package cs.service;

import cs.entity.User;

public interface UserService {
	User login(String id,String pwd) throws NameException,PwdException;
	User reg(String id,String pwd,String confirm) throws NameException,PwdException;
	User update(String id,String pwd,String username,String email);
}
