
	package com.dawn.util;

	import java.security.MessageDigest;
	import java.text.ParseException;
	import java.text.SimpleDateFormat;
	import java.util.Calendar;
	import java.util.Date;
	import java.util.Random;

<<<<<<< .mine
		 Date date=new Date();
		String token = df.format(date);
		token += "a";
		token += staff_ID;
		token += "a";
		token += staff_pwd;
		token = Token.convertMD5(token);
		return token;
	}
=======

	public class Token {
		public static final String allChar = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
>>>>>>> .r48

		/* 保存token值的默认命名空间  */
		public static String getToken(String staff_D,String pwd) {
			SimpleDateFormat df = new SimpleDateFormat("yyyy-mm-dd HH:mm:ss");
			 long st=System.currentTimeMillis(); 
			/*long st = 1302757320000L;*/
			/* System.out.println(st); */

			String token = df.format(st);
			token += "a";
			token += staff_D;
			token += "a";
			token += pwd;
			token = Token.convertMD5(token);
			return token;
		}

		/* MD5加码 生成32位md5码 */

		public static String string2MD5(String inStr) {
			MessageDigest md5 = null;
			try {
				md5 = MessageDigest.getInstance("MD5");
			} catch (Exception e) {
				System.out.println(e.toString());
				e.printStackTrace();
				return "";
			}
			char[] charArray = inStr.toCharArray();
			byte[] byteArray = new byte[charArray.length];

			for (int i = 0; i < charArray.length; i++)
				byteArray[i] = (byte) charArray[i];
			byte[] md5Bytes = md5.digest(byteArray);
			StringBuffer hexValue = new StringBuffer();
			for (int i = 0; i < md5Bytes.length; i++) {
				int val = ((int) md5Bytes[i]) & 0xff;
				if (val < 16)
					hexValue.append("0");
				hexValue.append(Integer.toHexString(val));
			}
			return hexValue.toString();

		}

		/**
		 * 加密解密算法 执行一次加密，两次解密
		 */
		public static String convertMD5(String inStr) {

			char[] a = inStr.toCharArray();
			for (int i = 0; i < a.length; i++) {
				a[i] = (char) (a[i] ^ 't');
			}
			String s = new String(a);
			return s;

		}
		
		
		
	      /*判段token是否失效*/
		public static Boolean invalidToken(String str) throws ParseException {
			String token = convertMD5(str);
			System.out.println("解密" + token);
			String[] sArry= token.split("a");
			for (String srr : sArry)
				System.out.println("分割" + srr);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd HH:mm:ss");
			Calendar ca=Calendar.getInstance();
			ca.setTime(sdf.parse(sArry[0]));
			ca.add(Calendar.HOUR_OF_DAY,6);
			Date d1=sdf.parse(sdf.format(ca.getTime()));
			System.out.println("d1token时间" + d1);
			long st = System.currentTimeMillis();
			Date d2 = sdf.parse(sdf.format(st));
			System.out.println("d2系统时间"+d2);
			long result=d1.getTime()-d2.getTime();
			if (result>0)
				return true;
			else
			return false;

		}

		/* 产生随机数 */
		public static String generateMixString(int length) {
			StringBuffer sb = new StringBuffer();
			Random random = new Random();
			for (int i = 0; i < length; i++) {
				sb.append(allChar.charAt(random.nextInt(allChar.length())));
			}

			return sb.toString();

		}

		public static void main(String[] arg) throws ParseException {
			System.out.println(Token.getToken("123","123"));
			System.out.println(Token.convertMD5("FDEEYDFYE@TEGNDFNDD+A+EE+EFG"));
			System.out.println(Token.invalidToken("FDECY@AYF@TEGN@ANEE+EE+EFG"));
			/*
			 * String s="asdassdjsi"; System.out.println(s);
			 * System.out.println("加密"+getMD5(s));
			 */

		}

	


}
