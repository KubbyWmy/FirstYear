package privateInfo;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

import javax.sql.DataSource;

import org.junit.Test;

import com.dawn.mapper.AssetMapper;
import com.dawn.mapper.StatusMapper;
import com.dawn.pojo.Asset;
import com.dawn.pojo.Status;

public class StatusTest extends DatabaseTest{
	@Test
	public void testDataSource() throws SQLException{
		DataSource ds=ctx.getBean("dataSource",DataSource.class);
		Connection conn=ds.getConnection();
		DatabaseMetaData md=conn.getMetaData();
		System.out.println(md);
		String n=md.getDatabaseProductName();
		String v=md.getDatabaseProductVersion();
		System.out.println(n+v);
		conn.close();
	}
	
	@Test
	public void testaddStatus(){
		StatusMapper a=ctx.getBean("statusMapper",StatusMapper.class);
		Date date=new Date(2017, 2, 9);
      Status status=new Status(1, 2, date, "良好", "张三", "待填");
		int i=a.addStatus(status);
		System.out.println(i);
	}
	
	@Test
	public void testdeleteStatus(){
		StatusMapper a=ctx.getBean("statusMapper",StatusMapper.class);
      int i=a.deleteStatus(1);
		System.out.println(i);
	}
	
	@Test
	public void testmodifyStatus(){
		StatusMapper a=ctx.getBean("statusMapper",StatusMapper.class);
		Date date=new Date(2017, 2, 9);
      Status status=new Status(1, 2, date, "良好", "张三", "待填");
		int i=a.modifyStatus(status);
		System.out.println(i);
	}
	
	@Test
	public void testqueryAllStutas(){
		StatusMapper a=ctx.getBean("statusMapper",StatusMapper.class);
		List<Status> list=a.queryAllStatus();
		for(Status s:list)
		System.out.println(s);
	}
	@Test
	public void testqueryStatus(){
		StatusMapper a=ctx.getBean("statusMapper",StatusMapper.class);
		Status list=a.queryOneAssetStatus(1);
		
		System.out.println(list);
	}
}
