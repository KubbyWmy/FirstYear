package test;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import org.junit.Test;

import cs.dao.InfoDao;
import cs.entity.Info;
import cs.service.InfoService;

public class JdbcInfoTest extends BaseTestCase {
	@Test
	public void testInfo1(){
		InfoDao dao=ctx.getBean("infoDao",InfoDao.class);
		System.out.println(dao);
		List<Map<String,Object>> list=dao.listInfo("wxm");
		for(Map<String,Object> map:list){
			System.out.println(map);
		}
	}
	@Test
	public void testInfo2() throws IOException{
//		InfoService service=ctx.getBean("infoService",InfoService.class);
//		List<Map<String,Object>> list=service.listInfo("wmy");
//		for(Map<String,Object> map:list){
//			System.out.println(map);
//		}
		InfoDao dao=ctx.getBean("infoDao",InfoDao.class);
		System.out.println(dao);
		Info info=dao.writeInfo(352);
		//FileOutputStream fos=new FileOutputStream(new File("C:/Users/tarena/Desktop/����/a.txt"),true);
		System.out.println(info);
		PrintWriter pw=new PrintWriter(new FileOutputStream(new File("C:/Users/wmywa/Desktop/lyt2/a.txt"),true), true);
		pw.println(info.toString());
	}
	@Test
	public void testInfo3(){
		InfoDao dao=ctx.getBean("infoDao",InfoDao.class);
		System.out.println(dao);
		int i=dao.removeInfo(2);
		InfoService service=ctx.getBean("infoService",InfoService.class);
		int a=service.removeInfo(211);
		System.out.println(a);
	}
	@Test
	public void testInfoInsert(){
		InfoDao dao=ctx.getBean("infoDao",InfoDao.class);
		Info info=new Info("wxm", 1, 1, 1, 1, 1);
		int i=dao.addInfo(info);
		System.out.println(i);
	}
	@Test
	public void addInfo(){
		InfoService service=ctx.getBean("infoService",InfoService.class);
		Info info=service.addInfo("wxm", 2, 2, 2, 2, 2);
		System.out.println(info);
	}
	@Test
	public void autowrite(){
		InfoDao dao=ctx.getBean("infoDao",InfoDao.class);
		//String info=dao.autoWrite();
		//System.out.println(info);
	}
}
