package com.dawn.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.dawn.mapper.StatusMapper;
import com.dawn.pojo.Asset;
import com.dawn.pojo.Status;
import com.dawn.service.StatusService;
import com.dawn.util.JsonResult;
@Service
public class StatusServiceImpl implements StatusService{

	@Resource
	private StatusMapper statusMapper;

	public JsonResult addStatus(Status status) {
		// TODO Auto-generated method stub
		if(statusMapper.addStatus(status)>0) return new JsonResult(1, null, "添加成功");
		return new JsonResult(0,new Throwable("添加失败"));
	}

	public JsonResult deleteStatus(Integer status_ID) {
		// TODO Auto-generated method stub
		if(statusMapper.deleteStatus(status_ID)>0){
			return new JsonResult(1, statusMapper.queryAllStatus(), "删除成功");
		}
		return new JsonResult(0,statusMapper.queryAllStatus(),"删除失败");
	}

	public JsonResult modifyStatus(Status status) {
		// TODO Auto-generated method stub
		if(statusMapper.modifyStatus(status)>0) return new JsonResult(1, statusMapper.queryAllStatus(),"修改成功");
		
		return new JsonResult(0, statusMapper.queryAllStatus(),"修改失败");
	}

	public JsonResult queryAllStatus() {
		// TODO Auto-generated method stub
		List<Status> list=statusMapper.queryAllStatus();
		if(list==null) return new JsonResult(0,new Throwable("该数据不存在"));
		return new JsonResult(1,list , "查询成功 ");
	}
/*	public JsonResult queryOneAssetStatus(Integer assetID) {
		// TODO Auto-generated method stub
		List<Status> status=statusMapper.queryOneAssetStatus(assetID);
		if(status.isEmpty()) return new JsonResult(0,new Throwable("数据不存在"));		
		return new JsonResult(1,status,"查询成功");
	}
*/
	public JsonResult queryOneAssetStatus(Integer status_ID) {
		Status status=statusMapper.queryOneAssetStatus(status_ID);
		if(status==null) return new JsonResult(0,new Throwable("该记录不存在"));
		return new JsonResult(1,status,"查询成功");
	}

	

}
