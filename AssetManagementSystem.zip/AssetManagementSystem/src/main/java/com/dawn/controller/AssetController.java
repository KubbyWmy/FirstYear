package com.dawn.controller;

import java.io.File;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.dawn.pojo.Asset;
import com.dawn.pojo.ProofInvoice;
import com.dawn.pojo.ProofPhoto;
import com.dawn.service.AssetService;
import com.dawn.util.JsonResult;
import com.dawn.util.PhotoUpload;

@Controller
@RequestMapping(value="/asset")
public class AssetController {
@Resource
private AssetService assetService;


//定义常量,1为操作成功,0为失败.
	private static int SUCCESS=1;
	private static int FAIL=0;
/*--------添加资产基本信息-----------*/
@RequestMapping("/add.do")
@ResponseBody
public  JsonResult addAssetBaseInfo(@RequestBody Asset asset){
	if(asset==null) return new JsonResult(0,new Throwable("参数不能为null"));
	System.out.println("接受到要添加的资产"+asset);
	return (JsonResult) assetService.addOneAsset(asset);
}
/*添加图片*/
@RequestMapping("/addPhoto.do")
@ResponseBody
public JsonResult addAssetPhoto(@RequestParam(value = "file", required = false) MultipartFile file, ProofPhoto proofPhoto,
HttpServletRequest request){
	if(proofPhoto==null) return new JsonResult(new Throwable("参数不能为null"));
	 String  url="addPhoto"+File.separator;
	 System.out.println("前缀"+url);
	 String path = request.getSession().getServletContext().getRealPath(File.separator+"addPhoto"+File.separator);
	System.out.println("文件路径" + path);
	String photo_url=PhotoUpload.upload(url, path, file);
	System.out.println("发票路径"+photo_url);
	proofPhoto.setPhoto_url(photo_url);
	return (JsonResult) assetService.addOnePhoto(proofPhoto);
	
}
/*添加发票*/
@RequestMapping("/addInvoice.do")
@ResponseBody
public JsonResult  addAssetInvoice(@RequestParam(value = "file", required = false) MultipartFile file,ProofInvoice  proofInvoice,
HttpServletRequest request){
	String  url="addPhoto"+File.separator;
	System.out.println("前缀"+url);
	String path = request.getSession().getServletContext().getRealPath(File.separator+"addPhoto"+File.separator);
	
	System.out.println("文件路径" + path);
	String invoice_url=PhotoUpload.upload(url, path, file);
	System.out.println("图片路径"+invoice_url);
	proofInvoice.setInvoice_url(invoice_url);
	 return (JsonResult) assetService.addOneInvocie(proofInvoice);
	
}
/*----------修改资产的基本信息-------------*/


@RequestMapping("/modify.do")
@ResponseBody
public JsonResult  modifyAssetBaseInfo(@RequestBody Asset asset){
	if(asset==null) return new  JsonResult(0,new Throwable("参数不能为null"));
	return (JsonResult) assetService.modifyAssetById(asset);
	
}
/*删除图片*/
@RequestMapping("/deletePhoto.do")
@ResponseBody
public JsonResult deleteAssetPhoto(@RequestBody ProofPhoto photo,HttpServletRequest servletRequest){
	System.out.println("图片"+photo);
	if(photo==null) return new JsonResult(0,new Throwable("参数不能为null"));
	return (JsonResult) assetService.deleteOnePhoto(photo,servletRequest);
	
	
}
/*删除发票*/
@RequestMapping("/deleteInvoice.do")
@ResponseBody
public JsonResult deleteAssetInvoice(@RequestBody ProofInvoice invoice,HttpServletRequest servletRequest){
	System.out.println(invoice);
	if(invoice==null) return new JsonResult(0,new Throwable("参数不能为null"));
	return (JsonResult) assetService.deleteOneInvoice(invoice,servletRequest);
	
}
/*----------查询资产信息--------------*/

/* * 此方法请求的资产的信息不包括资产的图片信息*/
  /*@RequestMapping("/queryOne.do")
public @ResponseBody Asset queryOneAssetById(Integer asset_ID){
	return assetService.queryOneAssetById(asset_ID);
	
}*/
/*
 * 查询所有资产信息记录，用于资产信息管理界面展示
 * */
@RequestMapping("/queryAllBaseInfo.do")
@ResponseBody
public JsonResult  queryAllAssetBaseInfo(){
	return (JsonResult) assetService.queryAllAssetExceptScrap();
}
/*查询单个资产基础信息包括实物图片和发票*/
@RequestMapping("/queryOne.do")
public @ResponseBody JsonResult queryAssetBaseInfo(Integer asset_ID){
	return assetService.queryOneAssetById(asset_ID);
}

/*查询资产的发票图片信息*/

/*@RequestMapping("/queryInvoiceUrl.do")
public @ResponseBody List<String> queryInvoice(Integer asset_ID){
	return assetService.queryInvoiceById(asset_ID);
}
*/

 @RequestMapping("/queryInvoice.do")
 @ResponseBody
 public JsonResult queryInvoice2(Integer asset_ID,HttpServletRequest servletRequest){
	 if(asset_ID==null) return new JsonResult(0,new Throwable("参数不能为null"));
	return (JsonResult) assetService.queryInvoiceById2(asset_ID,servletRequest);
}
/*
 * 查询资产实物图片信息*/
 /*@RequestMapping("/queryPhotoUrl.do")
public @ResponseBody List<String> queryPhoto(Integer asset_ID){
	return assetService.queryPhotoById(asset_ID);
 
}*/
 @RequestMapping("/queryPhoto.do")
 @ResponseBody
 public JsonResult queryPhoto(Integer asset_ID,HttpServletRequest servletRequest){
	 if(asset_ID==null) return new JsonResult(0,new Throwable("参数不能为null"));
 	return (JsonResult) assetService.queryPhotoById2(asset_ID,servletRequest);
  
 }
}
