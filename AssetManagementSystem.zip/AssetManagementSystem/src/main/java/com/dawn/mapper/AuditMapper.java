package com.dawn.mapper;

import java.util.List;

import com.dawn.pojo.Audit;

public interface AuditMapper {
 public int addAudit(Audit audit);
 public int modifyAudit(Audit audit);
 public int deleteAudit(Integer audit_ID);
 public Audit queryAudit(Integer asset_ID);
 public Audit queryAudit2(Integer audit_ID);

 public List<Audit> queryAllAudit();
}
