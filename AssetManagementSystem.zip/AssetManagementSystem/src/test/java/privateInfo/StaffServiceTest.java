package privateInfo;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.apache.commons.codec.digest.DigestUtils;
import org.junit.Test;

import com.dawn.mapper.StaffInfoMapper;
import com.dawn.pojo.Staff;
import com.dawn.service.StaffService;
import com.dawn.util.JsonResult;
public class StaffServiceTest extends DatabaseTest{
	@Test
	public void testDataSource() throws SQLException{
		DataSource ds=ctx.getBean("dataSource",DataSource.class);
		Connection conn=ds.getConnection();
		DatabaseMetaData md=conn.getMetaData();
		System.out.println(md);
		String n=md.getDatabaseProductName();
		String v=md.getDatabaseProductVersion();
		System.out.println(n+v);
		System.out.println(DigestUtils.md5Hex("adfa"+"dawn"));
		System.out.println("1c9664e6013a8e1d149a624e5996a219".equals(DigestUtils.md5Hex("111"+"dawn")));
		conn.close();
	}
	@Test
	public void addStaff(){
		StaffService service=ctx.getBean("staffService",StaffService.class);
		System.out.println(
				service.addStaff("124", "1", "123123", "1", "1", "1", 1)
				);
		
	}
	@Test
	public void deleteStaff(){
		StaffInfoMapper mapper=ctx.getBean("staffInfoMapper",StaffInfoMapper.class);
		System.out.println(
				mapper.deleteStaff("377")
				);
		
	}
	@Test
	public void showStaff(){
		StaffInfoMapper mapper=ctx.getBean("staffInfoMapper",StaffInfoMapper.class);
		List<Staff> list=mapper.showStaffInfo();
		for(Staff staff:list){
			System.out.println(staff);
		}
		
	}
	@Test
	public void changeStaff(){
		StaffInfoMapper mapper=ctx.getBean("staffInfoMapper",StaffInfoMapper.class);
		
		//Staff staff=new Staff("1","bbbaa","aaaaaa","aaaaa","aaaaa","aaaa",new Role());
		int a=mapper.changeStaffInfo("1", "adad", "asda", "adadf", "asdfasf", "dafd", 4);
		System.out.println(a);
	}
	@Test
	public void changePwd(){
		StaffService service=ctx.getBean("staffService",StaffService.class);
		System.out.println(new JsonResult(service.findStaffById("124")));
		
	}
}

