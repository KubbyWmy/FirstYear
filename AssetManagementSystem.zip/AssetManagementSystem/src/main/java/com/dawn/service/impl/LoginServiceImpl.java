package com.dawn.service.impl;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.stereotype.Service;

import com.dawn.mapper.StaffMapper;
import com.dawn.pojo.Staff;
import com.dawn.service.LoginService;
import com.dawn.util.JsonResult;
import com.dawn.util.PermissionConverter;
import com.dawn.util.Token;

@Service("loginService")
public class LoginServiceImpl implements LoginService {

	@Resource
	private StaffMapper staffMapper;

	/*
	 * 用于用户登录检验
	 */
	public JsonResult checkLogin(String staff_ID, String staff_pwd,HttpSession session) {
		Staff staff = staffMapper.queryStaff(staff_ID);
		if (staff== null)
			return new JsonResult(0,new Throwable("该用户不存在"));
		else if (staff.getStaff_pwd().equals(DigestUtils.md5Hex(staff_pwd+"dawn"))) {
			staff.setToken(Token.getToken(staff_ID,staff_pwd));
			PermissionConverter.StrToList(staff.getRole());
			session.setAttribute("token", staff.getToken());
			System.out.println(session.getAttribute("token"));
			return new JsonResult(1, staff, "登录成功");
		}
		else return new JsonResult(0,new Throwable("登录失败"));
	}

	public Object checkLogin2(String staff_ID, String staff_pwd) {
		Staff staff = staffMapper.queryStaff(staff_ID);
		if (staff== null)
			return new JsonResult(0,new Throwable("该用户不存在"));
		else if (staff.getStaff_pwd().equals(DigestUtils.md5Hex(staff_pwd+"dawn"))) {
			PermissionConverter.StrToList(staff.getRole());
			return new JsonResult(1, staff, "登录成功");
		}
		else return new JsonResult(0,new Throwable("登录失败"));
	
	}
	
	
}
