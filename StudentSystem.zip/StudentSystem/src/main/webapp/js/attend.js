function attend(){
	var url='http://localhost:8080/StudentSystem/student/attend.do';
	var param={studentId:$("#studentId").val()};
	$.post(url,param,function(result){
		if(result.state){
			alert("成功");
			location.href="index.html";
		}else{
			alert(result.message);
		}
	})
}