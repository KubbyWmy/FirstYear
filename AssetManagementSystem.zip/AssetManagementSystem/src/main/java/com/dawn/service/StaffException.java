package com.dawn.service;

public class StaffException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public StaffException() {
	}

	public StaffException(String message) {
		super(message);
	}

	public StaffException(Throwable cause) {
		super(cause);
	}

	public StaffException(String message, Throwable cause) {
		super(message, cause);
	}

	public StaffException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
