package dao;

import java.util.List;

import entity.Attendance;
import entity.Student;

public interface StudentDao {
	//管理员新增一名学生
	int addStudent(Student student);
	Student findStudentById(String studentId);
	//签到
	int attend(String studentId,String attendTime);
	int modifyStudent(Student student);
	List<Attendance> showAllAttend();
	List<Student> showAllStudent();
	
}
