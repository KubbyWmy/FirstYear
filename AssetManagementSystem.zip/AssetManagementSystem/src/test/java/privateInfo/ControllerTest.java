package privateInfo;

import java.io.IOException;
import java.net.URISyntaxException;

import org.junit.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.web.client.RestTemplate;

import com.dawn.util.Token;

public class ControllerTest {
	
	@Test
	public void testJsonRequestResponse() throws IOException, URISyntaxException {
		String url = "http://localhost:8080/AssetManagementSystem/role/add.do";
		HttpHeaders requestHeaders = new HttpHeaders();
		requestHeaders.set("Accept", "application/json");
		requestHeaders.set("token", "FDECYEMYFMTEDNEMNGD\u0015EF@\u0015EFG@AB");
		requestHeaders.set("Content-Type", "application/json");	
		String jsonStr = "{\"role_name\":\"gg\",\"permission\":16000}";
		RestTemplate restTemplate = new RestTemplate();
		HttpEntity<String> httpEntity = new HttpEntity<String>(jsonStr, requestHeaders);
		String jsonData = restTemplate.postForObject(url, httpEntity, String.class);
		System.out.println(jsonData);
	}
	@Test
	public void testJsonRequestResponse2() throws IOException, URISyntaxException {
		String url = "http://localhost:8080/AssetManagementSystem/audit/modify.do";
		HttpHeaders requestHeaders = new HttpHeaders();
		requestHeaders.set("Accept", "application/json");
		requestHeaders.set("token", "FDECYEMYFMTEDNEMNGD\u0015EF@\u0015EFG@AB");
		requestHeaders.set("Content-Type", "application/json");	
		String jsonStr = "{\"audit_ID\":\"1\",\"asset_no\":234}";
		RestTemplate restTemplate = new RestTemplate();
		HttpEntity<String> httpEntity = new HttpEntity<String>(jsonStr, requestHeaders);
		String jsonData = restTemplate.postForObject(url, httpEntity, String.class);
		System.out.println(jsonData);
	}
}
