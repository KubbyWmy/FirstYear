package com.dawn.mapper;


import java.util.List;

import com.dawn.pojo.Staff;
import com.dawn.service.StaffException;

public interface StaffInfoMapper {
	Staff findStaffById(String staff_id);
	int changeStaffPwd(String staff_id,String staff_pwd);
	int addStaff(String staff_id,String staff_name,
			String staff_pwd,String staff_dept,String staff_position,
			String contact_way,Integer role_ID);
	int deleteStaff(String staff_id);
	List<Staff> showStaffInfo();
	int changeStaffInfo(
			String staff_id,String staff_name,String pwd,
			String staff_dept,String staff_position,
			String contact_way,Integer role_id);
	int saveStaffInfo(String staff_id,String staff_position,String staff_contact_way);
}
