package com.dawn.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.dawn.pojo.Asset;
import com.dawn.pojo.ProofInvoice;
import com.dawn.pojo.ProofPhoto;
import com.dawn.util.JsonResult;

public interface AssetService {
	/*
	 * 添加资产基本信息，不包括图片信息和IS_fill字段
	 * */
  public JsonResult addOneAsset(Asset asset);
/*
 * 修改资产信息，仅限于基本的信息不包括图片和IS_fill字段
 * */
  public JsonResult modifyAssetById(Asset asset);
  /*
   * 查询资产信息根据资产asset_ID查询资产基本信息，包括IS_fill信息，但是不包括图片信息.
   * */
  public JsonResult queryOneAssetById(Integer assetID);
 /*
  *  查询所有资产的基本信息 不包括报废的
  *   */
  public JsonResult queryAllAssetExceptScrap();
  /*
   * 查询所有报废资产的基本信息
   * */
  public JsonResult queryAllAssetHasScrap();
/*  
 * 查询所有资产的基本信息 包括报废的
 * */
  public JsonResult queryAllAssetIncludeScrap();
 /*
  *  查询资产的所有信息包括发票图片与实物图片
  *  */
//  public Asset queryAssetIncludePhotos(Integer asset_ID);
/*
 * 根据asset_ID删除资产的基本信息
 * */
  public JsonResult  deleteOneAssetById(Integer asset_ID);
 /*
  *  增加一个资产的发票图片信息
  *  */
  public JsonResult addAllInvocie(List<ProofInvoice> proofInvoices);
/*  
 * 增加一个资产的发票图片信息
 * */
  public JsonResult addOneInvocie(ProofInvoice proofInvoice);
/* 
 * 删除资产发票图片信息
 * */
  public JsonResult deleteOneInvoice(ProofInvoice invoice,HttpServletRequest servletRequest);
  /*
   * 查询资产发票的信息，返回值为一个String 的list
   * */
 // public List<String> queryInvoiceById(Integer asset_ID);
  /*
   * 查询资产信息，返回值为一个pojo的List
   * */
  public JsonResult queryInvoiceById2(Integer asset_ID,HttpServletRequest servletRequest);
  
/*  
 * 批量增加一个资产的实物图片信息
 * */
  public JsonResult addAllPhoto(List<ProofPhoto> proofPhotos);
  /*
   * 增加一个资产实物图片
   * */
  public JsonResult addOnePhoto(ProofPhoto proofPhoto);
  /*
   * 删除一个资产信息的图片
   * */
  public JsonResult deleteOnePhoto(ProofPhoto photo,HttpServletRequest servletRequest);
/*  
 * 查询实物图  返回结果集是String-
 * */
 // public List<String> queryPhotoById(Integer asset_ID);
 /*
  * 查询资产实物图信息，返回值是pojo的list
  * */
  public JsonResult queryPhotoById2(Integer asset_ID,HttpServletRequest servletRequest);
  
  
}
