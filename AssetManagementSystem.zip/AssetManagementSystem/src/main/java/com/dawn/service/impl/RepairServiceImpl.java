  package com.dawn.service.impl;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import com.dawn.mapper.RepairMapper;
import com.dawn.pojo.ProofRepair;
import com.dawn.pojo.Repair;
import com.dawn.service.RepairService;
import com.dawn.util.JsonResult;
import com.dawn.util.PhotoUpload;
@Service
public class RepairServiceImpl implements RepairService{
@Resource
private RepairMapper repairMapper;
	public JsonResult addRepair(Repair repair) {
		return new JsonResult(1, repairMapper.addRepair(repair), "增加成功");
	}

	public JsonResult deleteRepair(Integer repair_ID) {
		if( repairMapper.deleteRepair(repair_ID)>0){
			List<Repair> list=repairMapper.queryAllRepair();
			return new JsonResult(1, list, "刪除成功");
		}
		else {
			List<Repair> list=repairMapper.queryAllRepair();
		    return new JsonResult(0, list, "刪除成功");
		}
	}

	public JsonResult modifyRepair(Repair repair) {
		// TODO Auto-generated method stub
		if(repairMapper.modifyRepair(repair)>0){
			Repair repair2=repairMapper.queryRepairById(repair.getRepair_ID());
			return new JsonResult(1,repair2,"修改成功");
		}
		Repair repair2=repairMapper.queryRepairById(repair.getRepair_ID());
		return new JsonResult(0,repair2,"修改失敗");
	}

	public JsonResult queryAllRepair() {
		List<Repair> repairs= repairMapper.queryAllRepair();
		if(repairs==null) return new JsonResult(1,new Throwable("记录不存在"));
		return new JsonResult(1, repairMapper.queryAllRepair(), "查詢成功");
	}
	
	/*public List<Repair> queryAssetRepair(Integer asset_ID) {
		// TODO Auto-generated method stub
		return repairMapper.queryAssetRepair(asset_ID);
	}
*/
	public JsonResult addRepairProof(ProofRepair proofRepair) {
		return new JsonResult(1, repairMapper.addRepairProof(proofRepair), "添加成功");
	}

/*	public List<String> queryRepairProof(Integer repair_ID) {
		System.out.println("go");
		List<String> s=repairMapper.queryRepairProof(repair_ID);
		for(String list:s)
			System.out.println(list);
		System.out.println("end");
		return s;
	}*/
	public JsonResult queryRepairProof2(Integer repair_ID,HttpServletRequest servletRequest) {
		List<ProofRepair> list=repairMapper.queryRepairProof2(repair_ID);
		if(list.isEmpty()) return new JsonResult(0,new Throwable("数据不存在"));
		for(ProofRepair r:list){
			String url=PhotoUpload.getUrl(servletRequest)+r.getRepair_url();
			String url2=url.replace("\\", "/");
			r.setRepair_url(url2);
		}
		return new JsonResult(1,list,"查询成功");
		
	}
	public JsonResult deleteRepairProof(ProofRepair proofRepair,HttpServletRequest servletRequest) {
		// TODO Auto-generated method stub
		if(repairMapper.deleteRepairProof(proofRepair.getRepairProof_ID())>0){
			List<ProofRepair> list=repairMapper.queryRepairProof2(proofRepair.getRepair_ID());
			if(list.isEmpty()) return new JsonResult(0,new Throwable("数据不存在"));
			for(ProofRepair r:list){
				String url=PhotoUpload.getUrl(servletRequest)+r.getRepair_url();
				String url2=url.replace("\\", "/");
				r.setRepair_url(url2);
			}
			
			return new JsonResult(1, list, "删除成功");
		}else{
			List<ProofRepair> list=repairMapper.queryRepairProof2(proofRepair.getRepair_ID());
			if(list.isEmpty()) return new JsonResult(0,new Throwable("数据不存在"));
			for(ProofRepair r:list){
				String url=PhotoUpload.getUrl(servletRequest)+r.getRepair_url();
				String url2=url.replace("\\", "/");
				r.setRepair_url(url2);
			}
			return new JsonResult(0, list, "删除失败");
		}
		
		
	}

	public JsonResult queryRepairById(Integer repair_ID) {
		// TODO Auto-generated method stub
		Repair repair=repairMapper.queryRepairById(repair_ID);
		if(repair==null) return new JsonResult(0,new Throwable("该记录不存在"));
		return new JsonResult(1,repair,"查询成功");
	}



}
