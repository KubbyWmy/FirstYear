package privateInfo;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

import javax.sql.DataSource;

import org.junit.Test;

import com.dawn.mapper.AuditMapper;
import com.dawn.pojo.Audit;

public class AuditTest extends DatabaseTest{
	@Test
	public void testDataSource() throws SQLException{
		DataSource ds=ctx.getBean("dataSource",DataSource.class);
		Connection conn=ds.getConnection();
		DatabaseMetaData md=conn.getMetaData();
		System.out.println(md);
		String n=md.getDatabaseProductName();
		String v=md.getDatabaseProductVersion();
		System.out.println(n+v);
		conn.close();
	}
	/*mapper层*/
	/*添加审核信息*/
	@Test
	public void testaddAudit(){
		AuditMapper a=ctx.getBean("auditMapper",AuditMapper.class);
		Date date=new Date(2017, 2, 9);
	    Audit audit=new Audit(1, 7,"name", 3, "研发", "14工位", "王武", "李四", date, "待填");
	     int i=a.addAudit(audit);
	     System.out.println(i);
	}
	@Test
	public void testaddAudit2(){
		AuditMapper a=ctx.getBean("auditMapper",AuditMapper.class);
	    Audit audit=new Audit();
	    audit.setAsset_no("No4456");
	    audit.setAsset_ID(8);
	     int i=a.addAudit(audit);
	     System.out.println(i);
	}
	@Test
	public void testModifyAudit(){
		AuditMapper a=ctx.getBean("auditMapper",AuditMapper.class);
	    Audit audit=new Audit();
	   /* audit.setAudit_ID(1);*/
	    audit.setAsset_ID(1);
	    audit.setAsset_dept("研发");;
	     int i=a.modifyAudit(audit);
	     System.out.println(i);
	}
	
	@Test
	public void testDeleteAudit(){
		AuditMapper a=ctx.getBean("auditMapper",AuditMapper.class);
	     int i=a.deleteAudit(2);
	     System.out.println(i);
	}
	
	@Test
	public void testqureryAudit(){
		AuditMapper a=ctx.getBean("auditMapper",AuditMapper.class);
	     Audit audit=a.queryAudit(6);
	     System.out.println(audit);
	}
	@Test
	public void testQureryAllAudit(){
		AuditMapper a=ctx.getBean("auditMapper",AuditMapper.class);
	     List<Audit> audit=a.queryAllAudit();
	     for(Audit list:audit)
	     System.out.println(list);
	}
}
