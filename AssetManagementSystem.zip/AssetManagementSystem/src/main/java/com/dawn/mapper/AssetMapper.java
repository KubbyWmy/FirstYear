package com.dawn.mapper;

import java.util.List;

import com.dawn.pojo.Asset;
import com.dawn.pojo.ProofInvoice;
import com.dawn.pojo.ProofPhoto;

public interface AssetMapper {
	/*
	 * 添加资产基本信息，不包括图片信息和IS_fill字段
	 * */
  public int addOneAsset(Asset asset);
/*
 * 修改资产信息，仅限于基本的信息不包括图片和IS_fill字段
 * */
  public int modifyAssetById(Asset asset);
  /*
   * 查询资产信息根据资产asset_ID查询资产基本信息，包括IS_fill信息，但是不包括图片信息.
   * */
  public Asset queryOneAssetById(Integer assetID);
 /*
  *  查询所有资产的基本信息 不包括报废的
  *   */
  public List<Asset> queryAllAssetExceptScrap();
  /*
   * 查询所有报废资产的基本信息
   * */
  public List<Asset> queryAllAssetHasScrap();
/*  
 * 查询所有资产的基本信息 包括报废的
 * */
  public List<Asset> queryAllAssetIncludeScrap();
 /*
  *  查询资产的所有信息包括发票图片与实物图片
  *  */
  public Asset queryAssetIncludePhotos(Integer asset_ID);
/*
 * 根据asset_ID删除资产的基本信息但是忽略图片信息和其他表的信息
 * */
  public int  deleteOneAssetById(Integer asset_ID);
  /*
   * 修改其他辅助信息状态
   * */
  public int setIsFill(Asset asset);
 /*
  *  增加一个资产的发票图片信息
  *  */
  public int addAllInvocie(List<ProofInvoice> proofInvoices);
/*  
 * 增加一个资产的发票图片信息
 * */
  public int addOneInvocie(ProofInvoice proofInvoices);
/* 
 * 删除资产发票图片信息
 * */
  public int deleteOneInvoice(Integer invoiceProof_ID);
  /*
   * 查询资产发票的信息，返回值为一个String 的list
   * */
  public List<String> queryInvoiceById(Integer asset_ID);
  /*
   * 查询资产信息，返回值为一个pojo的List
   * */
  public List<ProofInvoice> queryInvoiceById2(Integer asset_ID);
  
/*  
 * 批量增加一个资产的实物图片信息
 * */
  public int addAllPhoto(List<ProofPhoto> proofPhotos);
  /*
   * 增加一个资产实物图片
   * */
  public int addOnePhoto(ProofPhoto proofPhotos);
  /*
   * 删除一个资产信息的图片
   * */
  public int deleteOnePhoto(Integer invoiceProof_ID);
/*  
 * 查询实物图  返回结果集是String-
 * */
  public List<String> queryPhotoById(Integer asset_ID);
 /*
  * 查询资产实物图信息，返回值是pojo的list
  * */
  public List<ProofPhoto> queryPhotoById2(Integer asset_ID);
    public int deleteAudit2(Integer asset_ID);
    public int deleteRepair2(Integer asset_ID);
	public int deleteScrap2(Integer asset_ID);
	public int deleteStatus2(Integer asset_ID);
	public int deleteTransfer2(Integer asset_ID);
}
