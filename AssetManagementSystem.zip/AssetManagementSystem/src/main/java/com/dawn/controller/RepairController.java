package com.dawn.controller;

import java.io.File;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.dawn.pojo.ProofRepair;
import com.dawn.pojo.Repair;
import com.dawn.service.RepairService;
import com.dawn.util.JsonResult;
import com.dawn.util.PhotoUpload;

@Controller
@RequestMapping("/repair")
public class RepairController {
	@Resource
	private RepairService repairService;
	// 定义常量,1为操作成功,0为失败.
	private static int SUCCESS = 1;
	private static int FAIL = 0;

	@RequestMapping("/add.do")
	@ResponseBody
	public JsonResult addRepair(@RequestBody Repair repair) {
		if (repair == null)
			return new JsonResult(0, new Throwable("参数不为空"));
		return repairService.addRepair(repair);
	}

	@RequestMapping("/modify.do")
	@ResponseBody
	public JsonResult modifyRepair(@RequestBody Repair repair) {
		if (repair== null)
			return new JsonResult(0, new Throwable("参数不为空"));
		return repairService.modifyRepair(repair);
	}

	@RequestMapping("/delete.do")
	@ResponseBody
	public JsonResult modifyRepair(Integer repair_ID) {
		if (repair_ID == null)
			return new JsonResult(0, new Throwable("参数不为空"));
		return repairService.deleteRepair(repair_ID);
	}

	@RequestMapping("/queryAll.do")
	@ResponseBody
	public JsonResult queryAll() {
		return repairService.queryAllRepair();

	}
	@RequestMapping("/queryOne.do")
	@ResponseBody
	public JsonResult queryOne(Integer repair_ID) {
		return repairService.queryRepairById(repair_ID);

	}

	/* 添加证明材料 */
	@RequestMapping("/addProof.do")
	@ResponseBody
	public JsonResult addProof(@RequestParam(value = "file", required = false) MultipartFile file,
			 ProofRepair proofRepair, HttpServletRequest request) {
		if (proofRepair == null)
			return new JsonResult(1, new Throwable("参数不能为空"));
		String url = "addPhoto" + File.separator;
		String path = request.getSession().getServletContext()
				.getRealPath(File.separator + "addPhoto" + File.separator);
		System.out.println("文件路径" + path);
		String repair_url = PhotoUpload.upload(url, path, file);
		proofRepair.setRepair_url(repair_url);
		System.out.println(repair_url);
		return repairService.addRepairProof(proofRepair);

	}

	@RequestMapping("/queryProof.do")
	@ResponseBody
	public JsonResult queryProof(Integer repair_ID,HttpServletRequest servletRequest) {
		if (repair_ID == null)
			return new JsonResult(0, new Throwable("参数不能为空"));
		System.out.println(repair_ID);
		return repairService.queryRepairProof2(repair_ID,servletRequest);

	}

	@RequestMapping("/deleteProof.do")
	@ResponseBody
	public JsonResult deleteProof(@RequestBody ProofRepair proofRepair,HttpServletRequest servletRequest) {
		if (proofRepair == null)
			return new JsonResult(0, new Throwable("参数不能为空"));
		return repairService.deleteRepairProof(proofRepair,servletRequest);
	}
}
