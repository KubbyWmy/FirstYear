package service;

import org.apache.commons.codec.digest.DigestUtils;

public class test {

	public static void main(String[] args) {
		System.out.println(DigestUtils.md5Hex("123"+"123"));

	}

}
