package com.dawn.service;


import javax.servlet.http.HttpServletRequest;

import com.dawn.pojo.ProofTransfer;
import com.dawn.pojo.Transfer;
import com.dawn.util.JsonResult;

public interface TransferService {
	public JsonResult addTransfer(Transfer transfer);
	public JsonResult deleteTransfer(Integer transfer_ID);
	public JsonResult modifyTransfer(Transfer transfer);
	public JsonResult queryTransfer(Integer transfer_ID);
	public JsonResult queryAllTransfer();

	public JsonResult addTransferProof(ProofTransfer prooftransfer);
	//public List<String> queryTransferProof(Integer transfer_ID );
	public JsonResult queryTransferProof2(Integer transfer_ID,HttpServletRequest servletRequest );
	public JsonResult deleteTransferproof(ProofTransfer proofTransfer,HttpServletRequest servletRequest);
	public  JsonResult queryOneTransferProof(Integer transferProof_ID ,HttpServletRequest servletRequest);
}
