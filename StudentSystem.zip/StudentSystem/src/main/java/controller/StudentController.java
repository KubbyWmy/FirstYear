package controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import service.StudentException;
import service.StudentService;
import util.JsonResult;

@Controller
@RequestMapping("/student")
public class StudentController {
	@Resource
	private StudentService service;
	
	@ResponseBody
	@RequestMapping("/showAllAttendance.do")
	public JsonResult showAllAttend(){
		return new JsonResult(service.showAllAttendance());
	}
	@ResponseBody
	@RequestMapping("/showAllStudent.do")
	public JsonResult showAllStudent(){
		return new JsonResult(service.showAllStudent());
	}

	@ResponseBody
	@RequestMapping("/add.do")
	public JsonResult addStudent(String studentId,String studentName, String studentClass){
		return new JsonResult(service.addStudent(studentId, studentName, studentClass));
	}
	
	@ResponseBody
	@RequestMapping("/findStudent.do")
	public JsonResult findStudent(String studentId){
		return new JsonResult(service.findStudentById(studentId));
	}
	@ResponseBody
	@RequestMapping("/modify.do")
	public JsonResult modifyStudent(String studentId,String studentName, String studentClass){
		return new JsonResult(service.modifyStudent(studentId, studentName, studentClass));
		
		
	}
	@ResponseBody
	@RequestMapping("/attend.do")
	public JsonResult attend(String studentId,String attendTime){
		return new JsonResult(service.attend(studentId, attendTime));
	}
	@ExceptionHandler(StudentException.class)
	@ResponseBody
	public Object studentExp(StudentException e){
		return new JsonResult(0, e);
	}

}
