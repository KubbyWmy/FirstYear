	$(function(){
  		var ccc=getCookie("id");
		$('#head_username').html(ccc);
		$('#menu_username').html(ccc);
		var template='<tr>'+
		'<td>[water]</td>'+
		'<td>[temp]</td>'+
		'<td>[air]</td>'+
		'<td>[fert]</td>'+
		'<td>[sun]</td>'+
		'<td class="action-td">'+
			'<input type="button"  value="　√　"  onclick="writeAction(this);" class="btn btn-small btn-warning">'+
				'</input>　　'+				
			'<input type="button" value="　X　" onclick="removeAction(this);" class="btn btn-small">'+
			'</input>'+
			'</td>'+
		'</tr>';
		var url='info/list.do';
		var user_id=getCookie("id");
		var data={user_id:user_id};
		$.post(url,data,function(result){
			if(result.state==SUCCESS){
				var list=result.data;
				var listAll=$('#listbox_some');
				//console.log(a);
				var count=0;
				var count_today=list[0].water*1.5+list[0].temp*0.7+list[0].air*0.1+list[0].fert*3+list[0].sun*0.8;;
				$('#cost_today').html(Math.round(count_today));
				for(var i=0;i<5;i++){
					var tr= template.replace('[water]',list[i].water)
									.replace('[temp]',list[i].temp)
									.replace('[air]',list[i].air)
									.replace('[fert]',list[i].fert)
									.replace('[sun]',list[i].sun);
					count=count+list[i].water*1.5+list[i].temp*0.7+list[i].air*0.1+list[i].fert*3+list[i].sun*0.8;
					var creatime=list[i].creatime;
					tr=$(tr).data('creatime',creatime);
					listAll.append(tr);
				}
				count=Math.round(count);
				$('#cost_count').html(count);
			}
		});
  	});
