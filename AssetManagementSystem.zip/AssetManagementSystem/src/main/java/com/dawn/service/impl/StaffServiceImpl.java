package com.dawn.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.stereotype.Service;

import com.dawn.mapper.RoleMapper;
import com.dawn.mapper.StaffInfoMapper;
import com.dawn.mapper.StaffMapper;
import com.dawn.pojo.Staff;
import com.dawn.service.StaffException;
import com.dawn.service.StaffService;
import com.dawn.util.JsonResult;
@Service("staffService")

public class StaffServiceImpl implements StaffService {
	//定义常量,1为操作成功,0为失败.
	private static int SUCCESS=1;
	private static int FAIL=0;
	@Resource
	private StaffInfoMapper staffInfoMapper;
	private Staff staff;
	@Resource
	private StaffMapper mapper;
	@Resource
	private RoleMapper roleMapper;
	/**
	 * 通过员工id找到员工信息
	 */
	public Staff findStaffById(String id) {
		if(id==null||id.equals("")||id.trim()==""){
			throw new StaffException("用户id异常");
		}
		return staffInfoMapper.findStaffById(id);
	}
	/**
	 * 通过员工id找到员工后实现password的修改
	 */
	public int changeStaffPwd(String staff_id, String old_pwd,String staff_pwd) {
		if(staff_id==null||staff_id.trim().isEmpty()){
			throw new StaffException("用户id异常");
		}
		if(staff_pwd==null||staff_pwd.trim().isEmpty()){
			throw new StaffException("用户密码异常");
		}
		staff=staffInfoMapper.findStaffById(staff_id);
		if(staff!=null){
			System.out.println(staff.getStaff_pwd().equals(DigestUtils.md5Hex(old_pwd+"dawn")));
			System.out.println(staff.getStaff_pwd());
			System.out.println(old_pwd+"   "+staff_pwd);
			System.out.println(DigestUtils.md5Hex(old_pwd+"dawn"));
			if(staff.getStaff_pwd().equals(DigestUtils.md5Hex(old_pwd+"dawn"))){
				if(staffInfoMapper.changeStaffPwd(staff_id, DigestUtils.md5Hex(staff_pwd+"dawn"))==SUCCESS){
					return SUCCESS;
				}
			}else{
				throw new StaffException("用户原密码错误");
			}
		}else{
			throw new StaffException("用户id不存在");
		}
		return FAIL;
	}
	public int addStaff(String staff_id, String staff_name, String staff_pwd, String staff_dept, String staff_position,
			String contact_way, Integer role_ID) {
		System.out.println(staff_id);
		if(staff_id==null||staff_id.trim().isEmpty()){
			throw new StaffException("用户id异常");
		}
		if(staff_pwd==null||staff_pwd.trim().isEmpty()){
			throw new StaffException("用户密码异常");
		}
		System.out.println(mapper.queryStaff(staff_id));
		if(mapper.queryStaff(staff_id)!=null){
			throw new StaffException("您输入的工号已存在");
		}
		if(roleMapper.queryRoleById(role_ID)==null){
			throw new StaffException("赋予用户的权限异常");
		}
		
		if(staffInfoMapper.addStaff(staff_id, staff_name, DigestUtils.md5Hex(staff_pwd+"dawn"), staff_dept, 
				staff_position, contact_way, role_ID)==SUCCESS){
			
			return SUCCESS;
		}
		return FAIL;
	}
	public JsonResult deleteStaff(String staff_id,String handle_id) throws StaffException {
		if(staff_id==null||staff_id.trim().isEmpty()){
			throw new StaffException("用户id异常");
		}
		if(staffInfoMapper.findStaffById(staff_id)==null){
			throw new StaffException("用户id不存在");
		}
		if(staff_id.equals(handle_id)){
			throw new StaffException("您要把自己删了吗?");
		}
		if(staffInfoMapper.deleteStaff(staff_id)==SUCCESS){
			return new JsonResult(SUCCESS, staffInfoMapper.showStaffInfo(), "删除成功");
		}
		return new JsonResult(FAIL, staffInfoMapper.showStaffInfo()	, "删除失败");
	}
	public List<Staff> showStaffInfo() throws StaffException {
		
		System.out.println(staffInfoMapper.showStaffInfo());	
		return staffInfoMapper.showStaffInfo();
	}
	public JsonResult changeStaffInfo(String staff_id, String staff_name, String pwd, String staff_dept, String staff_position,
			String contact_way, Integer role_id) throws StaffException {
		if(staff_id==null||staff_id.trim().isEmpty()){
			throw new StaffException("用户id异常");
		}
		if(pwd==null||pwd.trim().isEmpty()){
			throw new StaffException("用户密码异常");
		}
		if(roleMapper.queryRoleById(role_id)==null){
			throw new StaffException("赋予用户的权限异常");
		}
		if(staffInfoMapper.findStaffById(staff_id)==null){
			throw new StaffException("用户id不存在");
		}
		staff=staffInfoMapper.findStaffById(staff_id);
		if(pwd.equals(staff.getStaff_pwd())){
			pwd=staff.getStaff_pwd();
		}
		pwd=DigestUtils.md5Hex(pwd+"dawn");
		if(staffInfoMapper.changeStaffInfo(staff_id, staff_name, pwd, staff_dept, staff_position, contact_way, role_id)==SUCCESS){
			return new JsonResult(staffInfoMapper.findStaffById(staff_id));
		}
		return new JsonResult(FAIL, staff, "更改失败");
	}
	public JsonResult saveStaffInfo(String staff_id, String staff_position, String contact_way) throws StaffException {
		if(staff_id==null||staff_id.trim().isEmpty()){
			throw new StaffException("用户id异常");
		}
		staff=staffInfoMapper.findStaffById(staff_id);
		if(staffInfoMapper.saveStaffInfo(staff_id, staff_position, contact_way)==SUCCESS){
			return new JsonResult(SUCCESS, staffInfoMapper.findStaffById(staff_id), "保存成功");
		}
		return new JsonResult(FAIL, staff, "保存失败");
	}
	
}
