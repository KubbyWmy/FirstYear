package com.dawn.util;
import com.dawn.pojo.Permission;
import com.dawn.pojo.Role;
import com.dawn.pojo.Staff;

public class PermissionConverter {

	public static Role StrToList(Role role) {
		
		String perStr=role.getPermission();
		System.out.println(perStr);
		/*String[] per = { "baseAuth", "auxiliaryAuth", "maintainAuth",
				"disposeAuth", "statusAuth", "transfersAuth",
				"usersAuth", "rolesAuth" };
		String[] perS = perStr.split(",");*/
		Permission permission=new Permission();
		 char[] charArr = perStr.toCharArray(); 
		 System.out.println(charArr);
	for(char s:charArr){
		switch (s) {
		case '1':
			permission.setBaseAuth(true);
			break;
		case '2':
			permission.setAuxiliaryAuth(true);;
			break;
		case '3':
		permission.setMaintainAuth(true);;
			break;
		case '4':
			permission.setDisposeAuth(true);;
			break;
		case '5':
			permission.setStatusAuth(true);;
			break;
		case '6':
			permission.setTransfersAuth(true);;
			break;	
		case '7':
			permission.setUsersAuth(true);
			break;
		case '8':
			permission.setRolesAuth(true);;
			break;
		}
	}
	   role.setPer(permission);
	  
		return role;

	}
	public Boolean isHave(String[] strs, String s) {
		for (int i = 0; i < strs.length; i++) {
			if (strs[i].indexOf(s) != -1) {// 循环查找字符串数组中的每个字符串中是否包含所有查找的内容 
				return true;// 查找到了就返回真，不在继续查询 
			}
		}
		return null;
	}
	
 public static void main(String[] args)  {
	 PermissionConverter p=new PermissionConverter();
	Staff staff=new Staff();
	Role role=new Role(3, "kk", "1,3,6,7");
	staff.setRole(role);
	System.out.println(p.StrToList(role));
}
 
}
