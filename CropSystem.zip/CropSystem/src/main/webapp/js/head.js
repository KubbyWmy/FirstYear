var SUCCESS=0;
$(function(){
	var url='info/list.do';
	var user_id=getCookie("id");
	var data={user_id:user_id};
	$.post(url,data,function(result){
		if(result.state==SUCCESS){
			var list=result.data;
			var max=list.length;
			$('#maxLine').html(max);
			$('#index_maxLine').html(max);
			
			}
		});
		var user_id=getCookie("id");
		var data={user_id:user_id};
		setInterval(function(){
			$.post('info/autoWrite.do',data,function(){
				location.reload();
				});
		}, 1000*6);
	
});