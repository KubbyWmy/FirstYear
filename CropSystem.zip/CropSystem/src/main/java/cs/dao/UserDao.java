package cs.dao;

import cs.entity.User;

public interface UserDao {
	User findUserById(String id);
	int addUser(User user);
	int updateUser(User user);
}
