package privateInfo;

import org.junit.Before;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dawn.mapper.RoleMapper;
import com.dawn.mapper.StaffInfoMapper;

public class DatabaseTest {
	ClassPathXmlApplicationContext ctx;
	
	@Before
	public void init(){//��ʼ��Spring����
		ctx=new ClassPathXmlApplicationContext("config/spring-service.xml","config/spring-mybatis.xml");
		
	}
}
