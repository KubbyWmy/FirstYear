package privateInfo;

import org.junit.Test;

import com.dawn.mapper.InventoryMapper;
import com.dawn.pojo.Inventory;

public class inventoryTest extends DatabaseTest{
	@Test
	public void testaddProofScrap()  {
		InventoryMapper a=ctx.getBean("inventoryMapper",InventoryMapper.class);
		Inventory i=a.queryInventoryById(3);
		
		
	     System.out.println(i);
	}
}
