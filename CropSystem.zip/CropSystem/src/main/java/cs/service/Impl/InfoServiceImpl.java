package cs.service.Impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import cs.dao.InfoDao;
import cs.dao.UserDao;
import cs.entity.Info;
import cs.entity.User;
import cs.service.InfoException;
import cs.service.InfoService;
import cs.service.UserException;
@Service("infoService")
public class InfoServiceImpl implements InfoService{
	@Resource
	private InfoDao infodao;
	@Resource
	private UserDao userdao;

	public List<Map<String, Object>> listInfo(String user_id) throws UserException {
		if(user_id==null||user_id.trim().isEmpty()){
			throw new InfoException("�û�ID����Ϊ��");
		}
		User user=userdao.findUserById(user_id);
		if(user==null){
			throw new InfoException("�û�ID������");
		}
		return infodao.listInfo(user_id);
	}

	public int removeInfo(int creatime) throws InfoException {
		return infodao.removeInfo(creatime);
	}

	public Info writeInfo(int creatime) throws InfoException, IOException {
		Info info=infodao.writeInfo(creatime);
		PrintWriter pw=new PrintWriter(new FileOutputStream(new File("C:/Users/wmywa/Desktop/a.txt"),true), true);
		pw.println(info.toString());
		pw.close();
		return info;
	}

	public Info addInfo(String user_id, int air, int water, int sun, int fert, int temp) throws InfoException {
		if(user_id==null||user_id.trim().isEmpty()){
			throw new InfoException("�û�ID����Ϊ��");
		}
		Info info=new Info(user_id, air, water, sun, fert, temp);
		infodao.addInfo(info);
		return info;
	}

	public Info autoWrite(String user_id) throws InfoException, IOException {
		int creatime=Integer.valueOf(infodao.autoWrite(user_id));
		Info info=infodao.writeInfo(creatime);
		PrintWriter pw=new PrintWriter(new FileOutputStream(new File("C:/Users/wmywa/Desktop/a.txt"),true), true);
		pw.println(info.toString());
		infodao.removeInfo(creatime);
		pw.close();
		return info;
	}

	
}
