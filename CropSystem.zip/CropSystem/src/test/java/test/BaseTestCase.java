package test;

import org.junit.Before;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class BaseTestCase {
	ClassPathXmlApplicationContext ctx;
	@Before
	public void init(){//��ʼ��Spring����
		ctx=new ClassPathXmlApplicationContext("config/spring-web.xml","config/spring-mybatis.xml","config/spring-service.xml");
		
	}
}
