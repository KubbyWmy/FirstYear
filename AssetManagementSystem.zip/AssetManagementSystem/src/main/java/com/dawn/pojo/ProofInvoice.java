package com.dawn.pojo;

public class ProofInvoice {
	private Integer invoiceProof_ID;
	private Integer asset_ID;
	private String invoice_url;
	private Integer is_delete;
	
	public ProofInvoice() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProofInvoice(Integer invoiceProof_ID, Integer asset_ID, String invoice_url) {
		super();
		this.invoiceProof_ID = invoiceProof_ID;
		this.asset_ID = asset_ID;
		this.invoice_url = invoice_url;
	}

	public Integer getAsset_ID() {
		return asset_ID;
	}

	public void setAsset_ID(Integer asset_ID) {
		this.asset_ID = asset_ID;
	}

	public String getInvoice_url() {
		return invoice_url;
	}

	public void setInvoice_url(String invoice_url) {
		this.invoice_url = invoice_url;
	}

	public Integer getIs_delete() {
		return is_delete;
	}

	public void setIs_delete(Integer is_delete) {
		this.is_delete = is_delete;
	}

	public void setInvoiceProof_ID(Integer invoiceProof_ID) {
		this.invoiceProof_ID = invoiceProof_ID;
	}

	public Integer getInvoiceProof_ID() {
		return invoiceProof_ID;
	}

	@Override
	public String toString() {
		return "ProofInvoice [invoiceProof_ID=" + invoiceProof_ID + ", asset_ID=" + asset_ID + ", invoice_url="
				+ invoice_url + ", is_delete=" + is_delete + "]";
	}

	
	
}
