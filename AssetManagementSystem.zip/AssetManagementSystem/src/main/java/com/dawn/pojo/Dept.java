package com.dawn.pojo;

public class Dept {
	private Integer dept_ID;
	private String dept_name;
	private Integer is_delete;
	public Dept() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Dept(Integer dept_ID, String dept_name, Integer is_delete) {
		super();
		this.dept_ID = dept_ID;
		this.dept_name = dept_name;
		this.is_delete = is_delete;
	}
	public Integer getDept_ID() {
		return dept_ID;
	}
	public void setDept_ID(Integer dept_ID) {
		this.dept_ID = dept_ID;
	}
	public String getDept_name() {
		return dept_name;
	}
	public void setDept_name(String dept_name) {
		this.dept_name = dept_name;
	}
	public Integer getIs_delete() {
		return is_delete;
	}
	public void setIs_delete(Integer is_delete) {
		this.is_delete = is_delete;
	}
	@Override
	public String toString() {
		return "Dept [dept_ID=" + dept_ID + ", dept_name=" + dept_name + ", is_delete=" + is_delete + "]";
	}
	
}
