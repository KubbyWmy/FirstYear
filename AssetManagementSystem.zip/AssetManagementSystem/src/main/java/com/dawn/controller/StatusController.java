package com.dawn.controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dawn.pojo.Status;
import com.dawn.service.StatusService;
import com.dawn.util.JsonResult;

@Controller
@RequestMapping("/status")
public class StatusController {
	//定义常量,1为操作成功,0为失败.
	private static int SUCCESS=1;
	private static int FAIL=0;
	
@Resource
private StatusService statusService;

@RequestMapping("/add.do")
@ResponseBody
public  JsonResult addStatus(@RequestBody Status status) {
	if (status.getAsset_ID()== null)
		return new JsonResult(0,new Throwable("参数不能为null"));
		return statusService.addStatus(status);
}

@RequestMapping("/delete.do")
@ResponseBody
public  JsonResult deleteStatus(Integer status_ID) {
	if (status_ID== null)
		return new JsonResult(0,new Throwable("参数不能为null"));
	return statusService.deleteStatus(status_ID);
}

@RequestMapping("/modify.do")
@ResponseBody
public  JsonResult modifyStatus(@RequestBody Status status) {
	if (status.getAsset_ID()== null)
		return new JsonResult(0,new Throwable("参数不能为null"));
	return statusService.modifyStatus(status);
}
@RequestMapping("/queryAll.do")
@ResponseBody
public  JsonResult queryAll() {
	return statusService.queryAllStatus();
}
@RequestMapping("/queryOne.do")
@ResponseBody
public  JsonResult queryOne(Integer status_ID) {
	return statusService.queryOneAssetStatus(status_ID);
}
	
}
