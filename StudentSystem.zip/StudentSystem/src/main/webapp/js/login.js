$(function(){
	$('#loginButton').click(loginAction);
	$('#adminId').focus().blur(checkId);
	$('#pwd').blur(checkPassword);
})
function checkId(){
	//console.log('checkUsername');
	var id=$('#adminId').val();
	if(! id){
		$('#idInfo').empty().html('不能为空');
		return false;
	}
	var reg=/^\w{3,10}$/;
	if(reg.test(id)){
		$('#idInfo').empty();
		return true;
	}else{
		$('#idInfo').empty().html('必须3~10字母');
		return false;
	}
}

function checkPassword(){
	console.log('checkPassword');
	var pwd = $('#pwd').val();
	if(! pwd){
		$('#pwdInfo').html('不能空');
		return false;
	}
	var reg=/^\w{3,10}$/;
	//console.log(pwd);
	if(reg.test(pwd)){
		$('#pwdInfo').empty();
		return true;
	}else{
		$('#pwdInfo').html('3~10位');
		return false;
	}
}
function loginAction(){
	//console.log(111);
	if(checkId()+checkPassword()!=2){
		return;
	}
	var adminId=$('#adminId').val();
	var pwd=$('#pwd').val();
	var url='http://localhost:8080/StudentSystem/admin/login.do';
	var param={adminId:adminId,pwd:pwd};
	$.post(url,param,function(result){
		//console.log(result);
		if(result.state){
			sessionStorage.setItem('adminId', result.data.adminId);
			location.href='index.html';
		}else {
				alert(result.message);
		}
	});
}