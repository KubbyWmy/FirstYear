package com.dawn.controller;

import java.text.ParseException;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dawn.service.LoginService;
import com.dawn.util.JsonResult;
import com.dawn.util.Token;

@Controller
@RequestMapping("/user")
public class LoginController {
	@Resource
	private LoginService service;

	@RequestMapping("/login.do")
	@ResponseBody
	public JsonResult checkLogin(String staff_ID, String staff_pwd, HttpSession session,HttpServletRequest servletRequest) {
		
		System.out.println(staff_ID+""+staff_pwd);
		if (staff_ID == null && staff_pwd == null)
			return new JsonResult(0,new Throwable("用户名或密码不能为空"));
		else {

			return (JsonResult) service.checkLogin(staff_ID, staff_pwd, session);
		}
	}
	@RequestMapping("/keep.do")
	public @ResponseBody JsonResult keepLogin(HttpServletRequest req) throws ParseException{
		String token = req.getHeader("token");
		
	/*	String token="FDECYAFYFMTEDNAFNDD\u0015EF@\u0015EFG@AB";*/
		System.out.println("加密"+token);
		String token2=Token.string2MD5(token);
		System.out.println("解密" + token2);
		if(!Token.invalidToken(token)) return new JsonResult(2,null,"token失效");
		 String[] sArry= token2.split("a");
		return (JsonResult) service.checkLogin2(sArry[1], sArry[2]);
		
	}
	
	
}
