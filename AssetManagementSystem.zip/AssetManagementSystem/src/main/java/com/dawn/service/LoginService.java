package com.dawn.service;

import javax.servlet.http.HttpSession;


public interface LoginService {
	public Object checkLogin(String staff_ID ,String staff_pwd,HttpSession session);
	public Object checkLogin2(String staff_ID ,String staff_pwd);
}
