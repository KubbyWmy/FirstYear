package com.dawn.pojo;

public class ProofTransfer {
  private Integer transferProof_ID;
  private Integer transfer_ID;
  private String transfer_url;
  private Integer is_delete;
  
  
public ProofTransfer() {
	super();
	// TODO Auto-generated constructor stub
}


public ProofTransfer(Integer transferProof_ID, Integer transfer_ID, String transfer_url) {
	super();
	this.transferProof_ID = transferProof_ID;
	this.transfer_ID = transfer_ID;
	this.transfer_url = transfer_url;
}

public Integer getTransferProof_ID() {
	return transferProof_ID;
}


public void setTransferProof_ID(Integer transferProof_ID) {
	this.transferProof_ID = transferProof_ID;
}


public Integer getTransfer_ID() {
	return transfer_ID;
}


public void setTransfer_ID(Integer transfer_ID) {
	this.transfer_ID = transfer_ID;
}


public String getTransfer_url() {
	return transfer_url;
}


public void setTransfer_url(String transfer_url) {
	this.transfer_url = transfer_url;
}


public Integer getIs_delete() {
	return is_delete;
}


public void setIs_delete(Integer is_delete) {
	this.is_delete = is_delete;
}


@Override
public String toString() {
	return "ProofTransfer [transferProof_ID=" + transferProof_ID + ", transfer_ID=" + transfer_ID + ", transfer_url="
			+ transfer_url + ", is_delete=" + is_delete + "]";
}



}
