package com.dawn.service.impl;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import com.dawn.mapper.AssetMapper;
import com.dawn.mapper.AuditMapper;
import com.dawn.mapper.ScrapMapper;
import com.dawn.pojo.Asset;
import com.dawn.pojo.Audit;
import com.dawn.pojo.ProofScrap;
import com.dawn.pojo.Scrap;
import com.dawn.service.ScrapService;
import com.dawn.util.JsonResult;
import com.dawn.util.PhotoUpload;

@Service
public class ScrapServiceImpl implements ScrapService {
	@Resource
	private ScrapMapper scrapMapper;
	@Resource
	private AssetMapper assetMapper;
	@Resource
    private AuditMapper auditMapper;
	
	public JsonResult addScrap(Scrap scrap) {
		Scrap scrap2=scrapMapper.queryAssetScrap(scrap.getAsset_ID());
		Asset asset=assetMapper.queryOneAssetById(scrap.getAsset_ID());
		Audit audit=auditMapper.queryAudit(scrap.getAsset_ID());
		if(scrap2!=null) return new JsonResult(0,new Throwable("数据已存在"));
		if(asset==null) return new JsonResult(0,new Throwable("请添加基础信息"));
		if(audit==null) return new JsonResult(0,new Throwable("请添辅助础信息"));
		if (scrapMapper.addScrap(scrap) > 0) {
			Asset asset2 = new Asset();
			asset2.setAudit_isFill(1);
			asset2.setAsset_ID(scrap.getAsset_ID());
			assetMapper.setIsFill(asset);
			return new JsonResult(1);
		} else
			return new JsonResult(0);
	}

	public JsonResult deleteScrap(Integer scrap_ID) {
		Scrap scrap=scrapMapper.queryAssetScrap(scrap_ID);
		System.out.println(scrap);;
		if(scrap==null)return new JsonResult(0,new Throwable("数据不存在"));
		if (scrapMapper.deleteScrap(scrap_ID) > 0) {
			Asset asset = new Asset();
			asset.setAudit_isFill(1);
			asset.setAsset_ID(scrap.getAsset_ID());
			assetMapper.setIsFill(asset);
			List<Scrap> list=scrapMapper.queryAllScrap();
			return new JsonResult(1, list, "删除成功");
		} else
			return new JsonResult(0, scrapMapper.queryAllScrap(),"删除失败");
	}

	public JsonResult modifyScrap(Scrap scrap) {
		
		if(scrapMapper.modifyScrap(scrap) > 0){
		Scrap scrap2=scrapMapper.queryAssetScrap(scrap.getAsset_ID());
			return new JsonResult(1, scrap2, "修改成功");
		}
		return new JsonResult(0,assetMapper.queryAllAssetExceptScrap(),"修改失败");
	}
	public JsonResult queryAllScrap() {
		List<Scrap> list=scrapMapper.queryAllScrap();
		if(list.isEmpty()) return new JsonResult(0,new Throwable("数据不存在"));
		return new JsonResult(1,list,"查询成功") ;
	}

	
	  public JsonResult queryAssetScrap(Integer asset_ID) { 
		  Scrap scrap=scrapMapper.queryAssetScrap(asset_ID);
		  if(scrap==null) return new JsonResult(0, new Throwable("该记录不存在"));  
		  return new JsonResult(1,scrap,"查询成功"); 
	  }

	public JsonResult addProofScrap(ProofScrap proofScrap) {
		return new JsonResult(1, scrapMapper.addProofScrap(proofScrap), "添加成功");
	}

	/*
	 * public List<String> queryProofScrap(Integer scrap_ID) { return
	 * scrapMapper.queryProofScrap(scrap_ID); }
	 */

	public JsonResult deleteProofScrap(ProofScrap proofScrap,HttpServletRequest servletRequest) {
		if(scrapMapper.deleteProofScrap(proofScrap.getScrapProof_ID()) > 0){
		List<ProofScrap> proofScraps=scrapMapper.queryProofScrap2(proofScrap.getScrap_ID());
		if(proofScraps.isEmpty())return new JsonResult(0,new Throwable("数据不存在"));
		for(ProofScrap proofScrap2:proofScraps){
			String url=PhotoUpload.getUrl(servletRequest)+proofScrap2.getScrap_url();
			String url2=url.replace("\\", "/");
			proofScrap2.setScrap_url(url2);
		}
			return new JsonResult(1,proofScraps,"添加成功");
		}else{
			List<ProofScrap> proofScraps=scrapMapper.queryProofScrap2(proofScrap.getScrap_ID());
			if(proofScraps.isEmpty())return new JsonResult(0,new Throwable("数据不存在"));
			for(ProofScrap proofScrap2:proofScraps){
				String url=PhotoUpload.getUrl(servletRequest)+proofScrap2.getScrap_url();
				String url2=url.replace("\\", "/");
				proofScrap2.setScrap_url(url2);
			}
		}
		return new JsonResult(1,scrapMapper.queryAllScrap(),"删除失败");
	}

	public JsonResult queryProofScrap2(Integer scrap_ID,HttpServletRequest servletRequest) {
		List<ProofScrap> proofScraps=scrapMapper.queryProofScrap2(scrap_ID);
		if(proofScraps.isEmpty())return new JsonResult(0,new Throwable("数据不存在"));
		for(ProofScrap proofScrap2:proofScraps){
			String url=PhotoUpload.getUrl(servletRequest)+proofScrap2.getScrap_url();
			String url2=url.replace("\\", "/");
			proofScrap2.setScrap_url(url2);
		}
		return new JsonResult(1, proofScraps, "查詢成功") ;
		
	}

}
