package com.dawn.pojo;

public class ProofRepair {
 private Integer repairProof_ID;
 private Integer repair_ID;
 private String repair_url;
 private Integer is_delete;

	
	
	public ProofRepair() {
		super();
		// TODO Auto-generated constructor stub
	}



	public ProofRepair(Integer repairProof_ID, Integer repair_ID, String repair_url) {
		super();
		this.repairProof_ID = repairProof_ID;
		this.repair_ID = repair_ID;
		this.repair_url = repair_url;
	}



	public Integer getRepairProof_ID() {
		return repairProof_ID;
	}



	public void setRepairProof_ID(Integer repairProof_ID) {
		this.repairProof_ID = repairProof_ID;
	}



	public Integer getRepair_ID() {
		return repair_ID;
	}



	public void setRepair_ID(Integer repair_ID) {
		this.repair_ID = repair_ID;
	}



	public String getRepair_url() {
		return repair_url;
	}



	public void setRepair_url(String repair_url) {
		this.repair_url = repair_url;
	}



	public Integer getIs_delete() {
		return is_delete;
	}



	public void setIs_delete(Integer is_delete) {
		this.is_delete = is_delete;
	}



	@Override
	public String toString() {
		return "ProofRepair [repairProof_ID=" + repairProof_ID + ", repair_ID=" + repair_ID + ", repair_url="
				+ repair_url + ", is_delete=" + is_delete + "]";
	}


	
}
