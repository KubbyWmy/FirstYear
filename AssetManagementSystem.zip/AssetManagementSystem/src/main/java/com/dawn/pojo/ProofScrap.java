package com.dawn.pojo;

public class ProofScrap {
private Integer scrapProof_ID;
private Integer scrap_ID;
private String scrap_url;
private Integer is_delete;

public ProofScrap() {
	super();
	// TODO Auto-generated constructor stub
}

public ProofScrap(Integer scrapProof_ID, Integer scrap_ID, String scrap_url) {
	super();
	this.scrapProof_ID = scrapProof_ID;
	this.scrap_ID = scrap_ID;
	this.scrap_url = scrap_url;
}

public Integer getScrapProof_ID() {
	return scrapProof_ID;
}

public void setScrapProof_ID(Integer scrapProof_ID) {
	this.scrapProof_ID = scrapProof_ID;
}

public Integer getScrap_ID() {
	return scrap_ID;
}

public void setScrap_ID(Integer scrap_ID) {
	this.scrap_ID = scrap_ID;
}

public String getScrap_url() {
	return scrap_url;
}

public void setScrap_url(String scrap_url) {
	this.scrap_url = scrap_url;
}

public Integer getIs_delete() {
	return is_delete;
}

public void setIs_delete(Integer is_delete) {
	this.is_delete = is_delete;
}

@Override
public String toString() {
	return "ProofScrap [scrapProof_ID=" + scrapProof_ID + ", scrap_ID=" + scrap_ID + ", scrap_url=" + scrap_url
			+ ", is_delete=" + is_delete + "]";
}


}
