package com.dawn.service.impl;


import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.dawn.mapper.InventoryMapper;
import com.dawn.pojo.Inventory;
import com.dawn.service.InventoryService;
import com.dawn.util.InventoryUtil;
import com.dawn.util.JsonResult;
import com.sun.org.apache.bcel.internal.generic.RETURN;
@Service
public class InventoryServiceImpl implements InventoryService{
@Resource
private InventoryMapper inventoryMapper;
	public JsonResult queryInventoryById(Integer asset_ID) {
     Inventory inventory=inventoryMapper.queryInventoryById(asset_ID);
     if(inventory==null)return new JsonResult(0,new Throwable("数据不存在"));
		return new JsonResult(1,InventoryUtil.getInventory(inventory),"查询成功");
	}
	

}
