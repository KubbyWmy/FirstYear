package com.dawn.pojo;

public class ProofPhoto {

	private Integer photoProof_ID;
	private String photo_url;
	private Integer asset_ID;
	private Integer is_delete;
	
	public ProofPhoto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ProofPhoto(Integer photoProof_ID, String photo_url, Integer asset_ID) {
		super();
		this.photoProof_ID = photoProof_ID;
		this.photo_url = photo_url;
		this.asset_ID = asset_ID;
	}

	public Integer getPhotoProof_ID() {
		return photoProof_ID;
	}

	public void setPhotoProof_ID(Integer photoProof_ID) {
		this.photoProof_ID = photoProof_ID;
	}

	public String getPhoto_url() {
		return photo_url;
	}

	public void setPhoto_url(String photo_url) {
		this.photo_url = photo_url;
	}

	public Integer getAsset_ID() {
		return asset_ID;
	}

	public void setAsset_ID(Integer asset_ID) {
		this.asset_ID = asset_ID;
	}

	public Integer getIs_delete() {
		return is_delete;
	}

	public void setIs_delete(Integer is_delete) {
		this.is_delete = is_delete;
	}

	@Override
	public String toString() {
		return "ProofPhoto [photoProof_ID=" + photoProof_ID + ", photo_url=" + photo_url + ", asset_ID=" + asset_ID
				+ "]";
	}
	
	
}
