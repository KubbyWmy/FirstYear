package service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import dao.StudentDao;
import entity.Attendance;
import entity.Student;
@Service("studentService")
public class StudentServiceImpl implements StudentService {
	@Resource
	private StudentDao studentDao;
	
	public int addStudent(String studentId, String studentName, String studentClass) 
			throws StudentException {
		if(studentId==null||studentId.trim().isEmpty()){
			throw new StudentException("学号不能为空");
		}
		int state=studentDao.addStudent(new Student(studentId, studentName, studentClass));
		if(state!=1){
			throw new StudentException("增加失败");
		}
		return state;
	}

	public Student findStudentById(String studentId) throws StudentException {
		if(studentId==null||studentId.trim().isEmpty()){
			throw new StudentException("学号不能为空");
		}
		Student student=studentDao.findStudentById(studentId);
		if(student==null){
			throw new StudentException("学生不存在");
		}
		return student;
	}

	public int attend(String studentId,String attendTime) throws StudentException {
		if(studentId==null||studentId.trim().isEmpty()){
			throw new StudentException("学号不能为空");
		}
		int state=studentDao.attend(studentId, 
				new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(
						new Date(System.currentTimeMillis())));
		if(state!=1){
			throw new StudentException("打卡失败");
		}
		return state;
	}

	public int modifyStudent(String studentId, String studentName, String studentClass)  
			throws StudentException {
		if(studentId==null||studentId.trim().isEmpty()){
			throw new StudentException("学号不能为空");
		}
		Student student =new Student(studentId, studentName, studentClass);
		int state=studentDao.modifyStudent(student);
		if(state!=1){
			throw new StudentException("更改失败");
		}
		return state;
	}

	public List<Attendance> showAllAttendance() {
		
		return studentDao.showAllAttend();
	}

	public List<Student> showAllStudent() {
		return studentDao.showAllStudent();
	}

}
