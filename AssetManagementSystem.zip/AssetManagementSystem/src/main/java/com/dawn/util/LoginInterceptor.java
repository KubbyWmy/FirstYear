package com.dawn.util;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.dawn.pojo.Staff;

public class LoginInterceptor implements HandlerInterceptor {

	public void afterCompletion(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, Exception arg3)
			throws Exception {
		// TODO Auto-generated method stub

	}

	public void postHandle(HttpServletRequest req, HttpServletResponse res, Object obj, ModelAndView arg3)
			throws Exception {
		// TODO Auto-generated method stub

	}

	public boolean preHandle(HttpServletRequest req, HttpServletResponse res, Object obj) throws Exception {
		System.out.println("this is preHandle of LoginInterceptor");
		PrintWriter out = null;
		String url = req.getServletPath().toString();
		String url2 = "/user/login.do";
		System.out.println(url);
		if (url.equals(url2) == false) {
			 HttpSession session = req.getSession();
				System.out.println("session"+session);			
				String token3 = req.getHeader("token");
				System.out.println("heand"+token3);	
			if (token3 == null) {
				res.setHeader("Content-Type", "text/html; charset=UTF-8");
				out = res.getWriter();
				String json = "{\"state\":2,\"data\":null," + "\"message\":\"亲，你还没有登录哦!\"}";
				out.print(json);
				return false;
			} else if (!Token.invalidToken(token3)) {
				res.setHeader("Content-Type", "text/html; charset=UTF-8");
				out = res.getWriter();
				String json = "{\"state\":2,\"data\":null," + "\"message\":\"亲，你的tonken已失效!\"}";
				out.print(json);
				return false;
			}
	
		}
		return true;
	}

}
