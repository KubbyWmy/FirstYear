//$('#chart_table').click(showAction); 
$(function (){
	var data1 = new Array ();
    var ds = new Array();
    var url='info/list.do';
	var user_id=getCookie("id");
	var data={user_id:user_id};
	$.post(url,data,function(result){
		//console.log(result.data[5].water);
			data1.push ([[1,result.data[0].water],
			            [2,result.data[1].water],
			            [3,result.data[2].water],
			            [4,result.data[3].water],
			            [5,result.data[4].water]]);
			data1.push ([[1,result.data[0].temp],
			            [2,result.data[1].temp],
			            [3,result.data[2].temp],
			            [4,result.data[3].temp],
			            [5,result.data[4].temp]]);
			data1.push ([[1,result.data[0].air],
			            [2,result.data[1].air],
			            [3,result.data[2].air],
			            [4,result.data[3].air],
			            [5,result.data[4].air]]);
			data1.push ([[1,result.data[0].fert],
			            [2,result.data[1].fert],
			            [3,result.data[2].fert],
			            [4,result.data[3].fert],
			            [5,result.data[4].fert]]);
			data1.push ([[1,result.data[0].sun],
			            [2,result.data[1].sun],
			            [3,result.data[2].sun],
			            [4,result.data[3].sun],
			            [5,result.data[4].sun]]);
    
    for (var i=0, j=data1.length; i<j; i++) {
	     ds.push({
	        data:data1[i],
	        grid:{
            hoverable:true
        },
	        bars: {
	            show: true, 
	            barWidth: 0.15, 
	            order: 1,
	            lineWidth:1, 	
				fillColor: { colors: [ { opacity: 0.65 }, { opacity: 1 } ] }
	        }
	    });
	}
	    
    $.plot($("#bar-chart"), ds, {
    	colors: ["#F90", "#3C4055","#3C4049", "#666", "#BBB"]
    });
	});
});
                
