package service;

import javax.annotation.Resource;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.stereotype.Service;

import dao.AdminDao;
import entity.Admin;
@Service("adminService")
public class AdminServiceImpl implements AdminService {
	@Resource
	private AdminDao adminDao;
	
	public Admin login(String adminId,String pwd) {
		if(adminId==null||adminId.trim().isEmpty()){
			throw new AdminException("管理员Id异常");
		}
		if(pwd==null||pwd.trim().isEmpty()){
			throw new AdminException("密码不能为空");
		}
		Admin admin=adminDao.findAdminById(adminId);
		if(admin==null){
			throw new AdminException("管理员不存在");
		}
		if(admin.getPwd().equals(DigestUtils.md5Hex(pwd+"123"))){
			return admin;
		}
		throw new AdminException("登录失败");
	}

	

}
