package com.dawn.service;


import com.dawn.pojo.Status;
import com.dawn.util.JsonResult;

public interface StatusService {
	public JsonResult addStatus(Status status);
	public JsonResult deleteStatus(Integer status_ID);
	public JsonResult modifyStatus(Status status);
	public JsonResult queryAllStatus();
	public JsonResult queryOneAssetStatus(Integer status_ID);
	/*public JsonResult queryOneStatus(Integer status_ID);*/

}
