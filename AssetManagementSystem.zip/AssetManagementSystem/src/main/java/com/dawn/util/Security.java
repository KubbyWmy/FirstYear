package com.dawn.util;
import java.util.Scanner;

public class Security {



	/**
	 * java加密解密算法
	 * 
	 * @author 螃蟹
	 * 网站：IT学习者
	 * 网址：http://itxxz.com
	 *
	 */


	    public static void main(String[] args){
	        //Scanner scan = new Scanner(System.in);
	        boolean flag = true;
	        String msg = "2017a1a12456";
	        while(true){
	            if(flag){
	                msg = "加密";
	                flag = false;
	            }else{
	                msg = "解密";
	                flag = true;
	            }
	            System.out.println("请输入需要"+msg+"的字符串：");
	            String password =null; //scan.nextLine();
	            char[] array = password.toCharArray();
	            for(int i = 0;i<array.length;i++){
	                array[i] = (char)(array[i]^2);
	            }
	            System.out.println(msg+"结果如下：");
	            System.out.println(new String(array));
	        }
	        
	    }
	}
