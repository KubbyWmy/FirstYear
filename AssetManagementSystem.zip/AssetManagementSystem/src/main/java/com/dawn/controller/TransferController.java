package com.dawn.controller;

import java.io.File;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.dawn.pojo.ProofTransfer;
import com.dawn.pojo.Transfer;
import com.dawn.service.TransferService;
import com.dawn.util.JsonResult;
import com.dawn.util.PhotoUpload;

@Controller
@RequestMapping("/transfer")
public class TransferController {
	// 定义常量,1为操作成功,0为失败.
	private static int SUCCESS = 1;
	private static int FAIL = 0;

	@Resource
	private TransferService transferService;

	@RequestMapping("/add.do")
	@ResponseBody
	public JsonResult addTransfer(@RequestBody Transfer transfer) {
		if (transfer.getAsset_ID() == null)
			return new JsonResult(0,new Throwable("参数不能为空"));
		return transferService.addTransfer(transfer);
	}

	@RequestMapping("/delete.do")
	@ResponseBody
	public JsonResult deleteTransfer(Integer transfer_ID) {
		if (transfer_ID == null)
			return new JsonResult(0,new Throwable("参数不能为空"));
		return transferService.deleteTransfer(transfer_ID);
	}

	@RequestMapping("/modify.do")
	@ResponseBody
	public JsonResult modifyTransfer(@RequestBody Transfer transfer) {
		if (transfer.getAsset_ID() == null)
			return new JsonResult(0,new Throwable("参数不能为空"));
		return transferService.modifyTransfer(transfer);
	}

	@RequestMapping("/queryAll.do")
	@ResponseBody
	public JsonResult  queryTransfer() {
		return transferService.queryAllTransfer();
	}
	
	@RequestMapping("/queryOne.do")
	@ResponseBody
	public JsonResult  queryOneTransfer(Integer transfer_ID) {
		return transferService.queryTransfer(transfer_ID);
	}

	/* 添加证明材料 */
	@RequestMapping("/addProof.do")
	@ResponseBody
	public JsonResult addTransferProof(@RequestParam(value = "file", required = false) MultipartFile file,
			 ProofTransfer prooftransfer, HttpServletRequest request) {
		String url = "addPhoto" + File.separator;
		String path = request.getSession().getServletContext()
				.getRealPath(File.separator + "addPhoto" + File.separator);
		System.out.println("文件路径" + path);
		String transfer_url = PhotoUpload.upload(url, path, file);
		prooftransfer.setTransfer_url(transfer_url);
		System.out.println(transfer_url);
		return transferService.addTransferProof(prooftransfer);

	}

	/*
	 * @RequestMapping("/queryProof.do") public @ResponseBody List<String>
	 * queryProof(Integer transfer_ID){ if(transfer_ID==null) return null;
	 * return transferService.queryTransferProof(transfer_ID);
	 * 
	 * }
	 */
	@RequestMapping("/queryProof.do")
	@ResponseBody
	public JsonResult queryProof(Integer transfer_ID,HttpServletRequest servletRequest) {
		if (transfer_ID == null)
			return new JsonResult(0,new Throwable("参数不能为空"));
		return transferService.queryTransferProof2(transfer_ID,servletRequest);

	}
	@RequestMapping("/deleteProof.do")
	@ResponseBody
	public JsonResult deleteProof(@RequestBody ProofTransfer proofTransfer,HttpServletRequest servletRequest) {
		if (proofTransfer == null)
			return new JsonResult(0,new Throwable("参数不能为空"));
		return transferService.deleteTransferproof(proofTransfer,servletRequest);
	}

}