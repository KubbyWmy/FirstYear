package com.dawn.pojo;

import java.sql.Date;

import com.alibaba.fastjson.annotation.JSONField;

public class Audit {
	private Integer asset_ID;
	private Integer audit_ID;
	private String asset_no;
	private Integer depreciation ;
	private String asset_dept;
	private String asset_location;
	private String auditor_name;	
	private String asset_custodian;
    @JSONField(format="yyyy-mm-dd")
	private Date used_date;
	private String remarks;
	private Integer is_delete;
	private Asset asset;
	public Audit() {
		super();
		// TODO Auto-generated constructor stub
	}
	//构造一个审核信息,用于sava
	
	
//构造一个辅助信息用于查询
	
	public Integer getAsset_ID() {
		return asset_ID;
	}
	public Audit(Integer asset_ID, Integer audit_ID, String asset_no,Integer depreciation,
			String asset_dept, String asset_location, String auditor_name, String asset_custodian, Date used_date,
			String remarks) {
		super();
		this.asset_ID = asset_ID;
		this.audit_ID = audit_ID;
		this.asset_no = asset_no;
		this.depreciation = depreciation;
		this.asset_dept = asset_dept;
		this.asset_location = asset_location;
		this.auditor_name = auditor_name;
		this.asset_custodian = asset_custodian;
		this.used_date = used_date;
		this.remarks = remarks;
	}
	
	public Audit(Integer asset_ID, Integer audit_ID, String asset_no, Integer depreciation, String asset_dept,
			String asset_location, String auditor_name, String asset_custodian, Date used_date, String remarks,
			Asset asset) {
		super();
		this.asset_ID = asset_ID;
		this.audit_ID = audit_ID;
		this.asset_no = asset_no;
		this.depreciation = depreciation;
		this.asset_dept = asset_dept;
		this.asset_location = asset_location;
		this.auditor_name = auditor_name;
		this.asset_custodian = asset_custodian;
		this.used_date = used_date;
		this.remarks = remarks;
		this.asset = asset;
	}
	public void setAsset_ID(Integer asset_ID) {
		this.asset_ID = asset_ID;
	}
	public Integer getAudit_ID() {
		return audit_ID;
	}
	public void setAudit_ID(Integer audit_ID) {
		this.audit_ID = audit_ID;
	}
	public String getAsset_no() {
		return asset_no;
	}
	public void setAsset_no(String asset_no) {
		this.asset_no = asset_no;
	}
	public Integer getDepreciation() {
		return depreciation;
	}
	public void setDepreciation(Integer depreciation) {
		this.depreciation = depreciation;
	}
	public String getAsset_dept() {
		return asset_dept;
	}
	public void setAsset_dept(String asset_dept) {
		this.asset_dept = asset_dept;
	}
	public String getAsset_location() {
		return asset_location;
	}
	public void setAsset_location(String asset_location) {
		this.asset_location = asset_location;
	}
	public String getAuditor_name() {
		return auditor_name;
	}
	public void setAuditor_name(String auditor_name) {
		this.auditor_name = auditor_name;
	}
	public String getAsset_custodian() {
		return asset_custodian;
	}
	public void setAsset_custodian(String asset_custodian) {
		this.asset_custodian = asset_custodian;
	}
	public Date getUsed_date() {
		return used_date;
	}
	public void setUsed_date(Date used_date) {
		this.used_date = used_date;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Integer getIs_delete() {
		return is_delete;
	}
	public void setIs_delete(Integer is_delete) {
		this.is_delete = is_delete;
	}
	public Asset getAsset() {
		return asset;
	}


	public void setAsset(Asset asset) {
		this.asset = asset;
	}
	@Override
	public String toString() {
		return "Audit [asset_ID=" + asset_ID + ", audit_ID=" + audit_ID + ", asset_no=" + asset_no + ", depreciation="
				+ depreciation + ", asset_dept=" + asset_dept + ", asset_location=" + asset_location + ", auditor_name="
				+ auditor_name + ", asset_custodian=" + asset_custodian + ", used_date=" + used_date + ", remarks="
				+ remarks + ", is_delete=" + is_delete + ", asset=" + asset + "]";
	}


	

}
