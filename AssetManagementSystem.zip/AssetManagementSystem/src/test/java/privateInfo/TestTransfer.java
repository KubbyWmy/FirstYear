package privateInfo;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.junit.Test;

import com.dawn.mapper.AuditMapper;
import com.dawn.mapper.TransferMapper;
import com.dawn.pojo.Audit;
import com.dawn.pojo.ProofTransfer;
import com.dawn.pojo.Transfer;

public class TestTransfer extends DatabaseTest{
	@Test
	public void testDataSource() throws SQLException{
		DataSource ds=ctx.getBean("dataSource",DataSource.class);
		Connection conn=ds.getConnection();
		DatabaseMetaData md=conn.getMetaData();
		System.out.println(md);
		String n=md.getDatabaseProductName();
		String v=md.getDatabaseProductVersion();
		System.out.println(n+v);
		conn.close();
	}
	/*mapper层*/

	@Test
	public void testaddAudit(){
		TransferMapper a=ctx.getBean("transferMapper",TransferMapper.class);
		Date date=new Date(2017, 2, 9);
	   Transfer  transfer=new Transfer(1, 2,  "浙江", "梁山", date, "用于分公司", "长期租用", "快递", "ll", "李四", "未知");
			   int i=a.addTransfer(transfer);
	     System.out.println(i);
	}
	

	@Test
	public void testdeleteTransfer(){
		TransferMapper a=ctx.getBean("transferMapper",TransferMapper.class);
			   int i=a.deleteTransfer(2);
	     System.out.println(i);
	}
	
	@Test
	public void testmodifyTransfer(){
		TransferMapper a=ctx.getBean("transferMapper",TransferMapper.class);
		Date date=new Date(2017, 2, 9);
		Transfer  transfer=new Transfer();
			   int i=a.modifyTransfer(transfer);
	     System.out.println(i);
	}
	
	@Test
	public void testqueryAllTransfer(){
		TransferMapper a=ctx.getBean("transferMapper",TransferMapper.class);
          List<Transfer> list=a.queryAllTransfer();
          for(Transfer l:list)
	     System.out.println(l);
	}
	@Test
	public void testqueryTransfer(){
		TransferMapper a=ctx.getBean("transferMapper",TransferMapper.class);
          Transfer transfer=a.queryTransfer(3);   
	     System.out.println(transfer);
	}
	
	@Test
	public void testaddTransferProof(){
		TransferMapper a=ctx.getBean("transferMapper",TransferMapper.class);
        ProofTransfer prooftransfer=new ProofTransfer(1, 2, "123/kk");  
		int  i=a.addTransferProof(prooftransfer);   
	     System.out.println(i);
	}
	
	@Test
	public void testqueryTransferProof(){
		TransferMapper a=ctx.getBean("transferMapper",TransferMapper.class);
       List<String> prooftransfer=a.queryTransferProof(3);
       for(String i:prooftransfer)
       System.out.println(i);
	}
	@Test
	public void testdeleteTransferproof(){
		TransferMapper a=ctx.getBean("transferMapper",TransferMapper.class);
      int i=a.deleteTransferproof(2);
       System.out.println(i);
	}
	
	
}
