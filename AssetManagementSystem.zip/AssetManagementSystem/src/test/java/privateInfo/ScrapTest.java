package privateInfo;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.junit.Test;
import com.dawn.mapper.ScrapMapper;
import com.dawn.pojo.ProofScrap;
import com.dawn.pojo.Scrap;

public class ScrapTest extends DatabaseTest{
	@Test
	public void testDataSource() throws SQLException{
		DataSource ds=ctx.getBean("dataSource",DataSource.class);
		Connection conn=ds.getConnection();
		DatabaseMetaData md=conn.getMetaData();
		System.out.println(md);
		String n=md.getDatabaseProductName();
		String v=md.getDatabaseProductVersion();
		System.out.println(n+v);
		conn.close();
	}
	@Test
	public void testaddScrap(){
		ScrapMapper a=ctx.getBean("scrapMapper",ScrapMapper.class);
		Date date=new Date(2015, 2, 3);
	    Scrap scrap=new Scrap(1, 2, "ss", "ass", "ssd");
		int i=a.addScrap(scrap);
		
	     System.out.println(i);
	}
	
	@Test
	public void testdeleteScrap(){
		ScrapMapper a=ctx.getBean("scrapMapper",ScrapMapper.class);
		int i=a.deleteScrap(1);
	     System.out.println(i);
	}
	@Test
	public void testmodifyScrap(){
		ScrapMapper a=ctx.getBean("scrapMapper",ScrapMapper.class);
		Scrap scrap=new Scrap(1, 2, "55", "888", "ssd");
		int i=a.modifyScrap(scrap);
	     System.out.println(i);
	}
	@Test
	public void testqueryAllScrap(){
		ScrapMapper a=ctx.getBean("scrapMapper",ScrapMapper.class);
		List<Scrap> scraps=a.queryAllScrap();
		for(Scrap list:scraps)
	     System.out.println(list);
	}
	@Test
	public void testqueryAssetScrap(){
		ScrapMapper a=ctx.getBean("scrapMapper",ScrapMapper.class);
		Scrap scraps=a.queryAssetScrap(2);
	     System.out.println(scraps);
	}
	
	@Test
	public void testaddProofScrap(){
		ScrapMapper a=ctx.getBean("scrapMapper",ScrapMapper.class);
		ProofScrap proofScrap=new ProofScrap(1, 2, "asd/asd");
		int i=a.addProofScrap(proofScrap);
	     System.out.println(i);
	}
	@Test
	public void testqueryProofScrap(){
		ScrapMapper a=ctx.getBean("scrapMapper",ScrapMapper.class);
		List<String> scraps=a.queryProofScrap(2);
		for(String list:scraps)
	     System.out.println(list);
	}
	@Test
	public void testdeleteProofScrap(){
		ScrapMapper a=ctx.getBean("scrapMapper",ScrapMapper.class);
		int i=a.deleteProofScrap(1);
	     System.out.println(i);
	}
}
