package com.dawn.service;


import javax.servlet.http.HttpServletRequest;

import com.dawn.pojo.ProofScrap;
import com.dawn.pojo.Scrap;
import com.dawn.util.JsonResult;

public interface ScrapService {
	public JsonResult addScrap(Scrap scrap);
	public JsonResult deleteScrap(Integer scrap_ID);
	public JsonResult modifyScrap(Scrap scrap);
	public JsonResult queryAllScrap();
	public JsonResult queryAssetScrap(Integer asset_ID);
	
	public JsonResult addProofScrap(ProofScrap proofScrap);
	//public List<String> queryProofScrap(Integer scrap_ID);
	public JsonResult queryProofScrap2(Integer scrap_ID,HttpServletRequest servletRequest);
	public JsonResult deleteProofScrap(ProofScrap proofScrap,HttpServletRequest servletRequest);
	
}