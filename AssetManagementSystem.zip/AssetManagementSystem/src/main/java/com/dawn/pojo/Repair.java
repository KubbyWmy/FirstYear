package com.dawn.pojo;

import java.sql.Date;
import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;

public class Repair {
	private Integer repair_ID;
	private Integer asset_ID;
   @JSONField(format="yyyy-mm-dd")
	private Date repair_time;
	private String repair_course;
	private String repair_process;
	private String repair_man;
	private Double repair_cost;
	private String repair_handler;
	private String remarks;
	private Integer is_delete;
	private List<ProofRepair> proofRepairs;
	private Asset asset;

	public Repair() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Repair(Integer repair_ID, Integer asset_ID, Date repair_time, String repair_course,
			String repair_process, String repair_man, Double repair_cost, String repair_handler, String remarks) {
		super();
		this.repair_ID = repair_ID;
		this.asset_ID = asset_ID;
		this.repair_time = repair_time;
		this.repair_course = repair_course;
		this.repair_process = repair_process;
		this.repair_man = repair_man;
		this.repair_cost = repair_cost;
		this.repair_handler = repair_handler;
		this.remarks = remarks;
	}

	

	public Repair(Integer repair_ID, Integer asset_ID, Date repair_time, String repair_course, String repair_process,
			String repair_man, Double repair_cost, String repair_handler, String remarks,
			List<ProofRepair> proofRepairs, Asset asset) {
		super();
		this.repair_ID = repair_ID;
		this.asset_ID = asset_ID;
		this.repair_time = repair_time;
		this.repair_course = repair_course;
		this.repair_process = repair_process;
		this.repair_man = repair_man;
		this.repair_cost = repair_cost;
		this.repair_handler = repair_handler;
		this.remarks = remarks;
		this.proofRepairs = proofRepairs;
		this.asset = asset;
	}

	public Asset getAsset() {
		return asset;
	}

	public void setAsset(Asset asset) {
		this.asset = asset;
	}

	public Integer getRepair_ID() {
		return repair_ID;
	}

	public void setRepair_ID(Integer repair_ID) {
		this.repair_ID = repair_ID;
	}

	public Integer getAsset_ID() {
		return asset_ID;
	}

	public void setAsset_ID(Integer asset_ID) {
		this.asset_ID = asset_ID;
	}


	public Date getRepair_time() {
		return repair_time;
	}

	public void setRepair_time(Date repair_time) {
		this.repair_time = repair_time;
	}

	public String getRepair_course() {
		return repair_course;
	}

	public void setRepair_course(String repair_course) {
		this.repair_course = repair_course;
	}

	public String getRepair_process() {
		return repair_process;
	}

	public void setRepair_process(String repair_process) {
		this.repair_process = repair_process;
	}

	public String getRepair_man() {
		return repair_man;
	}

	public void setRepair_man(String repair_man) {
		this.repair_man = repair_man;
	}

	public Double getRepair_cost() {
		return repair_cost;
	}

	public void setRepair_cost(Double repair_cost) {
		this.repair_cost = repair_cost;
	}

	public String getRepair_handler() {
		return repair_handler;
	}

	public void setRepair_handler(String repair_handler) {
		this.repair_handler = repair_handler;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Integer getIs_delete() {
		return is_delete;
	}

	public void setIs_delete(Integer is_delete) {
		this.is_delete = is_delete;
	}

	public List<ProofRepair> getProofRepairs() {
		return proofRepairs;
	}

	public void setProofRepairs(List<ProofRepair> proofRepairs) {
		this.proofRepairs = proofRepairs;
	}

	@Override
	public String toString() {
		return "Repair [repair_ID=" + repair_ID + ", asset_ID=" + asset_ID + ", repair_time=" + repair_time
				+ ", repair_course=" + repair_course + ", repair_process=" + repair_process + ", repair_man="
				+ repair_man + ", repair_cost=" + repair_cost + ", repair_handler=" + repair_handler + ", remarks="
				+ remarks + ", is_delete=" + is_delete + ", proofRepairs=" + proofRepairs + ", asset=" + asset + "]";
	}



}
