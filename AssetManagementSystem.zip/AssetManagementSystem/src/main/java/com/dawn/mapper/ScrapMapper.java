package com.dawn.mapper;

import java.util.List;

import com.dawn.pojo.ProofScrap;
import com.dawn.pojo.Scrap;

public interface ScrapMapper {
	public int addScrap(Scrap scrap);
	public int deleteScrap(Integer scrap_ID);
	public int modifyScrap(Scrap scrap);
	public List<Scrap> queryAllScrap();
	public Scrap queryAssetScrap(Integer asset_ID);
	
	public int addProofScrap(ProofScrap proofScrap);
	public List<String> queryProofScrap(Integer scrap_ID);
	public List<ProofScrap> queryProofScrap2(Integer scrap_ID);
	public int deleteProofScrap(Integer scrapProof_ID);
	public ProofScrap queryAScrapproof(Integer scrapProof_ID);
}
