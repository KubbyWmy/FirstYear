$(function(){
	var url='http://localhost:8080/StudentSystem/student/showAllAttendance.do';
	var template='<tr class="pending-user">'+
	'<td>studentId</td>'+
	'<td>studentName</td>'+
	'<td>studentClass</td>'+
	'<td><span class="label label-important">已签到</span></td>'+
	'<td>attendTime</td>'+
'</tr>';
	$.post(url,function(result){
		if(result.state){
			console.log(result);
			var studentInfo=result.data;
			for(var i=0;i<studentInfo.length;i++){
				console.log(studentInfo[i].attendTime);
				var tr=template.replace('studentId',studentInfo[i].student.studentId)
								.replace('studentName',studentInfo[i].student.studentName)
								.replace('studentClass',studentInfo[i].student.studentClass)
								.replace('attendTime',studentInfo[i].attendTime);
				$('#indexBody').append(tr);
			}
		}
	});
});