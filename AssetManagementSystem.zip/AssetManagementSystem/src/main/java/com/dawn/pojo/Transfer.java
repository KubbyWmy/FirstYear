package com.dawn.pojo;

import java.sql.Date;
import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;

public class Transfer {
  private Integer transfer_ID;
  private Integer asset_ID;
  private String transfer_dept;
  private String receiving_dept;
  @JSONField(format="yyyy-mm-dd")
  private Date transfer_date;
  private String purpose;
  private String property;
  private String transfer_mode;
  private String transfer_handler;
  private String receiving_handler;
  private Integer is_delete;
  private String remarks;
  private List<ProofTransfer> proofTransfers;
  private Asset asset;
  
public Transfer() {
	super();
}
//用于信息添加

public Transfer(Integer transfer_ID, Integer asset_ID, String transfer_dept,
		String receiving_dept, Date transfer_date, String purpose, String property, String transfer_mode,
		String transfer_handler, String receiving_handler, String remarks) {
	super();
	this.transfer_ID = transfer_ID;
	this.asset_ID = asset_ID;
	this.transfer_dept = transfer_dept;
	this.receiving_dept = receiving_dept;
	this.transfer_date = transfer_date;
	this.purpose = purpose;
	this.property = property;
	this.transfer_mode = transfer_mode;
	this.transfer_handler = transfer_handler;
	this.receiving_handler = receiving_handler;
	this.remarks = remarks;
}


public Transfer(Integer transfer_ID, Integer asset_ID, String transfer_dept, String receiving_dept,
		Date transfer_date, String purpose, String property, String transfer_mode, String transfer_handler,
		String receiving_handler, String remarks, List<ProofTransfer> proofTransfers, Asset asset) {
	super();
	this.transfer_ID = transfer_ID;
	this.asset_ID = asset_ID;
	this.transfer_dept = transfer_dept;
	this.receiving_dept = receiving_dept;
	this.transfer_date = transfer_date;
	this.purpose = purpose;
	this.property = property;
	this.transfer_mode = transfer_mode;
	this.transfer_handler = transfer_handler;
	this.receiving_handler = receiving_handler;
	this.remarks = remarks;
	this.proofTransfers = proofTransfers;
	this.asset = asset;
}
public Integer getTransfer_ID() {
	return transfer_ID;
}

public void setTransfer_ID(Integer transfer_ID) {
	this.transfer_ID = transfer_ID;
}

public Integer getAsset_ID() {
	return asset_ID;
}

public void setAsset_ID(Integer asset_ID) {
	this.asset_ID = asset_ID;
}




public String getTransfer_dept() {
	return transfer_dept;
}

public void setTransfer_dept(String transfer_dept) {
	this.transfer_dept = transfer_dept;
}

public String getReceiving_dept() {
	return receiving_dept;
}

public void setReceiving_dept(String receiving_dept) {
	this.receiving_dept = receiving_dept;
}

public Date getTransfer_date() {
	return transfer_date;
}

public void setTransfer_date(Date transfer_date) {
	this.transfer_date = transfer_date;
}

public String getPurpose() {
	return purpose;
}

public void setPurpose(String purpose) {
	this.purpose = purpose;
}

public String getProperty() {
	return property;
}

public void setProperty(String property) {
	this.property = property;
}

public String getTransfer_mode() {
	return transfer_mode;
}

public void setTransfer_mode(String transfer_mode) {
	this.transfer_mode = transfer_mode;
}

public String getTransfer_handler() {
	return transfer_handler;
}

public void setTransfer_handler(String transfer_handler) {
	this.transfer_handler = transfer_handler;
}

public String getReceiving_handler() {
	return receiving_handler;
}

public void setReceiving_handler(String receiving_handler) {
	this.receiving_handler = receiving_handler;
}

public Integer getIs_delete() {
	return is_delete;
}

public void setIs_delete(Integer is_delete) {
	this.is_delete = is_delete;
}

public String getRemarks() {
	return remarks;
}

public void setRemarks(String remarks) {
	this.remarks = remarks;
}

public List<ProofTransfer> getProofTransfers() {
	return proofTransfers;
}

public void setProofTransfers(List<ProofTransfer> proofTransfers) {
	this.proofTransfers = proofTransfers;
}

public Asset getAsset() {
	return asset;
}

public void setAsset(Asset asset) {
	this.asset = asset;
}

@Override
public String toString() {
	return "Transfer [transfer_ID=" + transfer_ID + ", asset_ID=" + asset_ID + ", transfer_dept=" + transfer_dept
			+ ", receiving_dept=" + receiving_dept + ", transfer_date=" + transfer_date + ", purpose=" + purpose
			+ ", property=" + property + ", transfer_mode=" + transfer_mode + ", transfer_handler=" + transfer_handler
			+ ", receiving_handler=" + receiving_handler + ", is_delete=" + is_delete + ", remarks=" + remarks
			+ ", proofTransfers=" + proofTransfers + ", asset=" + asset + "]";
}




//用于信息查询





 
}
