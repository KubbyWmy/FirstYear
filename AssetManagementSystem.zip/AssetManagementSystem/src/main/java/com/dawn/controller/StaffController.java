package com.dawn.controller;


import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dawn.service.StaffException;
import com.dawn.service.StaffService;
import com.dawn.util.JsonResult;

@Controller
@RequestMapping("/staff")
public class StaffController {
	@Resource
	private StaffService service;
	@ResponseBody
	@RequestMapping("/findStaff.do")
	public JsonResult findStaff(String staff_id) {
		
		return new JsonResult(service.findStaffById(staff_id));
	}
	@ResponseBody
	@RequestMapping("/changeStaffPwdById.do")
	public JsonResult changeStaffPwdById(String staff_id,String oldPwd,String pwd) {
		
		return new JsonResult(service.changeStaffPwd(staff_id, oldPwd, pwd));
	}
	@ResponseBody
	@RequestMapping("/addStaff.do")
	public JsonResult addStaff(String staff_id, String staff_name, String staff_pwd, String staff_dept, String staff_position,
			String contact_way, String role_ID) {
		
		return new JsonResult(service.addStaff(staff_id, staff_name, staff_pwd, staff_dept, staff_position, contact_way, Integer.parseInt(role_ID)));
	}
	
	@ResponseBody
	@RequestMapping("/deleteStaff.do")
	public JsonResult deleteStaff(String staff_id,String handle_id) {
		
		return service.deleteStaff(staff_id,handle_id);
	}
	@ResponseBody
	@RequestMapping("/showAllStaffInfo.do")
	public JsonResult showStaffInfo() {
		
		return new JsonResult(service.showStaffInfo());
	}
	@ResponseBody
	@RequestMapping("/changeStaffInfo.do")
	public JsonResult changeStaffInfo(String staff_id, String staff_name, String pwd, String staff_dept, String staff_position,
			String contact_way, Integer role_id) {
		
		return service.changeStaffInfo(staff_id, staff_name, pwd, staff_dept, staff_position, contact_way, role_id);
	}
	@ResponseBody
	@RequestMapping("/saveStaffInfo.do")
	public JsonResult changeStaffInfo(String staff_id,  String staff_position,
			String contact_way) {
		
		return service.saveStaffInfo(staff_id, staff_position, contact_way);
	}
	
	
	@ExceptionHandler(StaffException.class)
	@ResponseBody
	public Object pwdexp(StaffException e){
		e.printStackTrace();
		return new JsonResult(0, e);
	}
}

