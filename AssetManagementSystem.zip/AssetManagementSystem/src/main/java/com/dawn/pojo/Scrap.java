package com.dawn.pojo;

import java.util.List;

public class Scrap {
	private Integer scrap_ID;
	private Integer asset_ID;
	private String disposal_method ;
	private String scrap_handler;
	private Integer is_delete;
	private String remarks;
	private List<ProofScrap> proofScraps;
	private Asset asset;
	private Audit audit;
		
	public Scrap() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Scrap(Integer scrap_ID, Integer asset_ID,String disposal_method, String scrap_handler,
			String remarks) {
		super();
		this.scrap_ID = scrap_ID;
		this.asset_ID = asset_ID;
		this.disposal_method = disposal_method;
		this.scrap_handler = scrap_handler;
		this.remarks = remarks;
	}



	

	public Audit getAudit() {
		return audit;
	}

	public void setAudit(Audit audit) {
		this.audit = audit;
	}

	public Scrap(Integer scrap_ID, Integer asset_ID, String disposal_method, String scrap_handler, Integer is_delete,
			String remarks, List<ProofScrap> proofScraps, Asset asset, Audit audit) {
		super();
		this.scrap_ID = scrap_ID;
		this.asset_ID = asset_ID;
		this.disposal_method = disposal_method;
		this.scrap_handler = scrap_handler;
		this.is_delete = is_delete;
		this.remarks = remarks;
		this.proofScraps = proofScraps;
		this.asset = asset;
		this.audit = audit;
	}

	public Integer getScrap_ID() {
		return scrap_ID;
	}

	public void setScrap_ID(Integer scrap_ID) {
		this.scrap_ID = scrap_ID;
	}

	public Integer getAsset_ID() {
		return asset_ID;
	}

	public void setAsset_ID(Integer asset_ID) {
		this.asset_ID = asset_ID;
	}

	

	public String getDisposal_method() {
		return disposal_method;
	}

	public void setDisposal_method(String disposal_method) {
		this.disposal_method = disposal_method;
	}

	public String getScrap_handler() {
		return scrap_handler;
	}

	public void setScrap_handler(String scrap_handler) {
		this.scrap_handler = scrap_handler;
	}

	public Integer getIs_delete() {
		return is_delete;
	}

	public void setIs_delete(Integer is_delete) {
		this.is_delete = is_delete;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public List<ProofScrap> getProofScraps() {
		return proofScraps;
	}

	public void setProofScraps(List<ProofScrap> proofScraps) {
		this.proofScraps = proofScraps;
	}

	public Asset getAsset() {
		return asset;
	}

	public void setAsset(Asset asset) {
		this.asset = asset;
	}

	@Override
	public String toString() {
		return "Scrap [scrap_ID=" + scrap_ID + ", asset_ID=" + asset_ID + ", disposal_method=" + disposal_method
				+ ", scrap_handler=" + scrap_handler + ", is_delete=" + is_delete + ", remarks=" + remarks
				+ ", proofScraps=" + proofScraps + ", asset=" + asset + "]";
	}

	
}
