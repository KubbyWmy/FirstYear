package com.dawn.service;

import java.util.List;

import com.dawn.pojo.Staff;
import com.dawn.util.JsonResult;

public interface StaffService {
	Staff findStaffById(String id) throws StaffException;
	int changeStaffPwd(String i,String oldPwd,String Pwd) throws StaffException;
	int addStaff(String staff_id,String staff_name,
			String staff_pwd,String staff_dept,String staff_position,
			String contact_way,Integer role_ID)throws StaffException;
	JsonResult deleteStaff(String staff_id,String handle_id) throws StaffException;
	List<Staff> showStaffInfo() throws StaffException;
	JsonResult changeStaffInfo(String staff_id,String staff_name,String pwd,
			String staff_dept,String staff_position,
			String contact_way,Integer role_id)throws StaffException;
	JsonResult saveStaffInfo(String staff_id,String staff_position,
			String contact_way)throws StaffException;
}
