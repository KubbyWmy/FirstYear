function addStudent(){
	var url='http://localhost:8080/StudentSystem/student/add.do';
	var param={studentId:$("#studentId").val(),
				studentName:$("#studentName").val(),
				studentClass:$("#studentClass").val()};
	$.post(url,param,function(result){
		if(result.state){
			location.href="roles.html";
		}else{
			alert(result.message);
		}
	})
}