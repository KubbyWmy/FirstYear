package cs.web;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cs.entity.Info;
import cs.service.InfoException;
import cs.service.InfoService;
import cs.util.JsonResult;

@Controller
@RequestMapping("/info")
public class InfoController {
	@Resource
	private InfoService service;
	
	@RequestMapping("/list.do")
	@ResponseBody
	public JsonResult<List<Map<String,Object>>> list(String user_id){
		List<Map<String,Object>> list=service.listInfo(user_id);
		return new JsonResult<List<Map<String,Object>>>(list);
	}
	
	@RequestMapping("/remove.do")
	@ResponseBody
	public int remove(int creatime){
		return service.removeInfo(creatime);
	}
	@RequestMapping("/write.do")
	@ResponseBody
	public Info write(int creatime) throws InfoException, IOException{
		
		return service.writeInfo(creatime);
	}
	@RequestMapping("/autoWrite.do")
	@ResponseBody
	public Info autoWrite(String user_id) throws InfoException, IOException{
		service.autoWrite(user_id);
		return null;
	}
	@RequestMapping("/add.do")
	@ResponseBody
	public JsonResult<Info> add(String user_id, int air, int water, int sun, int fert, int temp){
		Info info=service.addInfo(user_id, air, water, sun, fert, temp);
		return new JsonResult<Info>(info);
	}
	
}
