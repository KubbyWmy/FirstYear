
var SUCCESS = 0;

$(function(){
	//1. 绑定 登录 按钮
	//2. 在按键被点击时候获取 用户名和密码
	//3. 检查用户名和密码 是否符合规则 ??
	//4. 如何符合规则就向服务器发送
	//5. 处理服务器返回的结果(成功/失败)
	
	//绑定登录界面的事件
	$('#login').click(loginAction); 
	$('#id').blur(checkName);
	$('#pwd').blur(checkPassword);
	
	//绑定注册界面的事件
	$('#reg_id').blur(checkRegistName);
	$('#reg_pwd').blur(checkRegistPassword);
	$('#reg_confirm').blur(checkConfirmPassword);
	$('#regist_button').click(registAction);
	
	//绑定修改用户界面
	$('#password1').blur(checkUpdatePassword);
	$('#password2').blur(checkUpdateConfirmPassword);
	$('#save_button').click(saveAction);
	var max=getCookie("maxLines");
	$('#maxLine').html(max);
});

function checkName(){
	var name = $('#id').val();
	var reg = /^\w{3,10}$/;
	$('#id-msg').empty();
	if(! reg.test(name)){
		console.log(1);
		$('#id-msg').append("6~10个字符");
		return false;
	}
	return true;
}
function checkPassword(){
	var pwd = $('#pwd').val();
	var reg = /^\w{6,10}$/;
	$('#pwd-msg').empty();
	if(! reg.test(pwd)){
		$('#pwd-msg').append("6~10个字符");
		return false;
	}
	return true;
}

function loginAction(){
	//console.log("Login Action!");
	var id = $('#id').val();
	var pwd = $('#pwd').val();
	//检查用户名和密码的规则
	var n = checkName() + checkPassword();
	if(n!=2){
		return;
	}
	//向服务器发送用户名和密码
	var url="user/login.do";
	//data中的key与服务端控制器参数名一致
	//data中的值来源于页面表单中的数据
	var data={'id':id,'pwd':pwd};
	$.post(url, data, function(result){
		//服务器返回result 是JsonResult序列化的
		//结果. result: {state:0,data:...,message:...}
		//console.log(result);
		if(result.state==SUCCESS){
			//登录成功
			//跳转到 edit.html
			console.log(result.data);
			
			//登录成功之后id保存到cookie
			var id=result.data.id;
			setCookie("id",id);
			var ccc=getCookie("id");
			var update_username=result.data.username;
			var update_email=result.data.email;
			var update_pwd=result.data.pwd;
			setCookie("update_username",update_username);
			setCookie("update_email",update_email);
			setCookie("update_pwd", update_pwd);
			console.log(getCookie("update_pwd"));
			console.log(update_email);
			$('#head_username').html(ccc);
			location.href='index.jsp';
		}else{
			//显示错误消息
			var msg=result.message;
			console.log(msg);
			$('#msg').html(msg);
		}
	});
}


function  checkRegistName(){
	console.log("checkRegistName");
	var name = $('#reg_id').val();
	var reg = /^\w{3,10}$/;
	$('#warning_1').empty();
	if(! reg.test(name)){
		console.log(1);
		$('#warning_1').append("3~10个字符");
		return false;
	}
	return true;
}

function  checkRegistPassword(){
	console.log("checkRegistPassword");
	var pwd=$('#reg_pwd').val();
	var reg=/^\w{6,10}$/;
	$('#warning_2').empty();
	if(reg.test(pwd)){
		return true;
	}
	$('#warning_2').html('6~10字符');
	return false;
}

function  checkConfirmPassword(){
	console.log("reg_confirm");
	var pwd=$('#reg_pwd').val();
	var pwd2=$('#reg_confirm').val();
	$('#warning_3').empty();
	if(pwd != "" && pwd==pwd2){
		return true;
	}
	$('#warning_3').html('密码不一致');
	return false;

}

function registAction(){
	var n = checkRegistName()+
			checkRegistPassword()+
			checkConfirmPassword();
	if(n!=3){
		return;
	}
	var name=$('#reg_id').val();
	var pwd=$('#reg_pwd').val();
	var pwd2=$('#reg_confirm').val();
	
	var url='user/regist.do';
	var data = {id:name,pwd:pwd,
			confirm:pwd2};
	console.log(data);
	
	$.post(url, data, function(result){
		console.log(result);
		if(result.state==SUCCESS){
			alert("注册成功");
			location.href="login.jsp";
		}else{
			var msg=result.message;
			$('#warning_4').html(msg);
		}
	});
}
//密码重置检查项
function  checkUpdatePassword(){
	console.log("checkRegistPassword");
	var pwd=$('#password1').val();
	var reg=/^\w{6,10}$/;
	$('#update_password1').empty();
	if(reg.test(pwd)){
		return true;
	}
	$('#update_password1').html('6~10字符');
	return false;
}

function  checkUpdateConfirmPassword(){
	console.log("reg_confirm");
	var pwd=$('#password1').val();
	var pwd2=$('#password2').val();
	$('#update_password2').empty();
	if(pwd != "" && pwd==pwd2){
		return true;
	}
	$('#update_password2').html('密码不一致');
	return false;

}
//用户信息更改保存操作
function saveAction(){
	
	var id=getCookie("id");
	var pwd=$('#password2').val();
	var update_username1=$('#lastname').val();
	var email=$('#email').val();
	var url='user/update.do';
	var data = {id:id,pwd:pwd,username:update_username1,
			email:email};
	$.post(url, data, function(result){
		console.log(result);
		if(result.state==SUCCESS){
			alert("修改成功");
			setCookie("update_username",update_username1);
			setCookie("update_email",email);
			setCookie("update_pwd", pwd);
			var a=getCookie("update_username");
			console.log(a);
			location.href="account.jsp";
		}else{
			console.log(1);
			var msg=result.message;
			$('#warning_update').html(msg);
		}
	});
	
}









