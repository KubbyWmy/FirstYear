package com.dawn.controller;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
@RequestMapping(value="/photo")
public class FileUpload {
	@RequestMapping(value="/doUpload", method=RequestMethod.POST)
	public String doUploadFile(@RequestParam("file") MultipartFile file){

		if(!file.isEmpty()){
			try {
				
				//���ｫ�ϴ��õ����ļ������� d:\\temp\\file Ŀ¼
				FileUtils.copyInputStreamToFile(file.getInputStream(), new File("d:\\temp\\file\\", 
						System.currentTimeMillis()+ file.getOriginalFilename()));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		return "success";  //�ϴ��ɹ�����ת����success.jspҳ��
	}
	
	
	
	@RequestMapping(value="/upload", method=RequestMethod.GET)
	public String showUploadPage(){	
		return "uploadFile";		 //view�ļ����µ��ϴ������ļ���ҳ��
	}
	
}
