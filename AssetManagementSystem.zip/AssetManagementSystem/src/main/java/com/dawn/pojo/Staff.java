package com.dawn.pojo;


/*
 *creator: lyj
 *
 * */
public class Staff {
	private String staff_ID;
	private String staff_name;
	private String staff_pwd;
	private String staff_dept;
	private String staff_position;
	private String contact_way;
	private Role role;
	private int role_ID;
	private Integer is_delete;
	private String token;
	
	public Staff() {
		super();
	}

	public Staff(String staff_ID, String staff_name, String staff_pwd, String staff_dept, String staff_position,
			String contact_way, int role_ID, Integer is_delete) {
		super();
		this.staff_ID = staff_ID;
		this.staff_name = staff_name;
		this.staff_pwd = staff_pwd;
		this.staff_dept = staff_dept;
		this.staff_position = staff_position;
		this.contact_way = contact_way;
		this.role_ID = role_ID;
		this.is_delete = is_delete;
	}
	

	public String getStaff_ID() {
		return staff_ID;
	}

	public void setStaff_ID(String staff_ID) {
		this.staff_ID = staff_ID;
	}

	public String getStaff_name() {
		return staff_name;
	}

	public void setStaff_name(String staff_name) {
		this.staff_name = staff_name;
	}

	public String getStaff_pwd() {
		return staff_pwd;
	}

	public void setStaff_pwd(String staff_pwd) {
		this.staff_pwd = staff_pwd;
	}

	public String getStaff_dept() {
		return staff_dept;
	}

	public void setStaff_dept(String staff_dept) {
		this.staff_dept = staff_dept;
	}

	public String getStaff_position() {
		return staff_position;
	}

	public void setStaff_position(String staff_position) {
		this.staff_position = staff_position;
	}

	public String getContact_way() {
		return contact_way;
	}

	public void setContact_way(String contact_way) {
		this.contact_way = contact_way;
	}

	public int getRole_ID() {
		return role_ID;
	}

	public void setRole_ID(int role_ID) {
		this.role_ID = role_ID;
	}

	public Integer getIs_delete() {
		return is_delete;
	}

	public void setIs_delete(Integer is_delete) {
		this.is_delete = is_delete;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	@Override
	public String toString() {
		return "Staff [staff_ID=" + staff_ID + ", staff_name=" + staff_name + ", staff_pwd=" + staff_pwd
				+ ", staff_dept=" + staff_dept + ", staff_position=" + staff_position + ", contact_way=" + contact_way
				+ ", role=" + role + ", role_ID=" + role_ID + ", is_delete=" + is_delete + ", token=" + token + "]";
	}


}
