package com.dawn.mapper;

import java.util.List;

import com.dawn.pojo.Status;

public interface StatusMapper {
public int addStatus(Status status);
public int deleteStatus(Integer status_ID);
public int modifyStatus(Status status);
public List<Status> queryAllStatus();
public Status queryOneAssetStatus(Integer status_ID);


}
