package com.dawn.exception;

public class IllegalInputException {

}
