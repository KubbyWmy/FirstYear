package com.dawn.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.dawn.mapper.InventoryMapper;
import com.dawn.pojo.Inventory;

public class InventoryUtil {

	public static String getNo(Integer asset_ID) {
		String str2 = "YF";
		Date date = new Date();
		String str3 = new SimpleDateFormat("yyyyMMdd").format(date);
		String str = str2 + str3 + asset_ID;
		return str;

	}

	public static Map<String, Object> getInventory(Inventory inventory) {
		Double asset_price = inventory.getAsset().getAsset_price();
		int depreciation = inventory.getAudit().getDepreciation();
		Double money = asset_price * 0.95 / (depreciation * 12) * 12;
		Date used_date = inventory.getAudit().getUsed_date();
		int m = InventoryUtil.getMonthDifference(used_date);
		Double accumulated = money / 12 * m;
		Map<String, Object> map = new HashMap<String, Object>();
		String inventoryNo = InventoryUtil.getNo(inventory.getAsset().getAsset_ID());
		map.put("inventoryNo", inventoryNo);
		map.put("asset_name", inventory.getAsset().getAsset_name());
		map.put("specifications", inventory.getAsset().getSpecifications());
		map.put("PN", inventory.getAsset().getPN());
		map.put("SN", inventory.getAsset().getSN());
		map.put("asset_class", inventory.getAsset().getAsset_class());
		map.put("asset_price", asset_price);
		map.put("asset_no", inventory.getAudit().getAsset_no());
		map.put("depreciation", depreciation);
		map.put("asset_dept", inventory.getAudit().getAsset_dept());
		map.put("asset_location", inventory.getAudit().getAsset_location());
		map.put("bookQuantity", 1);
		map.put("actualQuantity", 1);
		map.put("used_date", used_date);
		map.put("money", money);
		map.put("accumulated", accumulated);
		return map;

	}

	public static int getMonthDifference(Date date) {
		String lastDate = new SimpleDateFormat("yyyy-MM-dd").format(date);
		String nowDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
		String[] arry = lastDate.split("-");
		String[] arry2 = nowDate.split("-");
		int year = Integer.parseInt(arry[0]);
		int month = Integer.parseInt(arry[1]);
		int year2 = Integer.parseInt(arry2[0]);
		int month2 = Integer.parseInt(arry2[1]);
		int y = year2 - year;
		if (y == 0) {
			return month2 - month;
		}
		return y * 12 - month + month2;

	}

}
