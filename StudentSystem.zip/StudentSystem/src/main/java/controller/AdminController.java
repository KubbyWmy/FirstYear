package controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import service.AdminException;
import service.AdminService;
import util.JsonResult;

@Controller
@RequestMapping("/admin")
public class AdminController {
	@Resource
	private AdminService service;
	@ResponseBody
	@RequestMapping("/login.do")
	public JsonResult login(String adminId,String pwd){
		return new JsonResult(service.login(adminId, pwd));
	}
	@ExceptionHandler(AdminException.class)
	@ResponseBody
	public Object studentExp(AdminException e){
		return new JsonResult(0, e);
	}
}
