package com.dawn.pojo;
import java.sql.Date;

import com.alibaba.fastjson.annotation.JSONField;
public class Status {
  private Integer status_ID;
  private Integer asset_ID;
  @JSONField(format="yyyy-mm-dd")
  private Date check_date;
  private String device_status;
  private String status_handler;
  private Integer is_delete;
  private String remarks;
  private Asset asset;
 
public Status() {
	super();
	// TODO Auto-generated constructor stub
}

public Status(Integer status_ID, Integer asset_ID,Date check_date, String device_status,
		String status_handler, String remarks) {
	super();
	this.status_ID = status_ID;
	this.asset_ID = asset_ID;
	this.check_date = check_date;
	this.device_status = device_status;
	this.status_handler = status_handler;
	this.remarks = remarks;
}

public Status(Integer status_ID, Integer asset_ID, Date check_date, String device_status, String status_handler,
		String remarks, Asset asset) {
	super();
	this.status_ID = status_ID;
	this.asset_ID = asset_ID;
	this.check_date = check_date;
	this.device_status = device_status;
	this.status_handler = status_handler;
	this.remarks = remarks;
	this.asset = asset;
}

public Integer getStatus_ID() {
	return status_ID;
}

public void setStatus_ID(Integer status_ID) {
	this.status_ID = status_ID;
}

public Integer getAsset_ID() {
	return asset_ID;
}

public void setAsset_ID(Integer asset_ID) {
	this.asset_ID = asset_ID;
}
public Date getCheck_date() {
	return check_date;
}

public void setCheck_date(Date check_date) {
	this.check_date = check_date;
}

public String getDevice_status() {
	return device_status;
}

public void setDevice_status(String device_status) {
	this.device_status = device_status;
}

public String getStatus_handler() {
	return status_handler;
}

public void setStatus_handler(String status_handler) {
	this.status_handler = status_handler;
}

public Integer getIs_delete() {
	return is_delete;
}

public void setIs_delete(Integer is_delete) {
	this.is_delete = is_delete;
}

public String getRemarks() {
	return remarks;
}

public void setRemarks(String remarks) {
	this.remarks = remarks;
}

public Asset getAsset() {
	return asset;
}

public void setAsset(Asset asset) {
	this.asset = asset;
}

@Override
public String toString() {
	return "Status [status_ID=" + status_ID + ", asset_ID=" + asset_ID + ", check_date=" + check_date
			+ ", device_status=" + device_status + ", status_handler=" + status_handler + ", is_delete=" + is_delete
			+ ", remarks=" + remarks + ", asset=" + asset + "]";
}




}
