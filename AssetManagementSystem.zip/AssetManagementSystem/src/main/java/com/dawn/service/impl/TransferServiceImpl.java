package com.dawn.service.impl;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import com.dawn.mapper.TransferMapper;
import com.dawn.pojo.ProofTransfer;
import com.dawn.pojo.Transfer;
import com.dawn.service.TransferService;
import com.dawn.util.JsonResult;
import com.dawn.util.PhotoUpload;
@Service
public class TransferServiceImpl implements TransferService{
@Resource
private TransferMapper transferMapper;

	public JsonResult addTransfer(Transfer transfer) {
		
		if(transferMapper.addTransfer(transfer)>0) return new JsonResult(1,null,"添加成功");
		return new JsonResult(0,new Throwable("添加失败"));
	}

	public JsonResult deleteTransfer(Integer transfer_ID) {
		// TODO Auto-generated method stub
		if(transferMapper.deleteTransfer(transfer_ID)>0){
			List<Transfer> list=transferMapper.queryAllTransfer();
			return new JsonResult(1,list,"删除成功");
		}
		return new JsonResult(0,new Throwable("删除失败"));
	}

	public JsonResult modifyTransfer(Transfer transfer) {
      if(transferMapper.modifyTransfer(transfer)>0) return new JsonResult(1,transferMapper.queryTransfer(transfer.getTransfer_ID()),"修改成功");
		return new JsonResult(0,new Throwable("修改失败"));
	}

	public JsonResult queryTransfer(Integer transfer_ID) {
		Transfer transfer=transferMapper.queryTransfer(transfer_ID);
		if(transfer==null) return new JsonResult(0,new Throwable("该数据不存在"));
		return new JsonResult(1,transfer,"查询成功") ;
	}

	public JsonResult queryAllTransfer() {
		// TODO Auto-generated method stub
		List<Transfer> list=transferMapper.queryAllTransfer();
		if(list.isEmpty()) return new JsonResult(0,new Throwable("该数据不存在"));
		return new JsonResult(1,list,"查询成功");
	}

	public JsonResult addTransferProof(ProofTransfer prooftransfer) {
		// TODO Auto-generated method stub
		if(transferMapper.addTransferProof(prooftransfer)>0) return new JsonResult(1,null,"添加图片成功");
		return new JsonResult(0,new Throwable("添加图片失败"));
	}

	/*public List<String> queryTransferProof(Integer transfer_ID) {
		System.out.println("do");
		List<String> s=transferMapper.queryTransferProof(transfer_ID);
		for(String list:s)
		System.out.println(list);
         System.out.println("end");
		return transferMapper.queryTransferProof(transfer_ID);
	}*/

	public JsonResult deleteTransferproof(ProofTransfer proofTransfer,HttpServletRequest servletRequest) {
		// TODO Auto-generated method stub
		 if(transferMapper.deleteTransferproof(proofTransfer.getTransferProof_ID())>0){
			 List<ProofTransfer> list=transferMapper.queryTransferProof2(proofTransfer.getTransfer_ID());
				if(list.isEmpty()) return new JsonResult(0,new Throwable("数据不存在"));
				for(ProofTransfer proofTransfer2:list){
					String url=PhotoUpload.getUrl(servletRequest)+proofTransfer2.getTransfer_url();
					  String url2=url.replace("\\", "/");
					  proofTransfer.setTransfer_url(url2);
				}
			 return new JsonResult(1,list,"删除成功");
		 }
		 else{
			 List<ProofTransfer> list=transferMapper.queryTransferProof2(proofTransfer.getTransfer_ID());
				if(list.isEmpty()) return new JsonResult(0,new Throwable("数据不存在"));
				for(ProofTransfer proofTransfer2:list){
					String url=PhotoUpload.getUrl(servletRequest)+proofTransfer2.getTransfer_url();
					  String url2=url.replace("\\", "/");
					  proofTransfer.setTransfer_url(url2);
				}
				 return new JsonResult(1,list,"删除成功");
		 }
		
	}

	public JsonResult queryTransferProof2(Integer transfer_ID,HttpServletRequest servletRequest) {
		// TODO Auto-generated method stub
		List<ProofTransfer> list=transferMapper.queryTransferProof2(transfer_ID);
		if(list.isEmpty()) return new JsonResult(0,new Throwable("数据不存在"));
		for(ProofTransfer proofTransfer:list){
			String url=PhotoUpload.getUrl(servletRequest)+proofTransfer.getTransfer_url();
			  String url2=url.replace("\\", "/");
			  proofTransfer.setTransfer_url(url2);
		}
		return new JsonResult(1,list,"查询成功");
	}

	public JsonResult queryOneTransferProof(Integer transferProof_ID,HttpServletRequest servletRequest) {
		// TODO Auto-generated method stub
	ProofTransfer proofTransfer=transferMapper.queryOneTransferProof(transferProof_ID);
		if(proofTransfer==null) return new JsonResult(0,proofTransfer,"数据不存在");
		  String url=PhotoUpload.getUrl(servletRequest)+proofTransfer.getTransfer_url();
		  String url2=url.replace("\\", "/");
		  proofTransfer.setTransfer_url(url2);
		return new JsonResult(1,proofTransfer,"查询成功");
	}

}
