package cs.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import cs.entity.Info;

public interface InfoService {
	List<Map<String, Object>> listInfo(String user_id) throws UserException;
	int removeInfo(int creatime) throws InfoException;
	Info writeInfo(int creatime) throws InfoException, FileNotFoundException, IOException;
	Info addInfo(String user_id,int air,int water,int sun,int fert,int temp) throws InfoException;
	Info autoWrite(String user_id) throws InfoException, FileNotFoundException, IOException;
}
