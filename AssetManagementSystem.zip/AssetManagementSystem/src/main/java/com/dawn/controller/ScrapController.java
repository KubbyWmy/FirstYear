 package com.dawn.controller;

import java.io.File;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.dawn.pojo.ProofScrap;
import com.dawn.pojo.Scrap;
import com.dawn.service.ScrapService;
import com.dawn.util.JsonResult;
import com.dawn.util.PhotoUpload;

@Controller
@RequestMapping(value="/scrap")
public class ScrapController {

	//定义常量,1为操作成功,0为失败.
	private static int SUCCESS=1;
	private static int FAIL=0;
	@Resource
	private ScrapService scrapService;
	@RequestMapping("/add.do")
	@ResponseBody
	public  JsonResult addScrap(@RequestBody Scrap scrap){
		if(scrap==null) 
			return  new JsonResult(0,new Throwable("参数不能为空"));
		return scrapService.addScrap(scrap);
	}
	@RequestMapping("/modify.do")
	@ResponseBody
	public  JsonResult modifyScrap(@RequestBody Scrap scrap){
		if(scrap==null) 
			return  new JsonResult(0,new Throwable("参数不能为空"));
		return  scrapService.modifyScrap(scrap);
	}
	@RequestMapping("/delete.do")
	@ResponseBody
	public  JsonResult deleteScrap(Integer scrap_ID){
		if(scrap_ID==null) 
			return  new JsonResult(0,new Throwable("参数不能为空"));
		return scrapService.deleteScrap(scrap_ID);
	}
	
	@RequestMapping("/queryAll.do")
	@ResponseBody
	public  JsonResult queryAll(){
		return scrapService.queryAllScrap();
	}
	@RequestMapping("/queryOne.do")
	@ResponseBody
	public  JsonResult queryOneScrap(Integer asset_ID){
		return scrapService.queryAssetScrap(asset_ID);
	}
	
	/*添加证明材料*/
	@RequestMapping("/addProof.do")
	@ResponseBody
	public  JsonResult addTransferProof(@RequestParam(value = "file", required = false) MultipartFile file, ProofScrap proofScrap,
	HttpServletRequest request){
		String  url="addPhoto"+File.separator;
		String path = request.getSession().getServletContext()
				.getRealPath(File.separator+"addPhoto"+File.separator);
		System.out.println("文件路径" + path);
		String scrap_url=PhotoUpload.upload(url, path, file);
		proofScrap.setScrap_url(scrap_url);
		System.out.println(scrap_url);
		return  scrapService.addProofScrap(proofScrap);
	
}
	@RequestMapping("/queryProof.do")
	@ResponseBody
	public  JsonResult  queryProof(Integer scrap_ID,HttpServletRequest servletRequest){
		if(scrap_ID==null) 
			return new JsonResult(FAIL);
		return scrapService.queryProofScrap2(scrap_ID,servletRequest);
		
	}
	
	@RequestMapping("/deleteProof.do")
	@ResponseBody
	public  JsonResult deleteProof(@RequestBody ProofScrap proofScrap,HttpServletRequest servletRequest){
		if(proofScrap==null) return  new JsonResult(FAIL);
		return  scrapService.deleteProofScrap(proofScrap,servletRequest);
	}
	
}
