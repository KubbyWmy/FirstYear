package privateInfo;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.junit.Test;

import com.dawn.mapper.AssetMapper;
import com.dawn.pojo.Asset;
import com.dawn.pojo.ProofInvoice;
import com.dawn.pojo.ProofPhoto;

public class AssetTest extends DatabaseTest{
	@Test
	public void testDataSource() throws SQLException{
		DataSource ds=ctx.getBean("dataSource",DataSource.class);
		Connection conn=ds.getConnection();
		DatabaseMetaData md=conn.getMetaData();
		System.out.println(md);
		String n=md.getDatabaseProductName();
		String v=md.getDatabaseProductVersion();
		System.out.println(n+v);
		conn.close();
	}
	/*mapper层*/
	/*添加资产信息*/
	@Test
	public void testAddAsset(){
		AssetMapper a=ctx.getBean("assetMapper",AssetMapper.class);
		Date purchase_date=new Date(1058, 2, 13);
		Asset asset2=new Asset();
		asset2.setAsset_name("123");
		asset2.setAsset_class("办公设备");
//		Asset asset=new Asset(null, "基站",null, null, "10988",null,12.3, purchase_date, "123");
//		int i=a.addOneAsset(asset);
//		System.out.println(i);
		int i2=a.addOneAsset(asset2);
		System.out.println(asset2.getAsset_ID());
		System.out.println(i2);
	}
	/*修改资产信息*/
	@Test
	public void testModifyAsset(){
		AssetMapper a=ctx.getBean("assetMapper",AssetMapper.class);
		Date purchase_date=new Date(1058, 2, 13);
		Asset asset=new Asset(null, null, "惠普", "", "ppp", "办公", 123.36, purchase_date, "网购");
		int i=a.modifyAssetById(asset);
		System.out.println(i);
	}
	/*查詢资产信息*/
	@Test
	public void testQueryOneAsset(){
		AssetMapper a=ctx.getBean("assetMapper",AssetMapper.class);
		Asset asset=a.queryOneAssetById(null);//资产id=2时这里时间戳的格式转变有问题
		System.out.println(asset);
	}
	@Test
	public void testQueryAllAssetExceptScrap(){
		AssetMapper a=ctx.getBean("assetMapper",AssetMapper.class);
		List<Asset> asset=a.queryAllAssetExceptScrap();
		System.out.println(asset);
	}
	@Test
	public void testQueryAllAssetHasScrap(){
		AssetMapper a=ctx.getBean("assetMapper",AssetMapper.class);
		List<Asset> asset=a.queryAllAssetHasScrap();
		System.out.println(asset);
	}
	@Test
	public void testQueryAllAssetIncludeScrap(){
		AssetMapper a=ctx.getBean("assetMapper",AssetMapper.class);
		List<Asset> asset=a.queryAllAssetIncludeScrap();
		System.out.println(asset);
	}
	@Test
	public void testQueryAssetIncludePhotos(){
		AssetMapper a=ctx.getBean("assetMapper",AssetMapper.class);
		Asset asset=a.queryAssetIncludePhotos(1);
		System.out.println(asset);
	}
	/*删除资产信息*/
	@Test
	public void testDeleteAsset(){
		AssetMapper a=ctx.getBean("assetMapper",AssetMapper.class);
		int i=a.deleteOneAssetById(4);
		System.out.println(i);
	}
	@Test
	public void testSetAll(){
		AssetMapper a=ctx.getBean("assetMapper",AssetMapper.class);
		Asset asset=new Asset();
		int i=a.setIsFill(asset);
		System.out.println(i);
	}
	/*图片信息管理*/
	/*批量添加发票*/
	@Test
	public void testaddAssetUrl(){
		AssetMapper a=ctx.getBean("assetMapper",AssetMapper.class);
		ProofInvoice proofInvoice=new ProofInvoice(2, 2, "img/lyj/pp");
		ProofInvoice proofInvoice2=new ProofInvoice(2, 3, "img/lyj/77");
		ProofInvoice proofInvoice5=new ProofInvoice(1, 2, "img/lyj/88");
		List<ProofInvoice> p=new ArrayList<ProofInvoice>();
		p.add(proofInvoice);
	    p.add(proofInvoice2);
	    p.add(proofInvoice5);
		int i=a.addAllInvocie(p);
		System.out.println(i);
	}
	@Test
	public void testddOneInvocie(){
		AssetMapper a=ctx.getBean("assetMapper",AssetMapper.class);;
		ProofInvoice proofInvoice5=new ProofInvoice(1, 5, "img/lyj/88");
		int i=a.addOneInvocie(proofInvoice5);
		System.out.println(i);
	}
	@Test
	public void testDeleteInvoice(){
		AssetMapper a=ctx.getBean("assetMapper",AssetMapper.class);
		int i=a.deleteOneInvoice(2);
		System.out.println(i);
	}
	@Test
	public void testQueryInvoiceById(){
		AssetMapper a=ctx.getBean("assetMapper",AssetMapper.class);
//		List<ProofInvoice> s= a.queryInvoiceById(1);
		List<String> s= a.queryInvoiceById(1);
		/*for(ProofInvoice str:s)	*/
		for(String str:s)	
			System.out.print(str+"+++");
	}
	@Test
	public void testQueryInvoiceById2(){
		AssetMapper a=ctx.getBean("assetMapper",AssetMapper.class);
		List<ProofInvoice> s= a.queryInvoiceById2(1);
		for(ProofInvoice str:s)	
	
			System.out.print(str+"+++");
	}
	/*实物图*/
	@Test
	public void testAddAllPhoto(){
		AssetMapper a=ctx.getBean("assetMapper",AssetMapper.class);
		ProofPhoto proofPhoto=new ProofPhoto(1, "img/lyj/pp", 2);
		ProofPhoto proofPhoto2=new ProofPhoto(1, "img/lyj12", 2);
		ProofPhoto proofPhoto3=new ProofPhoto(1, "img/lyj/11p", 3);
		ProofPhoto proofPhoto4=new ProofPhoto(1, "img/lyj/p55", 5);
		List<ProofPhoto> p=new ArrayList<ProofPhoto>();
		p.add(proofPhoto);
	    p.add(proofPhoto2);
	    p.add(proofPhoto3);
	    p.add(proofPhoto4);
		int i=a.addAllPhoto(p);
		System.out.println(i);
	}
	@Test
	public void testaddOnePhoto(){
		AssetMapper a=ctx.getBean("assetMapper",AssetMapper.class);
		ProofPhoto proofPhoto=new ProofPhoto(1, "img/lyj/pp", 2);
		int i=a.addOnePhoto(proofPhoto);
		System.out.println(i);
	}
	@Test
	public void testDeletePhoto(){
		AssetMapper a=ctx.getBean("assetMapper",AssetMapper.class);
		int i=a.deleteOnePhoto(4);
		System.out.println(i);
	}
	@Test
	public void testQueryPhotoById(){
		AssetMapper a=ctx.getBean("assetMapper",AssetMapper.class);
//		List<ProofInvoice> s= a.queryInvoiceById(1);
		List<String> s= a.queryPhotoById(1);
		/*for(ProofInvoice str:s)	*/
		for(String str:s)	
			System.out.print(str+"+++");
	}
	
	@Test
	public void testQueryPhotoById2(){
		AssetMapper a=ctx.getBean("assetMapper",AssetMapper.class);
		List<ProofPhoto> s= a.queryPhotoById2(1);
			System.out.print(s);
	}
	
	
}
