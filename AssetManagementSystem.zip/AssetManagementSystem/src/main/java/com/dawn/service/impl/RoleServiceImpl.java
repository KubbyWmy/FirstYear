package com.dawn.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.dawn.mapper.RoleMapper;
import com.dawn.pojo.Role;
import com.dawn.service.RoleService;
import com.dawn.util.JsonResult;
import com.dawn.util.PermissionConverter;

@Service("roleService")
public class RoleServiceImpl implements RoleService {
	@Resource
	private RoleMapper roleMapper;

	/*
	 * 添加一个角色 查询该角色是否不存在 添加该角色入库，成功返回true 该角色存在或添加不成功 ，返回false
	 */
	public JsonResult addRole(Role role) {
		if (roleMapper.queryRoleByName(role.getRole_name()) != null)
			return new JsonResult(0, new Throwable("该角色名已存在，角色不可同名"));
		if (roleMapper.addRole(role) > 0)
			return new JsonResult(1, null, "保存成功");
		return new JsonResult(0, new Throwable("未知原因导致添加失败"));

	}
	/*
	 * 删除角色
	 */
	public JsonResult deleteRole(Integer role_ID) {
		if(roleMapper.queryFromstaff(role_ID)!=null) {
			return new JsonResult(0,new Throwable("该角色正在使用中，不可删除"));
		}
		if(roleMapper.deleteRole(role_ID)> 0) {
			List<Role> roleList=roleMapper.queryAllRole();
			for(Role r:roleList)
				PermissionConverter.StrToList(r);
			return new JsonResult(1,roleList , "删除成功");
		}else{
		List<Role> rList=roleMapper.queryAllRole();
		for(Role r:rList)	
			PermissionConverter.StrToList(r);
		return new JsonResult(0,rList,"未知原因导致修改失败");// 修改失败，返回false;
		}
		}

	/*
	 * 修改角色权限
	 * // 修改该角色permission字段的值，修改成功返回true
		// 修改失败返回false;
	 */
	public JsonResult modifyRolePermission(Role role) {
		if(roleMapper.modifyRolePermission(role) > 0){
		Role role2=roleMapper.queryRoleById(role.getRole_ID());
			
		return new JsonResult(1, PermissionConverter.StrToList(role2), "修改成功");
		}
		Role role2=roleMapper.queryRoleById(role.getRole_ID());
		return new JsonResult(0,PermissionConverter.StrToList(role2),"修改失败" );	
	}

	/*
	 * 根据名字查找该角色信息 // 数据库该角色名存在// 返回该角色所有信息 // 该参数为空值或该角色名在数据库不存在。返回空值
	 */
	public Role queryRoleByName(String role_name) {
		Role role = roleMapper.queryRoleByName(role_name);
		if (role != null) {
			if (role.getPermission() != null)
				return PermissionConverter.StrToList(role);
			// PermissionConverter pConverter=new PermissionConverter();
		} else
			return role;
		return null;
	}

	/*
	 * 查询角色表所有角色信息
	 */
	public JsonResult queryAllRole() {
		List<Role> list=roleMapper.queryAllRole();
		for(Role r:list)
			PermissionConverter.StrToList(r);
		return new JsonResult(1, list, "查询成功");
	}

	/*
	 * 根据id号查找角色信息
	 */
	public Role queryRoleById(Integer role_ID) {

		/*
		 * if (role_ID != null) // 传入参数不为空 if (roleMapper.queryRoleById(role_ID)
		 * != null)// 数据库查到该参数 return roleMapper.queryRoleById(role_ID);// 返回该角色
		 * return null;// 否则，返回空
		 * 
		 */ Role role = roleMapper.queryRoleById(role_ID);
		if (role.getPermission() != null) {
			// PermissionConverter pConverter=new PermissionConverter();
			return PermissionConverter.StrToList(role);
		}
		return role;
	}

}
