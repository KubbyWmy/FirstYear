package cs.web;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cs.entity.User;
import cs.service.UserService;
import cs.util.JsonResult;

@Controller
@RequestMapping("/user")
public class UserController extends BaseController{
	@Resource
	private UserService service;
	
	@RequestMapping("/login.do")
	@ResponseBody
	public JsonResult<User> login(String id,String pwd,HttpServletRequest req){
		User user=service.login(id, pwd);
		req.getSession().setAttribute("loginUser", user);
		return new JsonResult<User>(user);
	}
	@RequestMapping("/regist.do")
	@ResponseBody
	public JsonResult<User> reg(String id,String pwd,String confirm){
		User user=service.reg(id, pwd, confirm);
		return new JsonResult<User>(user);
	}
	@RequestMapping("/update.do")
	@ResponseBody
	public JsonResult<User> update(String id, String pwd, String username, String email){
		User user=service.update(id, pwd, username, email);
		return new JsonResult<User>(user);
	}
}	
