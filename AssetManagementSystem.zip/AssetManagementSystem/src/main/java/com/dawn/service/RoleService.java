package com.dawn.service;

import java.util.List;

import com.dawn.pojo.Role;
import com.dawn.util.JsonResult;

public interface RoleService {
	  public Object addRole(Role role);
	  public Object deleteRole(Integer role_ID);
	  public Object modifyRolePermission(Role role);
	  public Role queryRoleByName(String role_name);
	  public Role queryRoleById(Integer role_ID);
	/*  public List<Map<String,Boolean>> queryRoleById(Integer role_ID);*/
	  public JsonResult queryAllRole();
	}
