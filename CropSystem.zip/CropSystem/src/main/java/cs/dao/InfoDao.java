package cs.dao;

import java.util.List;
import java.util.Map;

import cs.entity.Info;

public interface InfoDao {
	List<Map<String, Object>> listInfo(String user_id);
	int removeInfo (int creatime);
	Info writeInfo(int creatime);
	int addInfo(Info info);
	String autoWrite(String user_id);
}
