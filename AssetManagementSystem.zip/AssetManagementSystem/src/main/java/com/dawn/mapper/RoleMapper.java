package com.dawn.mapper;

import java.util.List;

import com.dawn.pojo.Role;
import com.dawn.pojo.Staff;

public interface RoleMapper {
	/*
	 * 添加一个角色
	 */
	public int addRole(Role role);

	/*
	 * 修改用户权限
	 */
	public int modifyRolePermission(Role role);

	/*
	 * 根据角色名查找角色信息
	 */
	public Role queryRoleByName(String role_name);
	/*
	 * 根据id查找角色
	 */
	public Role queryRoleById(Integer role_ID);

	/*
	 * 查询所有角色信息
	 */
	public List<Role> queryAllRole();
	/*
	 * 删除一个角色
	 */
	public int deleteRole(Integer role_ID);
	
	public  Staff queryFromstaff(Integer role_ID);
}
