package com.dawn.util;

import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.docx4j.openpackaging.parts.WordprocessingML.AltChunkType;

/**
 * Add HTML, in a way that leaves it up to downstream 
 * application (eg Word) to convert the content to docx content.
 * 
 * Unless you really want the HTML converted by Word,
 * consider converting your HTML to well-formed XHTML,
 * then using docx4j's XHTMLImporter instead.
 * 
 * @author jharrop
 *
 */
public class AltChunkAddOfTypeHtml {

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {

		WordprocessingMLPackage wordMLPackage = WordprocessingMLPackage.createPackage();

		String html = "<html>"+
"<head>"+
"<style type= text/css\" data-styled-components=\"lbVtra jiVNIn iAwAJM ksEPUt gXUxOL jMitKt ghHdxY huaJtQ\" data-styled-components-is-local=\"true\"> .sc-bdVaJa {} .jMitKt{font-size:20px;color:rgb(85,85,85);} .sc-bwzfXH {} .jiVNIn{width:900px;margin:0 auto;border:2px solid #000;border-collapse:collapse;text-align:center;}.jiVNIn td{padding:5px;border:2px solid #000;color:#000;}.jiVNIn tr:nth-child(odd) > td{color:#000;font-size:16px;font-weight:bolder;} .sc-htpNat {} .iAwAJM{fontSize:12;font-weight:normal;} .sc-bxivhb {} .ksEPUt{fontSize:12;font-weight:normal;} .sc-ifAKCX {} .gXUxOL{color:#000;margin-top:10px;font-weight:bolder;margin-left:750px;}.gXUxOL>span{margin-left:90px;} .sc-EHOje {} .lbVtra{clear:both;} .sc-gzVnrw {} .ghHdxY{background:#fff;width:90px;height:35px;border:1px solid #000000;border-color:#0099ff;border-radius:5px;outline:none;color:#0099ff;margin-right:10px;}.ghHdxY:hover{background:#0099ff;color:#fff;cursor:pointer;} .huaJtQ{background:#fff;width:90px;height:35px;border:1px solid #000000;border-color:#49D21C;border-radius:5px;outline:none;color:#49D21C;margin-right:10px;}.huaJtQ:hover{background:#49D21C;color:#fff;cursor:pointer;}</style> "+
	"<div><h1 style=\"text-align: center;\">资产核查备忘录</h1><div style=\"text-align: center; font-size: 18px;\">（一式二份，保管人与公司资产管理部各执一份）</div><table class=\"sc-bwzfXH jiVNIn\" style=\"width:600px;margin:0 auto;border:2px solid #000;border-collapse:collapse;text-align:center;\"><tbody><tr> <td style=\"border:1px solid black\"><!-- react-text: 66 -->资产清单编号<!-- /react-text --><div class=\"sc-htpNat iAwAJM\">(具有唯一性）</div></td> <td style=\"border:1px solid black\">固定资产编码</td> <td style=\"border:1px solid black\">资产名称</td> <td style=\"border:1px solid black\">资产类别</td> <td style=\"border:1px solid black\">规格型号</td> <td style=\"border:1px solid black\">P/N</td></tr><tr> <td style=\"border:1px solid black\">YF008</td> <td style=\"border:1px solid black\">0</td> <td style=\"border:1px solid black\">工具箱</td> <td style=\"border:1px solid black\">维修工具</td> <td style=\"border:1px solid black\">详图片</td> <td style=\"border:1px solid black\">0</td></tr><tr> <td style=\"border:1px solid black\">S/N</td> <td style=\"border:1px solid black\">账面数量</td> <td style=\"border:1px solid black\">实际数量</td> <td style=\"border:1px solid black\">使用部门</td> <td style=\"border:1px solid black\">所在区域</td> <td style=\"border:1px solid black\">开始使用日期</td></tr><tr> <td style=\"border:1px solid black\">00000</td> <td style=\"border:1px solid black\">1</td> <td style=\"border:1px solid black\">1</td> <td style=\"border:1px solid black\">研发中心</td> <td style=\"border:1px solid black\">研发中心</td> <td style=\"border:1px solid black\">2017/6/22</td></tr><tr> <td style=\"border:1px solid black\"><!-- react-text: 96 -->原单价<!-- /react-text --><span class=\"sc-bxivhb ksEPUt\">（元）</span></td> <td style=\"border:1px solid black\"><!-- react-text: 99 -->折旧年限<!-- /react-text --><span class=\"sc-bxivhb ksEPUt\">（年）</span></td> <td style=\"border:1px solid black\"><!-- react-text: 102 -->年折旧额<!-- /react-text --><span class=\"sc-bxivhb ksEPUt\">（元）</span></td> <td style=\"border:1px solid black\"><!-- react-text: 105 -->累计折旧<!-- /react-text --><span class=\"sc-bxivhb ksEPUt\">（元）</span></td> <td style=\"border:1px solid black\"><!-- react-text: 108 -->估值<!-- /react-text --><span class=\"sc-bxivhb ksEPUt\">（元）</span></td> <td style=\"border:1px solid black\"><!-- react-text: 111 -->管理责任人<!-- /react-text --><div class=\"sc-htpNat iAwAJM\">（签字）</div></td></tr><tr> <td style=\"border:1px solid black\">0</td> <td style=\"border:1px solid black\">5</td> <td style=\"border:1px solid black\">0</td> <td style=\"border:1px solid black\">0.00</td> <td style=\"border:1px solid black\">0.00</td> <td style=\"border:1px solid black\"></td></tr><tr> <td style=\"border:1px solid black\" colspan=\"2\">备注</td> <td style=\"border:1px solid black\" colspan=\"2\"><!-- react-text: 123 -->核查情况说明<!-- /react-text --><div class=\"sc-htpNat iAwAJM\">（需当场确认并填写）</div></td> <td style=\"border:1px solid black\"><!-- react-text: 126 -->转交或移出人<!-- /react-text --><div class=\"sc-htpNat iAwAJM\">（签字）</div></td> <td style=\"border:1px solid black\"><!-- react-text: 129 -->接受或保管人<!-- /react-text --><div class=\"sc-htpNat iAwAJM\">（签字）</div></td></tr><tr style=\"height: 110px;\"> <td style=\"border:1px solid black\" colspan=\"2\">东冠公司自购，部分工具损耗待补，情况详图片</td> <td style=\"border:1px solid black\" colspan=\"2\">东冠公司自购，部分工具损耗待补，情况详图片</td> <td style=\"border:1px solid black\"></td> <td style=\"border:1px solid black\"></td></tr></tbody></table><div class=\"sc-ifAKCX gXUxOL\"><!-- react-text: 137 -->核查日期 <!-- /react-text --><span>2017/8/22 15:54</span></div></div> "
+
"</html>"; 

		wordMLPackage.getMainDocumentPart().addAltChunk(AltChunkType.Html, html.getBytes()); 

		wordMLPackage.save(new java.io.File(System.getProperty("user.dir") + "/test.docx"));		
	}

}
