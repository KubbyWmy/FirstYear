$(function(){
	var url='http://localhost:8080/StudentSystem/student/showAllStudent.do';
	var template='<tr class="list-roles">'+
	'<td>studentId</td>'+
	'<td>studentName</td>'+
	'<td>studentClass</td>'+
	'<td>'+
	'<div class="btn-group">'+
	'<a href="my-profile.html?id=studentIdNew" style="cursor:pointer"><i class="icon-pencil"></i> 更改信息</a>'+
	'</div>'+
	'</td>'+
	'</tr>';
	$.post(url,function(result){
		if(result.state){
			//console.log(result);
			var studentInfo=result.data;
			for(var i=0;i<studentInfo.length;i++){
				var tr=template.replace('studentId',studentInfo[i].studentId)
								.replace('studentName',studentInfo[i].studentName)
								.replace('studentClass',studentInfo[i].studentClass)
								.replace('studentIdNew',studentInfo[i].studentId);
				$('#rolesBody').append(tr);
			}
		}
	});
});
