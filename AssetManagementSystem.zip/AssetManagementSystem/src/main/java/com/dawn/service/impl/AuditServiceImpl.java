package com.dawn.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.dawn.mapper.AssetMapper;
import com.dawn.mapper.AuditMapper;
import com.dawn.pojo.Asset;
import com.dawn.pojo.Audit;
import com.dawn.service.AuditService;
import com.dawn.util.JsonResult;

@Service
public class AuditServiceImpl implements AuditService {
	@Resource
	private AuditMapper auditMapper;
	@Resource
	private AssetMapper assetMapper;
	Asset asset=new Asset() ;
	public JsonResult addAudit(Audit audit) {
		if(assetMapper.queryOneAssetById(audit.getAsset_ID()).getAudit_isFill()==1) return new JsonResult(0,new Throwable("已添加，不要重复录入"));
		if (auditMapper.addAudit(audit) > 0) {
			asset.setAudit_isFill(1);
			asset.setAsset_ID(audit.getAsset_ID());
			assetMapper.setIsFill(asset);
			return new JsonResult(1,null,"添加成功");
		} else
			return new JsonResult(0,new Throwable("添加失败"));
	}
	public JsonResult modifyAudit(Audit audit) {
		if(auditMapper.modifyAudit(audit) > 0) {
			Audit audits=auditMapper.queryAudit(audit.getAsset_ID());
			return new JsonResult(1, audits,"修改成功");
		}
		Audit audits=auditMapper.queryAudit(audit.getAsset_ID());
		return new JsonResult(0, audits,"修改失败");
	}

	public JsonResult deleteAudit(Integer audit_ID) {
		Audit audit=auditMapper.queryAudit(audit_ID);
		if(audit==null) return new JsonResult(0,new Throwable("该参数不存在"));
		if(auditMapper.deleteAudit(audit_ID) > 0){
		asset.setAudit_isFill(0);
		asset.setAsset_ID(audit.getAsset_ID());
		assetMapper.setIsFill(asset);
		List<Audit> audits=auditMapper.queryAllAudit();
		
	    return new JsonResult(1, audits,"删除成功");
		}
       List<Audit> audits=auditMapper.queryAllAudit();
	    return new JsonResult(1, audits,"删除失败");
	}

	public JsonResult queryAudit(Integer asset_ID) {
		Audit audit=auditMapper.queryAudit(asset_ID);
		if(auditMapper.queryAudit(asset_ID)==null) return new JsonResult(0,new Throwable("该记录不存在")); 
		return new JsonResult(1,audit,"查询成功") ;
	}

	public JsonResult queryAllAudit() {
		// TODO Auto-generated method stub
		List<Audit> audits=auditMapper.queryAllAudit();
		if(audits.isEmpty()) return new JsonResult(0,new Throwable("数据不存在"));
		return new JsonResult(1,audits,"查询成功") ;
	}
	public JsonResult queryAudit2(Integer audit_ID) {
		Audit audit=auditMapper.queryAudit2(audit_ID);
		if(auditMapper.queryAudit(audit.getAsset_ID())==null) return new JsonResult(0,new Throwable("该记录不存在")); 
		return new JsonResult(1,audit,"查询成功") ;
	}

}
