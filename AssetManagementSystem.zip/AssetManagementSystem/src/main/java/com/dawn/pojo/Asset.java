package com.dawn.pojo;
import java.sql.Date;
/*
 *creator: lyj
 *
 * */
import java.util.List;


import com.alibaba.fastjson.annotation.JSONField;

public class Asset {
	
	private Integer asset_ID;
    private String  asset_name;
    private String  specifications;
    private String  PN;
    private String  SN;
    private String  asset_class;
    @JSONField(format="yyyy-mm-dd")
    private double  asset_price;
    private Date   purchase_date;
    private String  remarks;
    private Integer is_delete;
    private Integer audit_isFill;
    private Integer scrap_isFill;
    private List<ProofInvoice>  proofInvoices;
    private List<ProofPhoto> photos;
	public Asset() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Asset(Integer asset_ID, String asset_name, String specifications, String pN, String sN, String asset_class,
			double asset_price, Date purchase_date, String remarks) {
		super();
		this.asset_ID = asset_ID;
		this.asset_name = asset_name;
		this.specifications = specifications;
		PN = pN;
		SN = sN;
		this.asset_class = asset_class;
		this.asset_price = asset_price;
		this.purchase_date = purchase_date;
		this.remarks = remarks;
	}



	public Asset(Integer asset_ID, String asset_name, String specifications, String pN, String sN, String asset_class,
			double asset_price,Date purchase_date, String remarks,
			List<ProofInvoice> proofInvoices, List<ProofPhoto> photos) {
		super();
		this.asset_ID = asset_ID;
		this.asset_name = asset_name;
		this.specifications = specifications;
		PN = pN;
		SN = sN;
		this.asset_class = asset_class;
		this.asset_price = asset_price;
		this.purchase_date = purchase_date;
		this.remarks = remarks;
		this.proofInvoices = proofInvoices;
		this.photos = photos;
	}


	/*用于修改其他辅助信息*/
	
	public Integer getAsset_ID() {
		return asset_ID;
	}

	public Asset(Integer asset_ID, Integer audit_isFill, Integer scrap_isFill) {
		super();
		this.asset_ID = asset_ID;
		this.audit_isFill = audit_isFill;
		this.scrap_isFill = scrap_isFill;
	}

	public void setAsset_ID(Integer asset_ID) {
		this.asset_ID = asset_ID;
	}

	public String getAsset_name() {
		return asset_name;
	}

	public void setAsset_name(String asset_name) {
		this.asset_name = asset_name;
	}

	public String getSpecifications() {
		return specifications;
	}

	public void setSpecifications(String specifications) {
		this.specifications = specifications;
	}

	public String getPN() {
		return PN;
	}

	public void setPN(String pN) {
		PN = pN;
	}

	public String getSN() {
		return SN;
	}

	public void setSN(String sN) {
		SN = sN;
	}

	public String getAsset_class() {
		return asset_class;
	}

	public void setAsset_class(String asset_class) {
		this.asset_class = asset_class;
	}

	public double getAsset_price() {
		return asset_price;
	}

	public void setAsset_price(double asset_price) {
		this.asset_price = asset_price;
	}

	public Date getPurchase_date() {
		return purchase_date;
	}

	public void setPurchase_date(Date purchase_date) {
		this.purchase_date = purchase_date;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Integer getIs_delete() {
		return is_delete;
	}

	public void setIs_delete(Integer is_delete) {
		this.is_delete = is_delete;
	}

	public Integer getAudit_isFill() {
		return audit_isFill;
	}

	public void setAudit_isFill(Integer audit_isFill) {
		this.audit_isFill = audit_isFill;
	}
	public List<ProofInvoice> getProofInvoices() {
		return proofInvoices;
	}

	public void setProofInvoices(List<ProofInvoice> proofInvoices) {
		this.proofInvoices = proofInvoices;
	}

	public List<ProofPhoto> getPhotos() {
		return photos;
	}

	public void setPhotos(List<ProofPhoto> photos) {
		this.photos = photos;
	}

	@Override
	public String toString() {
		return "Asset [asset_ID=" + asset_ID + ", asset_name=" + asset_name + ", specifications=" + specifications
				+ ", PN=" + PN + ", SN=" + SN + ", asset_class=" + asset_class + ", asset_price=" + asset_price
				+ ", purchase_date=" + purchase_date + ", remarks=" + remarks + ", is_delete=" + is_delete
				+ ", audit_isFill=" + audit_isFill + ", scrap_isFill=" + scrap_isFill + ", proofInvoices="
				+ proofInvoices + ", photos=" + photos + "]";
	}

	


    
}
