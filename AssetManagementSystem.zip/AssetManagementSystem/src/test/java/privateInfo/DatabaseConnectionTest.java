package privateInfo;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.junit.Test;

import com.dawn.mapper.StaffInfoMapper;
import com.dawn.mapper.RoleMapper;
import com.dawn.mapper.StaffMapper;
import com.dawn.pojo.Role;
import com.dawn.pojo.Staff;
import com.dawn.service.LoginService;
import com.dawn.service.RoleService;
import com.dawn.service.StaffService;

public class DatabaseConnectionTest extends DatabaseTest {
	@Test
	public void testDataSource() throws SQLException {
		DataSource ds = ctx.getBean("dataSource", DataSource.class);
		Connection conn = ds.getConnection();
		DatabaseMetaData md = conn.getMetaData();
		System.out.println(md);
		String n = md.getDatabaseProductName();
		String v = md.getDatabaseProductVersion();
		System.out.println(n + v);
		conn.close();
	}

	@Test
	public void testFindStaff() {
		StaffInfoMapper info = ctx.getBean("staffInfoMapper", StaffInfoMapper.class);
		Staff staff = info.findStaffById("2");
		System.out.println(staff);
	}

	@Test
	public void testChangePwd() {
		StaffService info = ctx.getBean("staffService", StaffService.class);
		System.out.println(info.changeStaffPwd("2", "1235465", "1235465111"));
	}

	@Test
	public void testRoller() {
		RoleMapper role = ctx.getBean("roleMapper", RoleMapper.class);
		Role r = new Role(1, "bb", "1213");
		System.out.println(r);
		int i = role.addRole(r);
		System.out.println(i);

	}

	@Test
	public void testDeleteRole() {
		RoleMapper role = ctx.getBean("roleMapper", RoleMapper.class);
		Role r = new Role(19, "bb", "1213");
		int i = role.deleteRole(r.getRole_ID());
		System.out.println(i);

	}

	@Test
	public void testQueryRoleById() {
		RoleMapper role = ctx.getBean("roleMapper", RoleMapper.class);
		Role r = role.queryRoleById(1);
		System.out.println(r);
	}

	@Test
	public void testQueryRoleByName() {
		RoleMapper role = ctx.getBean("roleMapper", RoleMapper.class);
		Role r = role.queryRoleByName("绠＄悊鍛�");
		System.out.println(r);
	}

	@Test
	public void testQueryStaff() {
		StaffMapper role = ctx.getBean("staffMapper", StaffMapper.class);
		Staff s = role.queryStaff("1");
		System.out.println(s.toString());
	}

	@Test
	public void testModifyRole() {
		RoleMapper role = ctx.getBean("roleMapper", RoleMapper.class);
		Role r = new Role(1, "qubq", "123456");
		int i = role.modifyRolePermission(r);
		System.out.println(i);
		System.out.println(r);
	}

	@Test
	public void testQueryStaffService() {
		System.out.println("come");
		LoginService ss = ctx.getBean("loginService", LoginService.class);
		System.out.println(ss);
		Staff s = (Staff) ss.checkLogin("1", "123", null);
		System.out.println(s);
	}

	/*@Test
	public void testRoleServiceAdd() {
		RoleService rService = ctx.getBean("roleService", RoleService.class);
		System.out.println(rService);
		Role role = new Role(1, "49", "123654");
		Boolean b = rService.addRole(role);
		if (b)
			System.out.println(b + "right");
		else
			System.out.println(b + "wrong");
	}

	@Test
	public void testRoleServiceDeleteRole() {
		RoleService rService = ctx.getBean("roleService", RoleService.class);
		System.out.println(rService);
		Role role = new Role(1, "49", "124412");
		Boolean b = rService.deleteRole(role);
		if (b)
			System.out.println(b + "right");
		else
			System.out.println(b + "wrong");
	}*/

	@Test
	public void testRoleServicemodifyPermission() {
		RoleService rService = ctx.getBean("roleService", RoleService.class);
		System.out.println(rService);
		Role role = new Role(6, "hh", "124412");
		System.out.println(rService.modifyRolePermission(role));
	}

	@Test
	public void testRoleServicQueryByName() {
		RoleService rService = ctx.getBean("roleService", RoleService.class);
		System.out.println(rService);
		String role_name = "hh";
		System.out.println(rService.queryRoleByName(role_name));
	}

	@Test
	public void testRoleServicQueryById() {
		RoleService rService = ctx.getBean("roleService", RoleService.class);
		System.out.println(rService);
		int role_ID = 6;
		System.out.println(rService.queryRoleById(role_ID));
	}

	/*@Test
	public void testRoleServicQueryAll() {
		RoleService rService = ctx.getBean("roleService", RoleService.class);
		System.out.println(rService);
		List<Role> list = rService.queryAllRole();
		for (Role role : list) {
			System.out.print(role + "/t");

		}

	}*/

	@Test
	public void testAddStaff() {
		StaffMapper role = ctx.getBean("staffMapper", StaffMapper.class);
		Role r = new Role();
		Staff staff = new Staff();
		staff.setStaff_ID("21");
		staff.setStaff_pwd("1234");
		int s = role.addStaff(staff);
		System.out.println(s);
	}
	// @Test
	// public void testModifyStaff(){
	// StaffMapper role=ctx.getBean("staffMapper",StaffMapper.class);
	// Role r=new Role(6, "123", "ll", 0);
	// Staff staff=new Staff("4", "anli", "123ll", "以i", "keyuan", "123654", r,
	// 0);
	// int s=role.modifyStaff(staff);
	// System.out.println(s);
	// }

}
