package com.dawn.mapper;

import java.util.List;

import com.dawn.pojo.ProofTransfer;
import com.dawn.pojo.Transfer;

public interface TransferMapper {
public int addTransfer(Transfer transfer);
public int deleteTransfer(Integer transfer_ID);
public int modifyTransfer(Transfer transfer);
public Transfer queryTransfer(Integer transfer_ID);
public List<Transfer> queryAllTransfer();


public int addTransferProof(ProofTransfer prooftransfer);
public List<String> queryTransferProof(Integer transfer_ID );
public List<ProofTransfer> queryTransferProof2(Integer transfer_ID );
public int deleteTransferproof(Integer transferProof_ID);
public  ProofTransfer queryOneTransferProof(Integer transferProof_ID );
}
