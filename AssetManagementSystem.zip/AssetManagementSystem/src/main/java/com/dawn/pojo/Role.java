package com.dawn.pojo;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Role {
	private Integer role_ID;
	private String role_name;
	private String permission;
	private Integer is_delete;
	private Permission per;
	public Role() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Role(Integer role_ID, String role_name, String permission) {
		super();
		this.role_ID = role_ID;
		this.role_name = role_name;
		this.permission = permission;
	}
	public Role(Integer role_ID, String role_name, String permission, Permission per) {
		super();
		this.role_ID = role_ID;
		this.role_name = role_name;
		this.permission = permission;
		this.per = per;
	}
	public Integer getRole_ID() {
		return role_ID;
	}
	public void setRole_ID(Integer role_ID) {
		this.role_ID = role_ID;
	}
	public String getRole_name() {
		return role_name;
	}
	public void setRole_name(String role_name) {
		this.role_name = role_name;
	}
	public String getPermission() {
		return permission;
	}
	public void setPermission(String permission) {
		this.permission = permission;
	}
	public Integer getIs_delete() {
		return is_delete;
	}
	public void setIs_delete(Integer is_delete) {
		this.is_delete = is_delete;
	}
	public Permission getPer() {
		return per;
	}
	public void setPer(Permission per) {
		this.per = per;
	}
	@Override
	public String toString() {
		return "Role [role_ID=" + role_ID + ", role_name=" + role_name + ", permission=" + permission + ", is_delete="
				+ is_delete + ", per=" + per + "]";
	}
	

	


	
}
