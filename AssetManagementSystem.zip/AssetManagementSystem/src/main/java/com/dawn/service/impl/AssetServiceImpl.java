package com.dawn.service.impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.Principal;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletInputStream;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Service;

import com.dawn.mapper.AssetMapper;
import com.dawn.pojo.Asset;
import com.dawn.pojo.ProofInvoice;
import com.dawn.pojo.ProofPhoto;
import com.dawn.service.AssetService;
import com.dawn.util.JsonResult;
import com.dawn.util.PhotoUpload;
import com.dawn.util.Token;

@Service
public class AssetServiceImpl implements AssetService {
	@Resource
	private AssetMapper assetMapper;
	
	
	/*
	 * 添加资产基本信息，不包括图片信息和IS_fill字段 数据库中asset_name和asset_class为必填字段，需先要判空
	 */
	public JsonResult addOneAsset(Asset asset) {
		System.out.println("addAsset--Go");
		if (assetMapper.addOneAsset(asset) > 0)
			return new JsonResult(1, null, "添加成功");
		return new JsonResult(0, new Throwable("不明原因导致添加失败"));
	}

	/*
	 * 修改资产信息，仅限于基本的信息不包括图片和IS_fill字段 如果修改成功返回true，其他为false
	 */
	public JsonResult modifyAssetById(Asset asset) {
		System.out.println("modify--Go");
		if (assetMapper.modifyAssetById(asset) > 0)
			return new JsonResult(1, assetMapper.queryOneAssetById(asset.getAsset_ID()), "修改成功");
		else return new JsonResult(0,assetMapper.queryOneAssetById(asset.getAsset_ID()), "不明原因导致修改失败");
	}

	/*
	 * 查询所有资产的基本信息 不包括已经报废的 返回资产的信息
	 */
	public JsonResult queryOneAssetById(Integer asset_ID) {
		System.out.println("queryOneAssetById--Go");
		Asset asset=assetMapper.queryOneAssetById(asset_ID);
		if(asset==null)return new JsonResult(0,new Throwable("数据不存在"));
		return new JsonResult(1,asset ,"查询成功") ;
	}

	/*
	 * 查询所有资产的基本信息 不包括报废的
	 */
	public JsonResult queryAllAssetExceptScrap() {
		System.out.println("queryAllAssetExceptScrap--Go");
        List<Asset> assets=assetMapper.queryAllAssetExceptScrap();
        if(assets.isEmpty()) return new JsonResult(0,new Throwable("参数不存在"));
		return new JsonResult(1, assets,"查询成功") ;
	}

	/*
	 * 查询所有报废资产的基本信息
	 */
	public JsonResult queryAllAssetHasScrap() {
		return new JsonResult(1, assetMapper.queryAllAssetHasScrap(), "查询成功");
	}

	/*
	 * 查询所有资产的基本信息 包括报废的
	 */
	public JsonResult queryAllAssetIncludeScrap() {
         
		
		return new JsonResult(1, assetMapper.queryAllAssetIncludeScrap(), "查询成功");
	}

	/*
	 * 查询资产的所有信息包括发票图片与实物图片
	 */
	public Object queryAssetIncludePhotos(Integer asset_ID) {
		// TODO Auto-generated method stub
		return new JsonResult(1, assetMapper.queryAssetIncludePhotos(asset_ID), "查询成功");
	}

	/*
	 * 根据asset_ID删除资产的信息
	 */
	public JsonResult deleteOneAssetById(Integer asset_ID) {
		
		if (assetMapper.deleteOneAssetById(asset_ID) > 0) {
			assetMapper.deleteAudit2(asset_ID);
			assetMapper.deleteRepair2(asset_ID);
			assetMapper.deleteScrap2(asset_ID);
			assetMapper.deleteStatus2(asset_ID);
			assetMapper.deleteTransfer2(asset_ID);
			return new JsonResult(1,assetMapper.queryAllAssetExceptScrap(),"删除成功");
		}
		return new JsonResult(0, assetMapper.queryAllAssetExceptScrap(),"未知原因导致失败");
	}

	/* 忽略此方法 */
	public JsonResult addAllInvocie(List<ProofInvoice> proofInvoices) {
		// TODO Auto-generated method stub
		return null;
	}

	/*
	 * 增加一个资产的发票图片信息 成功返回true否则返回false
	 */
	public JsonResult addOneInvocie(ProofInvoice proofInvoice) {
		if(proofInvoice.getAsset_ID()==null) return new JsonResult(0,new Throwable("资产基本信息未添加"));
		if(assetMapper.addOneInvocie(proofInvoice) > 0) return new JsonResult(1,new Throwable("添加成功"));
		return new JsonResult(0, new Throwable("不明原因导致失败"))  ;
	}

	/*
	 * 删除资产发票图片信息
	 */
	public JsonResult deleteOneInvoice(ProofInvoice invoice,HttpServletRequest servletRequest) {
		// TODO Auto-generated method stub
		if(assetMapper.deleteOneInvoice(invoice.getInvoiceProof_ID()) > 0){
			  List<ProofInvoice> proofInvoices=assetMapper.queryInvoiceById2(invoice.getAsset_ID());
		        if(proofInvoices.isEmpty()) return new JsonResult(0,new Throwable("全都删掉了"));   	
		        for(ProofInvoice proofInvoice:proofInvoices){
		        String	url=PhotoUpload.getUrl(servletRequest)+proofInvoice.getInvoice_url();
		        String url2=url.replace("\\", "/");
	        	proofInvoice.setInvoice_url(url2);
		        }
			return new JsonResult(1, proofInvoices, "删除成功");
		}
		else{ List<ProofInvoice> proofInvoices=assetMapper.queryInvoiceById2(invoice.getAsset_ID());
	        if(proofInvoices.isEmpty()) return new JsonResult(0,new Throwable("全都删掉了"));   	
	        for(ProofInvoice proofInvoice:proofInvoices){
	        String	url=PhotoUpload.getUrl(servletRequest)+proofInvoice.getInvoice_url();
	        	
	        	String url2=url.replace("\\", "/");
	        	proofInvoice.setInvoice_url(url2);
	        }
		return new JsonResult(0, proofInvoices, "删除失败");
		}
	}

	/*
	 * 查询资产发票的信息，返回值为一个String 的list
	 */
	public JsonResult queryInvoiceById(Integer asset_ID) {

		return new JsonResult(1, assetMapper.queryInvoiceById(asset_ID), "查询成功");
	}

	/*
	 * 查询资产信息，返回值为一个pojo的List
	 */
	public JsonResult queryInvoiceById2(Integer asset_ID,HttpServletRequest servletRequest) {
        List<ProofInvoice> proofInvoices=assetMapper.queryInvoiceById2(asset_ID);
        if(proofInvoices.isEmpty()) return new JsonResult(0,new Throwable("查询失败"));   	
        for(ProofInvoice proofInvoice:proofInvoices){
        	System.out.println(proofInvoice);
        String	url=PhotoUpload.getUrl(servletRequest)+proofInvoice.getInvoice_url();
        String url2=url.replace("\\", "/");
        	proofInvoice.setInvoice_url(url2);
        }
		return new JsonResult(1,proofInvoices ,"查询成功");
	}

	/* 忽略此方法 */
	public JsonResult addAllPhoto(List<ProofPhoto> proofPhotos) {
		return null;
	}

	/*
	 * 增加一个资产实物图片
	 */
	public JsonResult addOnePhoto(ProofPhoto proofPhoto) {
		System.out.println("addOnePhoto--Go");
		if(proofPhoto.getAsset_ID()==null) return new JsonResult(0,new Throwable("资产基本信息未添加"));
		if(assetMapper.addOnePhoto(proofPhoto)>0) return new JsonResult(1, null, "实物图片添加成功");
		return new JsonResult(0,new Throwable("未知原因导致添加失败"));
	}

	/*
	 * 删除一个资产信息的图片
	 */
	public JsonResult deleteOnePhoto(ProofPhoto photo,HttpServletRequest servletRequest) {
		System.out.println("deleteOnePhoto--Go");
		// TODO Auto-generated method stub
		if(assetMapper.deleteOnePhoto(photo.getPhotoProof_ID()) > 0) {
			List<ProofPhoto> photos=assetMapper.queryPhotoById2(photo.getAsset_ID());
			if(photos.isEmpty()) return new JsonResult(0,new Throwable("数据不存在"));
			for(ProofPhoto photo2:photos){
				String url=PhotoUpload.getUrl(servletRequest)+photo2.getPhoto_url();
				String url2=url.replace("\\", "/");
				photo.setPhoto_url(url2);
			}
			return new JsonResult(1, photos, "删除成功");
		}else{
			List<ProofPhoto> photos=assetMapper.queryPhotoById2(photo.getAsset_ID());
			if(photos.isEmpty()) return new JsonResult(0,new Throwable("数据不存在"));
			for(ProofPhoto photo2:photos){
				String url=PhotoUpload.getUrl(servletRequest)+photo2.getPhoto_url();
				String url2=url.replace("\\", "/");
				photo.setPhoto_url(url2);
			}
			return new JsonResult(0, photos, "未知原因导致删除失败") ;
			
		}
		
		
		
	}

	/*
	 * 查询实物图 返回结果集是String-
	 */
	public JsonResult queryPhotoById(Integer asset_ID) {
		return new JsonResult(1, assetMapper.queryPhotoById(asset_ID), "查询成功");
	}

	/*
	 * 查询资产实物图信息，返回值是pojo的list
	 */
	public JsonResult queryPhotoById2(Integer asset_ID,HttpServletRequest servletRequest) {
		System.out.println("queryPhotoById2--Go");
		List<ProofPhoto> photos=assetMapper.queryPhotoById2(asset_ID);
		if(photos.isEmpty()) return new JsonResult(0,new Throwable("数据不存在"));
		for(ProofPhoto photo:photos){
			System.out.println(photo);
			String url=PhotoUpload.getUrl(servletRequest)+photo.getPhoto_url();
			String url2=url.replace("\\", "/");
			photo.setPhoto_url(url2);
		}
		return new JsonResult(1,photos, "查询成功");
	}

	

}
