package com.dawn.mapper;

import com.dawn.pojo.Inventory;

public interface InventoryMapper {
public Inventory queryInventoryById(Integer asset_ID);
}
