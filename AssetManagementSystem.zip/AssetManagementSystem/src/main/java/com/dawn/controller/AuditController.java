package com.dawn.controller;


import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dawn.pojo.Audit;
import com.dawn.service.AuditService;
import com.dawn.util.JsonResult;

@Controller
@RequestMapping("/audit")
public class AuditController {

	@Resource
	private AuditService auditService;
	//定义常量,1为操作成功,0为失败.
		private static int SUCCESS=1;
		private static int FAIL=0;
	
	@RequestMapping("/add.do")
	@ResponseBody
	public  JsonResult addAudit(@RequestBody Audit audit) {
		if (audit == null)
			return new JsonResult(0,new Throwable("参数不能为null"));
		return auditService.addAudit(audit);
	}

	@RequestMapping("/delete.do")

	@ResponseBody
	public  JsonResult  deleteAudit(Integer audit_ID) {
		System.out.println(audit_ID);
		if (audit_ID == null)
			return new JsonResult(0,new Throwable("参数不能为null"));
		return auditService.deleteAudit(audit_ID);
	}

	@RequestMapping("/modify.do")
	@ResponseBody
	public  JsonResult  modifyAudit(@RequestBody Audit audit) {
		
		System.out.println("接收参数"+audit);
		if (audit== null)
			return new JsonResult(0,new Throwable("参数不能为null"));
		return auditService.modifyAudit(audit);
	}

	@RequestMapping("/queryAll.do")
	@ResponseBody
	public  JsonResult queryAllAudit() {
		return auditService.queryAllAudit();
	}

	@RequestMapping("/queryOne.do")
	@ResponseBody
	public  JsonResult queryAAudit(Integer asset_ID) {
		return auditService.queryAudit(asset_ID);
	}
	@RequestMapping("/queryOne2.do")
	@ResponseBody
	public  JsonResult queryAAudit2(Integer audit_ID ) {
		return auditService.queryAudit2(audit_ID);
	}

}
