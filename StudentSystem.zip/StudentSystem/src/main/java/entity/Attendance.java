package entity;


public class Attendance {
	private Student student;
	private String attendTime;
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	public String getAttendTime() {
		return attendTime;
	}
	public void setAttendTime(String attendTime) {
		this.attendTime = attendTime;
	}
	public Attendance(Student student, String attendTime) {
		super();
		this.student = student;
		this.attendTime = attendTime;
	}
	public Attendance() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Attendance [student=" + student + ", attendTime=" + attendTime + "]";
	}
	
	
	
}
