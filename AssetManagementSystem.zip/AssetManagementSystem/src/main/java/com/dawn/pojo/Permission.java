package com.dawn.pojo;

public class Permission  {
	// TODO Auto-generated constructor stub
  private Boolean baseAuth=false;
  private Boolean auxiliaryAuth=false;
  private Boolean maintainAuth=false;
  private Boolean disposeAuth=false;
  private Boolean statusAuth=false;
  private Boolean transfersAuth=false;
  private Boolean usersAuth=false;
  private Boolean rolesAuth=false;
 
public Permission() {
	super();
	// TODO Auto-generated constructor stub
}

public Permission(Boolean baseAuth, Boolean auxiliaryAuth, Boolean maintainAuth, Boolean disposeAuth,
		Boolean statusAuth, Boolean transfersAuth, Boolean usersAuth, Boolean rolesAuth) {
	super();
	this.baseAuth = baseAuth;
	this.auxiliaryAuth = auxiliaryAuth;
	this.maintainAuth = maintainAuth;
	this.disposeAuth = disposeAuth;
	this.statusAuth = statusAuth;
	this.transfersAuth = transfersAuth;
	this.usersAuth = usersAuth;
	this.rolesAuth = rolesAuth;
}

public Boolean getBaseAuth() {
	return baseAuth;
}
public void setBaseAuth(Boolean baseAuth) {
	this.baseAuth = baseAuth;
}
public Boolean getAuxiliaryAuth() {
	return auxiliaryAuth;
}
public void setAuxiliaryAuth(Boolean auxiliaryAuth) {
	this.auxiliaryAuth = auxiliaryAuth;
}
public Boolean getMaintainAuth() {
	return maintainAuth;
}
public void setMaintainAuth(Boolean maintainAuth) {
	this.maintainAuth = maintainAuth;
}
public Boolean getDisposeAuth() {
	return disposeAuth;
}
public void setDisposeAuth(Boolean disposeAuth) {
	this.disposeAuth = disposeAuth;
}
public Boolean getStatusAuth() {
	return statusAuth;
}
public void setStatusAuth(Boolean statusAuth) {
	this.statusAuth = statusAuth;
}
public Boolean getTransfersAuth() {
	return transfersAuth;
}
public void setTransfersAuth(Boolean transfersAuth) {
	this.transfersAuth = transfersAuth;
}
public Boolean getUsersAuth() {
	return usersAuth;
}
public void setUsersAuth(Boolean usersAuth) {
	this.usersAuth = usersAuth;
}
public Boolean getRolesAuth() {
	return rolesAuth;
}
public void setRolesAuth(Boolean rolesAuth) {
	this.rolesAuth = rolesAuth;
}

@Override
public String toString() {
	return "Permossion [baseAuth=" + baseAuth + ", auxiliaryAuth=" + auxiliaryAuth + ", maintainAuth=" + maintainAuth
			+ ", disposeAuth=" + disposeAuth + ", statusAuth=" + statusAuth + ", transfersAuth=" + transfersAuth
			+ ", usersAuth=" + usersAuth + ", rolesAuth=" + rolesAuth + "]";
}
  
  
  
}
