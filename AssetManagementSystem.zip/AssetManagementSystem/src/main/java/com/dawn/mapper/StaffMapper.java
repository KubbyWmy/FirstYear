package com.dawn.mapper;


import com.dawn.pojo.Staff;

public interface StaffMapper {
	public Staff queryStaff(String staff_ID);
	public int addStaff(Staff staff);
	public int modifyStaff(Staff staff);
}
