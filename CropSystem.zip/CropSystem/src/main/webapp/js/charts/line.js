$(function () {
	var url='info/list.do';
	var user_id=getCookie("id");
	var data={user_id:user_id};
	$.post(url,data,function(result){
    var water = [], temp = [], air = [], fert = [], sun = [];
    for (var i = 0; i < 16; i += 1) {
    	var list=result.data[i];
		var list_a=[list.water,list.temp,list.air,list.fert,list.sun];
        water.push([i, list_a[0]]);
        temp.push([i, list_a[1]]);
        air.push([i,list_a[2]]);
        fert.push([i, list_a[3]]);
        sun.push([i,list_a[4]]);
    }

    var plot = $.plot($("#line-chart"),
           [ { data: water, label: "水分"}, 
             { data: temp, label: "温度" }, 
             { data: fert, label: "养料" }, ], 
             {
               series: {
                   lines: { show: true },
                   points: { show: true }
               },
               
               grid: { hoverable: true, clickable: true },
               yaxis: { min: 0, max: 20 },
			   xaxis: { min: 1, max: 15 },
    	colors: ["#F90", "#666", "#BBB"]
             });
	});
});