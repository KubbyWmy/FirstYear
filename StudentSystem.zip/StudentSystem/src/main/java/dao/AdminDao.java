package dao;

import entity.Admin;

public interface AdminDao {
	Admin findAdminById(String adminId);
}
