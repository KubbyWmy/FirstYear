$(function(){
	$("input[type=text]").blur(cal);
	
});
function cal(){
	var prewater=$('#prewater').val();
	var pretemp=$('#pretemp').val();
	var preair=$('#preair').val();
	var prefert=$('#prefert').val();
	var presun=$('#presun').val();
	$('#pre_plan').html(prewater*1.5+pretemp*0.7+preair*0.1+prefert*3+presun*0.8);
	var customwater=$('#customwater').val();
	var customtemp=$('#customtemp').val();
	var customair=$('#customair').val();
	var customfert=$('#customfert').val();
	var customsun=$('#customsun').val();
	$('#custom_plan').html(customwater*1.5+customtemp*0.7+customair*0.1+customfert*3+customsun*0.8);
	var lastwater=$('#lastwater').val();
	var lasttemp=$('#lasttemp').val();
	var lastair=$('#lastair').val();
	var lastfert=$('#lastfert').val();
	var lastsun=$('#lastsun').val();
	$('#last_plan').html(lastwater*1.5+lasttemp*0.7+lastair*0.1+lastfert*3+lastsun*0.8);
}
function add_pre(){
	var water=$('#prewater').val();
	var temp=$('#pretemp').val();
	var air=$('#preair').val();
	var fert=$('#prefert').val();
	var sun=$('#presun').val();
	var user_id=getCookie("id");
	//console.log(user_id);
	var url="info/add.do";
	var data={user_id:user_id,air:air,water:water,sun:sun,fert:fert,temp:temp};
	$.post(url,data,function(result){
		if(result.state==0){
			alert("增加成功");
			location.reload();
		}
	});
}
function add_last(){
	var water=$('#lastwater').val();
	var temp=$('#lasttemp').val();
	var air=$('#lastair').val();
	var fert=$('#lastfert').val();
	var sun=$('#lastsun').val();
	var user_id=getCookie("id");
	var url="info/add.do";
	var data={user_id:user_id,air:air,water:water,sun:sun,fert:fert,temp:temp};
	$.post(url,data,function(result){
		if(result.state==0){
			alert("增加成功");
			location.reload();
		}
	});
}
function add_custom(){
	var water=$('#customwater').val();
	var temp=$('#customtemp').val();
	var air=$('#customair').val();
	var fert=$('#customfert').val();
	var sun=$('#customsun').val();
	var user_id=getCookie("id");
	var url="info/add.do";
	var data={user_id:user_id,air:air,water:water,sun:sun,fert:fert,temp:temp};
	$.post(url,data,function(result){
		if(result.state==0){
			alert("增加成功");
			location.reload();
		}
	});
}