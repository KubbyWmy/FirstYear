package com.dawn.service;

import com.dawn.util.JsonResult;

public interface InventoryService {
public JsonResult queryInventoryById(Integer asset_ID);
}
