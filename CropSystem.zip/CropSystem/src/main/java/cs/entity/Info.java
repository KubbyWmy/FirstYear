package cs.entity;

import java.sql.Timestamp;

public class Info {
	private String user_id;
	private Timestamp creatime;
	private Integer air;
	private Integer water;
	private Integer sun;
	private Integer fert;
	private Integer temp;
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public Timestamp getCreatime() {
		return creatime;
	}
	public void setCreatime(Timestamp creatime) {
		this.creatime = creatime;
	}
	public Integer getAir() {
		return air;
	}
	public void setAir(Integer air) {
		this.air = air;
	}
	public Integer getWater() {
		return water;
	}
	public void setWater(Integer water) {
		this.water = water;
	}
	public Integer getSun() {
		return sun;
	}
	public void setSun(Integer sun) {
		this.sun = sun;
	}
	public Integer getFert() {
		return fert;
	}
	public void setFert(Integer fert) {
		this.fert = fert;
	}
	public Integer getTemp() {
		return temp;
	}
	public void setTemp(Integer temp) {
		this.temp = temp;
	}
	@Override
	public String toString() {
		return "air=" + air + ", water=" + water + ", sun=" + sun + ", fert=" + fert + ", temp=" + temp;
	}
	public Info() {
		super();
	}
	public Info(String user_id, Integer air, Integer water, Integer sun, Integer fert,
			Integer temp) {
		super();
		this.user_id = user_id;
		this.air = air;
		this.water = water;
		this.sun = sun;
		this.fert = fert;
		this.temp = temp;
	}
	
	
}
