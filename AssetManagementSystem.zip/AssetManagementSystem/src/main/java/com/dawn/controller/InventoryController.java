package com.dawn.controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dawn.service.InventoryService;
import com.dawn.util.JsonResult;

@Controller
@RequestMapping("/toExcel")
public class InventoryController {

	@Resource
	private InventoryService inventoryService;
	@RequestMapping("/queryOne.do")
	@ResponseBody
	public JsonResult queryAll(Integer asset_ID){
		if(asset_ID==null) return new JsonResult(0,new Throwable("参数不能为空"));
		return inventoryService.queryInventoryById(asset_ID);
		
	}
}
