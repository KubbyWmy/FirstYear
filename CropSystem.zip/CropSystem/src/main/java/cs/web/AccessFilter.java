package cs.web;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cs.entity.User;

/**
 * Servlet Filter implementation class AccessFilter
 */
public class AccessFilter implements Filter {
  
	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(
		ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest req = 
			(HttpServletRequest) request;
		HttpServletResponse res = 
			(HttpServletResponse) response;
		
		String path = req.getRequestURI();
		//System.out.println(path); 
		
		
		if(path.endsWith("login.jsp")||path.endsWith("reg.jsp")){ 
			res.addHeader("Cache-Control", "no-cache");
			chain.doFilter(request, response);
			return;
		}
		
		User user = (User)req.getSession()
			.getAttribute("loginUser");
		//System.out.println(user);
		if(user==null){
			String login = 
				req.getContextPath()+ 
				"/login.jsp";
			// /note/log_in.html
			res.sendRedirect(login);
			return;
		}
		res.addHeader("Cache-Control", "no-cache");
		chain.doFilter(request, response);
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
	}

}
