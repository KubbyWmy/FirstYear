package cs.service;

public class PwdException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PwdException() {
	}

	public PwdException(String message) {
		super(message);
	}

	public PwdException(Throwable cause) {
		super(cause);
	}

	public PwdException(String message, Throwable cause) {
		super(message, cause);
	}

	public PwdException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
