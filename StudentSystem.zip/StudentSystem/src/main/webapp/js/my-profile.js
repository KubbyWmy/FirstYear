$(function(){
	var url='http://localhost:8080/StudentSystem/student/findStudent.do';
	var id=UrlParm.parm("id");
	$("#studentId").val(id);
	var param={studentId:id};
	$.post(url,param,function(result){
		if(result.state){
			$("#studentName").val(result.data.studentName);
			$("#studentClass").val(result.data.studentClass);
		}else{
			alert(result.message);
		}
	});
	
});
function saveStudent(){
	//console.log(111);
	var url='http://localhost:8080/StudentSystem/student/modify.do';
	var param={studentId:$("#studentId").val(),
				studentName:$("#studentName").val(),
				studentClass:$("#studentClass").val()};
	$.post(url,param,function(result){
		if(result.data){
			location.href="roles.html";
		}else{
			alert(result.message);
		}
	})
}
