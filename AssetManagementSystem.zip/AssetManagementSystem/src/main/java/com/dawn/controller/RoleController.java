package com.dawn.controller;


import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.dawn.pojo.Role;
import com.dawn.service.RoleService;
import com.dawn.util.JsonResult;

@Controller
@RequestMapping("/role")
public class RoleController {
	@Resource
	private RoleService roleService;

	//定义常量,1为操作成功,0为失败.
			private static int SUCCESS=1;
			private static int FAIL=0;
	
	@RequestMapping(value="/add.do",consumes="application/json")
	@ResponseBody
	public  JsonResult addRole(@RequestBody Role role, HttpSession session) {
		if(role==null) 		
			return new JsonResult(0, new Throwable("参数不能为null"));
		System.out.println(role);
		return (JsonResult) roleService.addRole(role);
	}
	@RequestMapping("/modify.do")
	@ResponseBody
	public  JsonResult modifyRolePermissiion(@RequestBody Role role) {
		if(role==null) return new JsonResult(0, new Throwable("参数不能为null"));
	  return (JsonResult) roleService.modifyRolePermission(role);
	}

	@RequestMapping("/queryByName.do")
	@ResponseBody
	public  JsonResult queryRoleByName(String role_name) {
		/*Role role = roleService.queryRoleByName(role_name);
		if (role != null)
			return JSON.toJSONString(role);*/
		if(role_name==null) return new JsonResult(0, new Throwable("参数不能为null"));
		return new JsonResult(roleService.queryRoleByName(role_name));
	}

	@RequestMapping("/queryById.do")
	@ResponseBody
	public  JsonResult  queryRoleById(Integer role_ID) {
		/*Role role = roleService.queryRoleById(role_ID);
		if (role != null)
			return role;*/
		System.out.println(role_ID);
		if(role_ID==null) return new JsonResult(0, new Throwable("参数不能为null"));
		return new JsonResult(roleService.queryRoleById(role_ID));

	}

	@RequestMapping("/queryAll.do")
	@ResponseBody
	public  JsonResult queryAllRole() {
			return  roleService.queryAllRole();
	}
	@RequestMapping("/deleteRole.do")
	@ResponseBody
	public  JsonResult deleteRole(Integer role_ID) {
		if(role_ID==null) return new JsonResult(0, new Throwable("参数不能为null"));
			return (JsonResult) roleService.deleteRole(role_ID);
	}

}
