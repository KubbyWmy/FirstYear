package test;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;
import java.util.Properties;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.junit.Test;

import cs.dao.UserDao;
import cs.entity.User;
import cs.service.UserService;


public class JdbcTestCase extends BaseTestCase{
	@Test
	public void testDataSource() throws SQLException{
		DataSource ds=ctx.getBean("dataSource",DataSource.class);
		Connection conn=ds.getConnection();
		DatabaseMetaData md=conn.getMetaData();
		System.out.println(md);
		String n=md.getDatabaseProductName();
		String v=md.getDatabaseProductVersion();
		System.out.println(n+v);
		conn.close();
	}
	@Test
	public void usertest(){
		String name="wxm";
		UserDao dao=ctx.getBean("userDao",UserDao.class);
		User user=dao.findUserById(name);
		System.out.println(user);
	}
	@Test
	public void testLogin(){
		String id="wxm";
		String pwd="123";
		UserService service=ctx.getBean("userService",UserService.class);
		User user=service.login(id, pwd);
		System.out.println(user);
	}
	@Test
	public void reg(){
		UserService service=ctx.getBean("userService",UserService.class);
		User user=service.reg("aaa", "111", "111");
		System.out.println(user);
	}
	@Test
	public void update(){
		UserDao dao=ctx.getBean("userDao",UserDao.class);
		User user=dao.findUserById("wxm");
		user.setPwd("456");
		int i=dao.updateUser(user);
		System.out.println(user);
		System.out.println(i);
	}
	@Test
	public void updateService(){
		UserService service=ctx.getBean("userService",UserService.class);
		User user=service.update("wxm", "123", "wmy", "sda");
		System.out.println(user);
	}
	@Test
	public void address() throws FileNotFoundException, IOException{
		Properties pro=new Properties();
		pro.load(new FileInputStream("address.properties"));
		String a=pro.getProperty("address");
		System.out.println(a);
		
	}
}
