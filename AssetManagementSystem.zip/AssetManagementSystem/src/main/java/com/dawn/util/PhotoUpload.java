package com.dawn.util;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.MultipartFile;
public class PhotoUpload {

	public static String upload(String url,String path,MultipartFile file ){
		
		SimpleDateFormat  stFormat=new SimpleDateFormat("yyyymmddhhMMSS");
		String newfileName=stFormat.format(new Date());
		
		SimpleDateFormat  stFormat1=new SimpleDateFormat("yyyy");
		String year=stFormat1.format(new Date());
	
		url+=year+File.separator;
		path+=File.separator+year;
		File file2=new File(path);
		if(!file2.exists())
			file2.mkdirs();
		
	
				String fileName = file.getOriginalFilename();
				System.out.println("fileName:" + fileName);
			
		        newfileName+=fileName.substring(fileName.lastIndexOf("."), fileName.length());
		        System.out.println("newfileName:" + newfileName);
				url+=newfileName;
				
				File targetFile = new File(path, newfileName);
				
				/*if (!targetFile.exists()) {
					targetFile.mkdirs();
				}*/
		
				try {
					//拷贝文件到目录路径
					file.transferTo(targetFile);
				} catch (Exception e) {
					e.printStackTrace();
				}
				String luj=url+"name"+fileName;
				System.out.println(luj);
			System.out.println(url);
			System.out.println(fileName);
		
		return url;
	}
	
	public ResponseEntity<byte[]> download(HttpServletRequest request) throws IOException {  
		 HttpHeaders headers = new HttpHeaders();  
		 headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);  
		
		 headers.setContentDispositionFormData("attachment", "sfsada.docx");
		 
		 String path = request.getSession().getServletContext()
					.getRealPath("//upload//");
		 
		  File file=new File(path+"/2016/201645121009808.docx");
		  
		return new ResponseEntity<byte[]>(FileCopyUtils.copyToByteArray(file),
		           headers, HttpStatus.CREATED);  
	}
	public static String getUrl(HttpServletRequest servletRequest){
	

		String str="http://"+servletRequest.getServerName()+":"+servletRequest.getServerPort()
		+servletRequest.getContextPath()+"/";

		return str;
		
	}
	
	
}
