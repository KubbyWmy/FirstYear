package com.dawn.service;


import javax.servlet.http.HttpServletRequest;

import com.dawn.pojo.ProofRepair;
import com.dawn.pojo.Repair;
import com.dawn.util.JsonResult;

public interface RepairService {
	public JsonResult addRepair(Repair repair);
	public JsonResult deleteRepair(Integer repair_ID);
	public JsonResult modifyRepair(Repair repair);
	public JsonResult queryAllRepair() ;
//	public List<Repair> queryAssetRepair(Integer asset_ID);
	public JsonResult queryRepairById(Integer  repair_ID);
	
	public JsonResult addRepairProof(ProofRepair proofRepair);
//	public List<String> queryRepairProof(Integer repair_ID);
	public JsonResult queryRepairProof2(Integer repair_ID,HttpServletRequest servletRequest);
	public JsonResult deleteRepairProof(ProofRepair proofRepair,HttpServletRequest servletRequest);
}
