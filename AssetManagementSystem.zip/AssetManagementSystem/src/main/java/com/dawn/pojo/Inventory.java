package com.dawn.pojo;

public class Inventory {
 private String inventoryNo;
 private Asset asset;
 private Audit audit;
 private Integer  bookQuantity;
 private Integer actualQuantity;
 
 
 public Integer getBookQuantity() {
	return bookQuantity;
}

public void setBookQuantity(Integer bookQuantity) {
	this.bookQuantity = bookQuantity;
}

public Integer getActualQuantity() {
	return actualQuantity;
}

public void setActualQuantity(Integer actualQuantity) {
	this.actualQuantity = actualQuantity;
}

public Inventory() {
		super();
		// TODO Auto-generated constructor stub
	}

public String getInventoryNo() {
	return inventoryNo;
}

public void setInventoryNo(String inventoryNo) {
	this.inventoryNo = inventoryNo;
}

public Asset getAsset() {
	return asset;
}

public void setAsset(Asset asset) {
	this.asset = asset;
}

public Audit getAudit() {
	return audit;
}

public void setAudit(Audit audit) {
	this.audit = audit;
}

@Override
public String toString() {
	return "Inventory [inventoryNo=" + inventoryNo + ", asset=" + asset + ", audit=" + audit + ", bookQuantity="
			+ bookQuantity + ", actualQuantity=" + actualQuantity + "]";
}




	
}
