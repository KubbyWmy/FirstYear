package privateInfo;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.junit.Test;

import com.dawn.mapper.StaffInfoMapper;
import com.dawn.mapper.StaffMapper;
import com.dawn.mapper.RoleMapper;
import com.dawn.pojo.Role;
import com.dawn.pojo.Staff;
public class StaffMapperTest extends DatabaseTest{
	@Test
	public void testDataSource() throws SQLException{
		DataSource ds=ctx.getBean("dataSource",DataSource.class);
		Connection conn=ds.getConnection();
		DatabaseMetaData md=conn.getMetaData();
		System.out.println(md);
		String n=md.getDatabaseProductName();
		String v=md.getDatabaseProductVersion();
		System.out.println(n+v);
		conn.close();
	}
	@Test
	public void addStaff(){
		StaffInfoMapper mapper=ctx.getBean("staffInfoMapper",StaffInfoMapper.class);
		
		RoleMapper e=ctx.getBean("roleMapper",RoleMapper.class);
	//	Staff staff=new Staff("1777", "dfa", "dfa", "dfa", "dfa", "dfa", new Role());
		System.out.println(
//				mapper.addStaff()
				);
		
	}
	@Test
	public void deleteStaff(){
		StaffMapper mapper=ctx.getBean("staffMapper",StaffMapper.class);
		System.out.println(
				mapper.queryStaff("12345")
				);
		
	}
	@Test
	public void showStaff(){
		StaffInfoMapper mapper=ctx.getBean("staffInfoMapper",StaffInfoMapper.class);
		List<Staff> list=mapper.showStaffInfo();
		for(Staff staff:list){
			System.out.println(staff);
		}
		
	}
	@Test
	public void changeStaff(){
		StaffInfoMapper mapper=ctx.getBean("staffInfoMapper",StaffInfoMapper.class);
		
		//Staff staff=new Staff("1","bbbaa","aaaaaa","aaaaa","aaaaa","aaaa",new Role());
		int a=mapper.saveStaffInfo("5",  "asda", "adadf");
		System.out.println(a);
	}
}

