package privateInfo;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.junit.Test;

import com.dawn.mapper.AuditMapper;
import com.dawn.mapper.RepairMapper;
import com.dawn.pojo.Audit;
import com.dawn.pojo.ProofRepair;
import com.dawn.pojo.Repair;

public class RepairTest extends DatabaseTest{
	@Test
	public void testDataSource() throws SQLException{
		DataSource ds=ctx.getBean("dataSource",DataSource.class);
		Connection conn=ds.getConnection();
		DatabaseMetaData md=conn.getMetaData();
		System.out.println(md);
		String n=md.getDatabaseProductName();
		String v=md.getDatabaseProductVersion();
		System.out.println(n+v);
		conn.close();
	}
	@Test
	public void testaddRepair(){
		RepairMapper a=ctx.getBean("repairMapper",RepairMapper.class);
		Date date=new Date(2017, 2, 9);
		Repair repair=new Repair(1, 2, date, "yingp", "genhuan", "lili", 12.3, "lili", "pp");
	     int i=a.addRepair(repair);
	     System.out.println(i);
	}
	@Test
	public void testdeleteRepair(){
		RepairMapper a=ctx.getBean("repairMapper",RepairMapper.class);
	     int i=a.deleteRepair(2);
	     System.out.println(i);
	}
	@Test
	public void testmodifyRepair(){
		RepairMapper a=ctx.getBean("repairMapper",RepairMapper.class);
		Date date=new Date(2017, 2, 9);
		Repair repair=new Repair(1, 2, date, "fgfd", "genhuan", "lili", 12.3, "lili", "pp");
	     int i=a.modifyRepair(repair);
	     System.out.println(i);
	}
	@Test
	public void testqueryAllRepair(){
		RepairMapper a=ctx.getBean("repairMapper",RepairMapper.class);
	     List<Repair> list=a.queryAllRepair();
	     for(Repair i:list)
	     System.out.println(i);
	}
	
	@Test
	public void testqueryAssetRepair(){
		RepairMapper a=ctx.getBean("repairMapper",RepairMapper.class);
	     List<Repair> list=a.queryAssetRepair(1);
	     for(Repair i:list)
	     System.out.println(i);
	}
	
	@Test
	public void testaddRepairProof(){
		RepairMapper a=ctx.getBean("repairMapper",RepairMapper.class);
		ProofRepair p=new ProofRepair(1, 2, "kk/ll");
	     int i=a.addRepairProof(p);
	     System.out.println(i);
	}
	@Test
	public void testqueryRepairProof(){
		RepairMapper a=ctx.getBean("repairMapper",RepairMapper.class);
		ProofRepair p=new ProofRepair(1, 2, "kk/ll");
	    List<String> s=a.queryRepairProof(2); 
	    for(String i:s)
		     System.out.println(i);
	}
	
	@Test
	public void testdeleteRepairProof(){
		RepairMapper a=ctx.getBean("repairMapper",RepairMapper.class);
	  int i=a.deleteRepairProof(2);
	 
		     System.out.println(i);
	}
}
