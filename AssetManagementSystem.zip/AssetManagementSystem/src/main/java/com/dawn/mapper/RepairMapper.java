package com.dawn.mapper;

import java.util.List;

import com.dawn.pojo.ProofRepair;
import com.dawn.pojo.Repair;

public interface RepairMapper {
public int addRepair(Repair repair);
public int deleteRepair(Integer repair_ID);
public int modifyRepair(Repair repair);
public List<Repair> queryAllRepair() ;
public List<Repair> queryAssetRepair(Integer asset_ID);
public Repair queryRepairById(Integer  repair_ID);

public int addRepairProof(ProofRepair proofRepair);
public List<String> queryRepairProof(Integer repair_ID);
public List<ProofRepair> queryRepairProof2(Integer repair_ID);
public int deleteRepairProof(Integer repairProof_ID);

}
