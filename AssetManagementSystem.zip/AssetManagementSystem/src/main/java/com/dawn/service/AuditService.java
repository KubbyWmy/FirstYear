package com.dawn.service;


import com.dawn.pojo.Audit;
import com.dawn.util.JsonResult;

public interface AuditService {
	public JsonResult addAudit(Audit audit);
	 public JsonResult modifyAudit(Audit audit);
	 public JsonResult deleteAudit(Integer audit_ID);
	 public JsonResult queryAudit(Integer asset_ID);
	 public JsonResult queryAudit2(Integer audit_ID);
	 public JsonResult queryAllAudit();
}
