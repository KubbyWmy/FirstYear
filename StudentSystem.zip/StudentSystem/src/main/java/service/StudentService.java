package service;

import java.util.List;

import entity.Attendance;
import entity.Student;

public interface StudentService {
		int addStudent(String studentId,String studentName,String studentClass) throws StudentException;
		Student findStudentById(String studentId) throws StudentException;
		int attend(String studentId,String attendTime) throws StudentException;
		int modifyStudent(String studentId,String studentName,String studentClass) throws StudentException;
		List<Attendance> showAllAttendance();
		List<Student> showAllStudent();
}
