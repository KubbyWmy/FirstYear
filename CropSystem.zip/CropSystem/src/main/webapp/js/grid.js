var SUCCESS = 0;
$(function(){
	var ccc=getCookie("id");
	$('#head_username').html(ccc);
	$('#menu_username').html(ccc);
	var template='<tr id="write_tr">'+
	'<td>[water]</td>'+
	'<td>[temp]</td>'+
	'<td>[air]</td>'+
	'<td>[fert]</td>'+
	'<td>[sun]</td>'+
	'<td class="action-td">'+
		'<input type="button" id="write_button" value="　√　" onclick="writeAction(this);" class="btn btn-small btn-warning">'+
			'</input>　　'+				
		'<input type="button" value="　X　" onclick="removeAction(this);" class="btn btn-small">'+
		'</input>'+
	'</td>'+
'</tr>';
	var url='info/list.do';
	var user_id=getCookie("id");
	var data={user_id:user_id};
	$.post(url,data,function(result){
		if(result.state==SUCCESS){
			var list=result.data;
			var listAll=$('#listbox_all');
			var max=list.length;
			setCookie("maxLines", max);
//			console.log(list);
			for(var i=0;i<list.length;i++){
				var tr= template.replace('[water]',list[i].water)
								.replace('[temp]',list[i].temp)
								.replace('[air]',list[i].air)
								.replace('[fert]',list[i].fert)
								.replace('[sun]',list[i].sun);
				var creatime=list[i].creatime;
				tr=$(tr).data('creatime',creatime);
				listAll.append(tr);
			}
		}
	});
});
function removeAction(btn){
	var a=$(btn);
	var tr=a.parents("tr");
	var creatime=tr.data('creatime');
	//console.log(creatime);
	var url='info/remove.do';
	var data={creatime:creatime};
	$.post(url,data,function(result){
		console.log(1);
			alert("删除成功!");
			//console.log(1);
			location.reload();
	});
}
function writeAction(btn){ 
	var a=$(btn);
	var tr=a.parents("tr");
	var creatime=tr.data('creatime');
	console.log(creatime);
	var url='info/write.do';
	var data={creatime:creatime};
	$.post(url,data,function(result){
			alert("实施成功!");
			$.post('info/remove.do',data,function(result){});
			location.reload();
	});
}

